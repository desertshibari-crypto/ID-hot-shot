# NobleDispatch — Phase 1 Deployment Prompt for Claude Code

**For:** Boston 2 VPS (Hostinger KVM8) — co-residing with idhotshot.com
**Subdomain:** nobledispatch.idhotshot.com
**Tenant #1:** ID Hotshot Transportation (Danielle Riley, Founder)
**Created by:** The Noble Glitch · thenobleglitch.com
**Phase:** 1 of 4 (Foundation + Core Dispatch Loop)

---

## How to run this

```bash
# 1. Copy this file + idhotshot_site.html to Boston 2:
scp NOBLEDISPATCH_DEPLOY_PROMPT.md idhotshot_site.html boston2:/root/

# 2. SSH in
ssh boston2

# 3. Set the env vars (see PRE-FLIGHT below)
cd /root && nano nobledispatch.env

# 4. Source them and launch Claude Code with autonomous mode + the prompt
source /root/nobledispatch.env
claude --dangerously-skip-permissions < /root/NOBLEDISPATCH_DEPLOY_PROMPT.md

# 5. From a SECOND SSH window, watch the build:
tail -f /var/log/nobledispatch-build.log

# 6. Go to bed.
```

---

## PRE-FLIGHT — set these before running

Create `/root/nobledispatch.env` with the following:

```bash
# === REQUIRED ===
export DOMAIN_PRIMARY="nobledispatch.idhotshot.com"
export ADMIN_EMAIL="dispatch@idhotshot.com"        # Let's Encrypt + initial admin
export SUPERADMIN_EMAIL="you@thenobleglitch.com"   # Noble Glitch superadmin login

# Postgres (Claude Code will install + configure)
export POSTGRES_USER="nobledispatch"
export POSTGRES_PASSWORD="<generate a 32-char random string>"
export POSTGRES_DB="nobledispatch"

# Mapbox - https://account.mapbox.com/access-tokens/
export MAPBOX_PUBLIC_TOKEN="pk.xxxxxxxxxxxxxxxxxxxxxxx"

# Google Maps Directions API - https://console.cloud.google.com/google/maps-apis/credentials
export GOOGLE_MAPS_API_KEY="AIzaxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"

# Initial admin password (change immediately after first login)
export INITIAL_ADMIN_PASSWORD="<temp password — change after login>"

# === OPTIONAL (Phase 2/3 — leave blank if not ready) ===
export TWILIO_ACCOUNT_SID=""
export TWILIO_AUTH_TOKEN=""
export TWILIO_FROM_NUMBER=""
export ANTHROPIC_API_KEY=""
export RESEND_API_KEY=""

# === BRANDING ===
export NOBLE_GLITCH_LOGO_URL="https://thenobleglitch.com/logo.png"  # or leave blank
export NOBLE_GLITCH_LINK="https://thenobleglitch.com"
```

Verify DNS is live before running:
```bash
dig +short nobledispatch.idhotshot.com
# Should return Boston 2's public IP. If not, add an A record at your DNS host.
```

---

## ===== PROMPT BEGIN — EVERYTHING BELOW IS FOR CLAUDE CODE =====

You are deploying **NobleDispatch**, a multi-tenant fleet management / dispatch / TMS SaaS platform owned by **The Noble Glitch** (thenobleglitch.com). The first tenant is **ID Hotshot Transportation** (Danielle Riley, founder, USDOT 4559278). This platform will be sold/licensed to other trucking companies later — multi-tenancy and white-labeling are not optional, they are foundational.

A reference file `idhotshot_site.html` is at `/root/`. **Open it. Read it.** It's the design language for the marketing site (already deployed at idhotshot.com on this same server). Match its visual aesthetic in NobleDispatch — typography (Anton + Barlow), red/black/silver palette, industrial/automotive feel, sharp lines, frame-based navigation. NobleDispatch is the *operations app* equivalent of that brand.

This is **Phase 1 of 4**. Your job is to build the foundation + core dispatch loop. Do **not** attempt features marked Phase 2/3 (listed at the bottom). Stub them cleanly so they can be added later.

---

## HARD SAFETY RAILS — read every word, violations are unacceptable

You are running autonomously with `--dangerously-skip-permissions`. The user is asleep. You will not be supervised. The following rules are absolute:

1. **Work directory is `/opt/nobledispatch` only.** Do not write, modify, or delete any file outside this directory, EXCEPT:
   - `/etc/nginx/sites-available/nobledispatch` and `/etc/nginx/sites-enabled/nobledispatch` (new file, do not modify other nginx configs)
   - `/etc/letsencrypt/*` (managed by certbot)
   - `/var/log/nobledispatch-build.log` (your status log)
   - Package installation via apt (allowed)

2. **Do not touch the existing idhotshot.com deployment.** Verify with `nginx -T | grep idhotshot` that it's still serving before and after your work. If you break it, stop everything and log a clear error.

3. **Initialize git in `/opt/nobledispatch` immediately.** Commit after every checkpoint listed below. Use clear commit messages: `[checkpoint N] description`.

4. **Stream a status log** to `/var/log/nobledispatch-build.log` at every step:
   ```
   touch /var/log/nobledispatch-build.log && chmod 644 /var/log/nobledispatch-build.log
   ```
   Format every entry: `[YYYY-MM-DD HH:MM:SS] [PHASE] [LEVEL] message`. The user will `tail -f` this when they wake up. Make it a clear narrative they can scan in 60 seconds.

5. **Backup before destructive operations.** Before any database migration, dump existing schema. Before modifying nginx, copy current config to `/root/nginx-backup-<timestamp>/`.

6. **Hard STOP conditions** — if any of these happen, stop, log a clear error, do NOT guess:
   - DNS for nobledispatch.idhotshot.com doesn't resolve to this server
   - Required env vars are missing
   - Port 80/443 conflict with idhotshot.com
   - Postgres install fails
   - Existing idhotshot.com site stops responding
   - You hit ambiguity that requires a product decision

7. **Use Docker Compose for everything.** App, Postgres, Redis — all containerized. The host should only run nginx + certbot. This guarantees portability for Phase 4 (migration to Danielle's own VPS).

8. **Use ports 3001 internally.** Nginx reverse-proxies 443 → 3001. The existing idhotshot.com runs on 3000 — do not collide.

9. **All credentials go in `/opt/nobledispatch/.env`** with mode 600. Never commit this file. Add to `.gitignore` first commit.

10. **Test as you build.** After each module, write a smoke test (curl-based or Playwright) and run it. If it fails, fix it before moving on. Never declare a checkpoint complete with failing tests.

---

## REQUIRED FROM ENV (already exported by user before running)

Read these at the start. If any required ones are missing, STOP and log clearly:

- `DOMAIN_PRIMARY` (required)
- `ADMIN_EMAIL` (required)
- `SUPERADMIN_EMAIL` (required)
- `POSTGRES_PASSWORD` (required)
- `MAPBOX_PUBLIC_TOKEN` (required)
- `GOOGLE_MAPS_API_KEY` (required)
- `INITIAL_ADMIN_PASSWORD` (required)
- `NOBLE_GLITCH_LINK` (required, default: `https://thenobleglitch.com`)
- `NOBLE_GLITCH_LOGO_URL` (optional)
- `TWILIO_*`, `ANTHROPIC_API_KEY`, `RESEND_API_KEY` (optional — features stub gracefully if missing)

---

## TECHNICAL STACK — non-negotiable

| Layer | Choice |
|---|---|
| Runtime | Node 20 LTS in Docker |
| Frontend | Next.js 14 App Router + TypeScript + Tailwind |
| UI primitives | shadcn/ui (install + customize, do not just use defaults) |
| Database | PostgreSQL 16 with Row-Level Security (RLS) |
| ORM | Drizzle ORM (not Prisma) |
| Auth | Better-Auth (self-hosted, owns the user table) |
| Job queue | BullMQ + Redis 7 |
| Real-time | Native WebSocket (not socket.io — keep it lean) |
| Maps | Mapbox GL JS (rendering) + Google Directions API (routing) |
| TTS | Web Speech API (built into browsers, no key needed for Phase 1) |
| File storage | Local FS at `/opt/nobledispatch/storage` (S3-compatible swap-in is Phase 2) |
| Reverse proxy | Nginx on host (NOT in Docker — co-resides with idhotshot.com nginx) |
| SSL | certbot / Let's Encrypt |
| Container orchestration | Docker Compose |

Fonts: Anton (display) + Barlow (body) + Barlow Condensed (UI labels) — same as marketing site.

---

## ARCHITECTURE — multi-tenancy

### Tenant model

- Every domain entity (customers, trucks, jobs, employees, etc.) has a `tenant_id UUID NOT NULL` column.
- PostgreSQL **Row-Level Security** is enabled on every domain table. Policy: rows are visible/mutable only when `current_setting('app.current_tenant_id')::uuid = tenant_id`.
- The Next.js middleware sets `app.current_tenant_id` per request based on the authenticated user's tenant.
- Three superadmin escape hatches:
  1. A `system` schema for tenant-spanning data (tenants table itself, system_settings, audit log)
  2. A superadmin role (Noble Glitch owner) that bypasses RLS via a `BYPASSRLS` Postgres role
  3. The auth table (`users`) lives in the `system` schema and joins to `tenants`

### Tenant resolution

- Phase 1: subdomain matching. `nobledispatch.idhotshot.com` resolves to `tenant_slug=idhotshot` via a custom_domains lookup.
- Phase 4 (custom domains): a `custom_domains` table maps `dispatch.othercompany.com` → `tenant_id`. Phase 1 should ALREADY have this table; just don't expose UI to manage it yet.

### Roles (RBAC)

- `superadmin` — Noble Glitch owner only, sees ALL tenants, can create new ones
- `tenant_owner` — owns a tenant (e.g. Danielle), full control of their tenant
- `dispatcher` — can create/assign jobs, message employees
- `accountant` — can see jobs/billing but not edit assignments
- `driver` — sees only their own jobs/calendar/messages
- `customer` — Phase 2 — read-only portal for tenant's customers

Permissions enforced at API boundary AND at UI level. Never trust the client.

### White-labeling

Each tenant has a `tenant_settings` table with:
- `brand_name` (e.g. "ID Hotshot Transportation")
- `logo_url` (uploaded by tenant_owner)
- `primary_color` (hex, default `#d8232a`)
- `accent_color` (hex, default `#0a0a0a`)
- `support_phone`, `support_email`
- `letterhead_html` (for invoice headers)
- `dispatch_hours` (JSON: which hours/days they accept jobs)
- `active_modules` (JSON: which Phase 2/3 features they've enabled)

The Noble Glitch attribution is **system-level** — only the superadmin can disable/edit it. Stored in `system_settings.noble_glitch_attribution_visible` (default true) and `system_settings.noble_glitch_link`.

### "Powered by The Noble Glitch" placement

- Login screen footer (always visible)
- Tenant admin dashboard footer (small, always visible)
- Driver app: hidden by default (avoid clutter on small screens) — toggleable in tenant settings
- Public-facing pages (customer portal in Phase 2): visible
- Invoice PDFs: small line in footer

---

## DATABASE SCHEMA — Phase 1

Create migrations in this order. Use Drizzle's migration generator. Every domain table gets RLS enabled with a tenant policy.

### Schema: `system`

```sql
-- system.tenants — every customer of NobleDispatch
CREATE TABLE system.tenants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,                  -- 'idhotshot'
  legal_name TEXT NOT NULL,                   -- 'ID Hotshot Transportation, LLC'
  display_name TEXT NOT NULL,                 -- 'ID Hotshot Transportation'
  primary_subdomain TEXT UNIQUE NOT NULL,     -- 'nobledispatch.idhotshot.com'
  status TEXT NOT NULL DEFAULT 'active',      -- active | suspended | trial
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  metadata JSONB NOT NULL DEFAULT '{}'
);

-- system.custom_domains (Phase 4 ready)
CREATE TABLE system.custom_domains (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES system.tenants(id) ON DELETE CASCADE,
  domain TEXT UNIQUE NOT NULL,
  ssl_status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- system.users — authentication, joins to tenants
CREATE TABLE system.users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES system.tenants(id) ON DELETE CASCADE,  -- NULL for superadmin
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL,                         -- superadmin | tenant_owner | dispatcher | accountant | driver | customer
  full_name TEXT NOT NULL,
  phone TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_login_at TIMESTAMPTZ
);

-- system.system_settings — Noble Glitch only
CREATE TABLE system.system_settings (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- system.audit_log — every meaningful action
CREATE TABLE system.audit_log (
  id BIGSERIAL PRIMARY KEY,
  tenant_id UUID,
  user_id UUID,
  action TEXT NOT NULL,                       -- 'job.created', 'employee.assigned', etc.
  entity_type TEXT,
  entity_id TEXT,
  details JSONB,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON system.audit_log (tenant_id, created_at DESC);
```

### Schema: `app` (tenant-scoped, RLS-enabled)

```sql
-- app.tenant_settings (one row per tenant)
CREATE TABLE app.tenant_settings (
  tenant_id UUID PRIMARY KEY REFERENCES system.tenants(id) ON DELETE CASCADE,
  brand_name TEXT NOT NULL,
  logo_url TEXT,
  primary_color TEXT NOT NULL DEFAULT '#d8232a',
  accent_color TEXT NOT NULL DEFAULT '#0a0a0a',
  support_phone TEXT,
  support_email TEXT,
  letterhead_html TEXT,
  dispatch_hours JSONB NOT NULL DEFAULT '{"mon":"24h","tue":"24h","wed":"24h","thu":"24h","fri":"24h","sat":"24h","sun":"24h"}',
  active_modules JSONB NOT NULL DEFAULT '{"jobs":true,"calendars":true,"messaging":true,"map":true}',
  usdot_number TEXT,
  mc_number TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- app.customers
CREATE TABLE app.customers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  company_name TEXT,
  contact_name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  billing_address JSONB,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- app.trucks
CREATE TABLE app.trucks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  nickname TEXT NOT NULL,                     -- "Big Red", "Truck 3"
  type TEXT NOT NULL,                         -- 'box_13' | 'pickup_18ft' | 'fifth_wheel' | 'camper' | 'bumper_pull'
  vin TEXT,
  license_plate TEXT,
  registration_expiry DATE,
  insurance_expiry DATE,
  color_hex TEXT NOT NULL DEFAULT '#d8232a',  -- for calendar coding
  status TEXT NOT NULL DEFAULT 'available',   -- available | in_use | maintenance | retired
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- app.employees
CREATE TABLE app.employees (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  user_id UUID UNIQUE,                        -- joins to system.users for login
  full_name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  role TEXT NOT NULL,                         -- 'driver' | 'dispatcher' | 'office' | 'mechanic'
  cdl_number TEXT,
  cdl_expiry DATE,
  cdl_class TEXT,
  endorsements TEXT[],
  hire_date DATE,
  pay_type TEXT,                              -- 'per_mile' | 'hourly' | 'salary' | 'percentage'
  pay_rate NUMERIC(10,2),
  is_active BOOLEAN NOT NULL DEFAULT true,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- app.jobs
CREATE TABLE app.jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  job_number TEXT NOT NULL,                   -- e.g. 'IDH-2026-0001' (auto-generated)
  customer_id UUID REFERENCES app.customers(id),
  status TEXT NOT NULL DEFAULT 'inbound',     -- inbound | accepted | assigned | in_progress | completed | cancelled
  source TEXT NOT NULL DEFAULT 'manual',      -- manual | website_booking | external_board | api
  pickup_location JSONB NOT NULL,             -- {address, city, state, zip, lat, lng, contact_name, contact_phone}
  dropoff_location JSONB NOT NULL,
  pickup_window_start TIMESTAMPTZ,
  pickup_window_end TIMESTAMPTZ,
  dropoff_window_start TIMESTAMPTZ,
  dropoff_window_end TIMESTAMPTZ,
  equipment_type TEXT,                        -- matches truck.type
  description TEXT,
  weight_lbs NUMERIC,
  dimensions TEXT,
  special_instructions TEXT,
  rate_quoted NUMERIC(10,2),
  rate_final NUMERIC(10,2),
  distance_miles NUMERIC,
  route_geojson JSONB,                        -- cached route from Google Directions
  assigned_employee_id UUID REFERENCES app.employees(id),
  assigned_truck_id UUID REFERENCES app.trucks(id),
  paperwork_urls JSONB DEFAULT '[]',          -- BOLs, invoices, etc.
  created_by UUID REFERENCES system.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON app.jobs (tenant_id, status, pickup_window_start);
CREATE INDEX ON app.jobs (tenant_id, assigned_employee_id);
CREATE INDEX ON app.jobs (tenant_id, assigned_truck_id);

-- app.job_time_entries (billable minute tracker)
CREATE TABLE app.job_time_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  job_id UUID NOT NULL REFERENCES app.jobs(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES app.employees(id),
  start_at TIMESTAMPTZ NOT NULL,
  end_at TIMESTAMPTZ,
  category TEXT NOT NULL,                     -- 'driving' | 'loading' | 'unloading' | 'waiting' | 'fueling' | 'paperwork'
  notes TEXT,
  is_billable BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- app.employee_pay_periods (Phase 2 fully wires this; Phase 1 just creates table)
CREATE TABLE app.employee_pay_periods (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  employee_id UUID NOT NULL REFERENCES app.employees(id),
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  total_hours NUMERIC,
  total_miles NUMERIC,
  gross_pay NUMERIC(10,2),
  status TEXT NOT NULL DEFAULT 'draft',       -- draft | approved | paid | exported
  exported_to TEXT,                           -- 'quickbooks' | 'manual' | etc.
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- app.messages
CREATE TABLE app.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  thread_id UUID NOT NULL,                    -- groups messages
  from_user_id UUID NOT NULL REFERENCES system.users(id),
  to_user_id UUID REFERENCES system.users(id),  -- null = broadcast
  job_id UUID REFERENCES app.jobs(id),        -- optional link
  body TEXT NOT NULL,
  alert_type TEXT,                            -- 'job_assigned' | 'admin_call_request' | 'standard' | etc.
  is_priority BOOLEAN NOT NULL DEFAULT false,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON app.messages (tenant_id, thread_id, created_at);
CREATE INDEX ON app.messages (tenant_id, to_user_id, read_at);

-- app.documents (BOLs, PODs, COIs, photos, etc.)
CREATE TABLE app.documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  job_id UUID REFERENCES app.jobs(id) ON DELETE CASCADE,
  employee_id UUID REFERENCES app.employees(id),
  truck_id UUID REFERENCES app.trucks(id),
  filename TEXT NOT NULL,
  file_path TEXT NOT NULL,                    -- /opt/nobledispatch/storage/...
  mime_type TEXT NOT NULL,
  size_bytes BIGINT NOT NULL,
  document_type TEXT NOT NULL,                -- 'bol' | 'pod' | 'coi' | 'invoice' | 'photo' | 'other'
  uploaded_by UUID REFERENCES system.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- app.calendar_events (unified — jobs auto-create entries; admin can add others)
CREATE TABLE app.calendar_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  event_type TEXT NOT NULL,                   -- 'job' | 'admin' | 'maintenance' | 'time_off'
  job_id UUID REFERENCES app.jobs(id) ON DELETE CASCADE,
  truck_id UUID REFERENCES app.trucks(id),
  employee_id UUID REFERENCES app.employees(id),
  title TEXT NOT NULL,
  start_at TIMESTAMPTZ NOT NULL,
  end_at TIMESTAMPTZ NOT NULL,
  color_hex TEXT,                             -- inherits from truck.color_hex if job
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON app.calendar_events (tenant_id, start_at);
CREATE INDEX ON app.calendar_events (tenant_id, employee_id, start_at);
CREATE INDEX ON app.calendar_events (tenant_id, truck_id, start_at);

-- app.inbound_requests (from website bookings, external boards, customer portal)
CREATE TABLE app.inbound_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  source TEXT NOT NULL,                       -- 'website_booking_form' | 'live_chat' | 'external_board' | 'api'
  source_reference TEXT,                      -- e.g. external job ID
  raw_payload JSONB NOT NULL,                 -- whatever came in
  parsed_payload JSONB,                       -- AI-extracted (Phase 2)
  status TEXT NOT NULL DEFAULT 'pending',     -- pending | accepted | rejected | converted
  converted_job_id UUID REFERENCES app.jobs(id),
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- app.chat_sessions (live chat from idhotshot.com)
CREATE TABLE app.chat_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  short_id TEXT UNIQUE NOT NULL,              -- 6-char alphanumeric, used in SMS routing
  visitor_name TEXT,
  visitor_phone TEXT,
  visitor_email TEXT,
  assigned_user_id UUID REFERENCES system.users(id),
  status TEXT NOT NULL DEFAULT 'open',        -- open | claimed | closed
  origin_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  closed_at TIMESTAMPTZ
);

CREATE TABLE app.chat_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  session_id UUID NOT NULL REFERENCES app.chat_sessions(id) ON DELETE CASCADE,
  sender_type TEXT NOT NULL,                  -- 'visitor' | 'employee' | 'system' | 'ai'
  sender_user_id UUID REFERENCES system.users(id),
  body TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

Enable RLS on every `app.*` table:
```sql
ALTER TABLE app.<table> ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON app.<table>
  USING (tenant_id = current_setting('app.current_tenant_id', true)::uuid);
```

Create a `BYPASSRLS` Postgres role for the superadmin connection (used only by Noble Glitch admin panel).

---

## BUILD ORDER — execute in this sequence with checkpoints

After EVERY checkpoint:
1. Run smoke tests
2. `git add -A && git commit -m "[checkpoint N] description"`
3. Append a clear status line to `/var/log/nobledispatch-build.log`
4. Move on

### Checkpoint 0 — Pre-flight verification
- Verify all required env vars present
- Verify DNS resolves
- Verify ports 3001 and 5432 are free (5432 only for local Docker network)
- Verify existing idhotshot.com responds with 200 at https://idhotshot.com
- Read `/root/idhotshot_site.html` to lock in design language
- `mkdir -p /opt/nobledispatch && cd /opt/nobledispatch`
- Initialize git, write .gitignore (include .env, node_modules, storage/, .next/)

### Checkpoint 1 — Project scaffold
- `pnpm create next-app@latest` with TypeScript, Tailwind, App Router, ESLint
- Install Drizzle, Better-Auth, BullMQ, ws, mapbox-gl, @googlemaps/google-maps-services-js, lucide-react, shadcn/ui
- Install shadcn components: button, input, dialog, dropdown, card, table, calendar, toast, badge, avatar
- Set up `drizzle.config.ts` and `lib/db.ts`
- Set up Tailwind config matching marketing site's color palette and font choices

### Checkpoint 2 — Docker Compose
- `docker-compose.yml` with: postgres:16, redis:7, app (built from project)
- `Dockerfile` for the Next.js app (multi-stage build, prod-optimized)
- Volumes for postgres data, redis data, app storage
- Health checks on all three services

### Checkpoint 3 — Database migrations
- Write all migrations matching the schema above
- Run migrations against the Docker postgres
- Seed system data:
  - One row in `system.tenants` for ID Hotshot (slug='idhotshot', primary_subdomain='nobledispatch.idhotshot.com')
  - One superadmin user (email = $SUPERADMIN_EMAIL, password = $INITIAL_ADMIN_PASSWORD)
  - One tenant_owner user for Danielle (email = $ADMIN_EMAIL, password = $INITIAL_ADMIN_PASSWORD, tenant = ID Hotshot)
  - One row in `app.tenant_settings` for ID Hotshot (use values from idhotshot_site.html — phone 520-239-9422, USDOT 4559278, primary color #d8232a, brand name "ID Hotshot Transportation")
  - System settings: noble_glitch_attribution_visible=true, noble_glitch_link from env
- Seed sample data for ID Hotshot: 2 trucks, 2 employees, 1 customer (so the UI isn't empty when Danielle logs in)
- Verify RLS by trying to query as different tenants

### Checkpoint 4 — Authentication
- Better-Auth configured with email + password
- Login page (use marketing site aesthetic — black background, red accents, Anton headings)
- Logout
- Password reset stub (sends to console log if RESEND_API_KEY missing — Phase 2 wires real email)
- Session middleware that sets `app.current_tenant_id` for every authenticated request
- Role-based route guards
- Test: superadmin sees /admin/superadmin, tenant_owner sees /admin, driver sees /driver, customer redirected to portal stub

### Checkpoint 5 — Layout, navigation, theming
- Three layout shells: `/admin/*` (dispatcher/owner), `/driver/*` (driver-mode-ready), `/superadmin/*` (Noble Glitch only)
- Sticky top nav with tenant logo, brand name, user avatar, notification bell
- Side nav with module icons (Jobs, Calendars, Map, Customers, Trucks, Employees, Messages, Documents, Settings)
- Apply tenant primary_color and accent_color via CSS variables read from /api/tenant
- "Powered by The Noble Glitch" footer (links to NOBLE_GLITCH_LINK)
- Driver layout is mobile-first: bottom tab nav, big touch targets, high contrast

### Checkpoint 6 — CRUD: Customers, Trucks, Employees
- List, create, edit, delete pages for each
- Search + sort
- Validation
- Audit log entries for every mutation
- For trucks: color picker for the calendar coding
- For employees: option to invite to login (creates system.users row, sends temp password)

### Checkpoint 7 — Jobs module
- List view (filterable by status, employee, truck, date range)
- Create job form: customer picker, pickup location (with autocomplete via Google Places), dropoff location, equipment type, dates/times, description
- On save: call Google Directions API, cache route_geojson and distance_miles
- Job detail page: full info, status workflow buttons, document upload, time entry log
- Auto-generate job_number: `IDH-YYYY-NNNN` (zero-padded sequence per tenant per year)
- Assign employee + truck (dropdowns of available ones)
- On assignment: auto-create calendar_events for the truck and the employee for the pickup window

### Checkpoint 8 — Calendars (4 views, one source of truth)
- Use a calendar component (full-calendar React or build with shadcn)
- Four views, all reading from `app.calendar_events`:
  - **Job Calendar**: all jobs, color-coded by truck
  - **Employee Calendar**: filtered to logged-in employee (or all employees as a grid view for admins)
  - **Truck Calendar**: each truck's blocks, with employee names labeled inside
  - **Admin Calendar**: shows everything + custom admin events (meetings, deadlines, etc.)
- Click a block → opens job detail
- Day/week/month switcher
- Mobile responsive (stacks to single column, horizontal scroll for week)

### Checkpoint 9 — Map module
- Mapbox GL JS map
- Layers: satellite, streets, dark mode (auto-switch by time of day, manual toggle)
- Plot all active jobs as pickup→dropoff routes
- Plot all employees' last known locations (when geolocation Phase 2 ships, this fills in)
- Click a pin → mini info card with link to job detail
- Trip planner: enter A and B, get route + distance + duration, "Save as Job" button → opens pre-filled job creation
- Match the brand: red routes, dark UI chrome

### Checkpoint 10 — Messaging
- Thread list (left sidebar)
- Thread view (center)
- Compose (bottom)
- Polling-based real-time for Phase 1 (every 5 sec); WebSocket upgrade in Phase 2
- Message types: standard, job_assigned (auto-sent on assignment), admin_call_request (priority alert)
- Notification bell in top nav with unread count
- Read receipts
- Quick-reply templates ("On my way", "Arrived", "Delayed 30 min", "Need help")

### Checkpoint 11 — Inbound request pipeline
- API endpoint `POST /api/inbound/booking` — accepts the marketing site's booking form payload
- API endpoint `POST /api/inbound/chat` — accepts chat messages, creates/updates chat_sessions
- Admin dashboard widget: "Inbound Queue" — lists pending requests, accept → converts to job (pre-fills form), reject → archives
- Configure idhotshot.com's existing site to POST to these endpoints (update its API routes — but DON'T touch its other code)

### Checkpoint 12 — Documents module
- File upload to `/opt/nobledispatch/storage/<tenant_id>/<doc_id>/<filename>`
- Attached to jobs, employees, or trucks
- Document types as listed in schema
- Download endpoint with auth check (only same-tenant users can download)
- Phase 2 swaps to S3-compatible — abstract this with a `StorageProvider` interface NOW so the swap is one file later

### Checkpoint 13 — Print-ready invoices
- PDF generation using puppeteer or @react-pdf/renderer
- Templates use `tenant_settings.letterhead_html` (defaults to a reasonable letterhead for ID Hotshot using their logo + USDOT)
- Standard fields: job number, customer, route, equipment, dates, line items, total, payment terms
- "Print" and "Download" buttons on job detail
- Save copy to documents table

### Checkpoint 14 — Tenant settings UI
- Tenant owner edits: brand name, logo upload, primary/accent colors, support phone/email, USDOT, MC, dispatch hours, letterhead
- Live preview of the changes (shows them what the login page / invoice header will look like)

### Checkpoint 15 — Superadmin (Noble Glitch) panel
- `/superadmin` route
- List all tenants, status, last activity
- Create new tenant flow: company info, owner email, generates invite link with temp password
- System settings: Noble Glitch attribution toggle, link, support contact
- Audit log viewer (cross-tenant)

### Checkpoint 16 — Nginx + SSL + production deployment
- Write `/etc/nginx/sites-available/nobledispatch` — server blocks for nobledispatch.idhotshot.com, reverse-proxy to localhost:3001
- Verify existing idhotshot.com server block is untouched (cat it, log it, do NOT modify)
- `nginx -t` to validate
- `certbot --nginx -d nobledispatch.idhotshot.com --non-interactive --agree-tos -m $ADMIN_EMAIL`
- Reload nginx
- `docker-compose up -d` to start the app
- Wait 30 seconds, curl https://nobledispatch.idhotshot.com — expect 200, login page renders
- Verify https://idhotshot.com STILL responds 200 (do not break the marketing site)

### Checkpoint 17 — Final smoke tests
Run end-to-end:
1. Visit https://nobledispatch.idhotshot.com → login page renders with brand colors
2. Login as Danielle ($ADMIN_EMAIL / $INITIAL_ADMIN_PASSWORD) → dashboard shows
3. Create a job → appears in all 4 calendars
4. Assign employee + truck → calendar updates with correct colors
5. Send a message → appears in recipient's thread
6. Submit a booking via idhotshot.com's form → appears in NobleDispatch inbound queue
7. Login as superadmin → sees all tenants list
8. Verify "Powered by The Noble Glitch" footer with link to thenobleglitch.com
9. Mobile view: open https://nobledispatch.idhotshot.com on a small viewport → driver layout renders correctly

### Checkpoint 18 — Wake-up package
Generate `/opt/nobledispatch/WAKE_UP_README.md` with:
- URLs (admin, login, superadmin)
- Credentials (with strong reminder to change INITIAL_ADMIN_PASSWORD)
- Status of every checkpoint (✅ or ⚠️ with explanation)
- Known issues / Phase 2 stubs that aren't wired
- How to view logs (`tail -f /var/log/nobledispatch-build.log`, `docker-compose logs -f`)
- How to restart the app
- How to roll back to a previous checkpoint (`git log`, `git reset`)
- A 3-line "what to test first" list for Danielle

---

## PHASE 1 SCOPE — what to BUILD vs what to STUB

### BUILD (Phase 1 — this session):
✅ Multi-tenant foundation (RLS, auth, tenant resolution)
✅ All 6 databases as CRUD pages
✅ Job creation + assignment + lifecycle
✅ 4 synced calendars
✅ Mapbox map + route trip planner
✅ Polling-based messaging
✅ Document upload + attachment
✅ Inbound queue (website booking → dispatch)
✅ Live chat session capture (UI shell, no SMS routing yet)
✅ Tenant settings + white-labeling
✅ Print-ready PDF invoices
✅ Superadmin panel (Noble Glitch)
✅ Nginx + SSL + Docker deployment
✅ Audit log

### STUB (Phase 1 creates the skeleton, Phase 2 fills in):
🔧 Real-time WebSocket (Phase 1 polls every 5sec)
🔧 SMS routing for chat → employee phone (Phase 1 saves messages, no Twilio yet)
🔧 AI extraction of inbound requests (Phase 1 stores raw_payload, manual entry)
🔧 Email sending (Phase 1 logs to console; Phase 2 wires Resend)
🔧 S3 storage abstraction (Phase 1 uses local disk via StorageProvider interface)
🔧 QuickBooks export (Phase 1 has the Pay Period table, Phase 2 wires the export)
🔧 Customer portal (Phase 1 stubs the route, Phase 2 builds the UI)

### DO NOT BUILD (Phase 2/3):
❌ Driver Mode (movement-locked screen)
❌ Text-to-speech notifications
❌ Geofencing
❌ Photo capture flow (basic upload works, geo-tagged photo capture is Phase 2)
❌ AI Assisted Dispatch (Twilio + Vapi)
❌ AI copilots throughout
❌ Payment processor integration
❌ Reporting/analytics dashboards
❌ Mobile push notifications
❌ Bluetooth audio routing UI

If you find yourself wanting to "just quickly add" any of these, **don't**. Stub them and move on. Phase 1 quality > Phase 1 scope creep.

---

## OUTPUT FORMAT FOR THE STATUS LOG

Every checkpoint writes a clear narrative entry. Example:

```
[2026-05-09 02:14:33] [CHECKPOINT 4] [START] Authentication module
[2026-05-09 02:14:35] [CHECKPOINT 4] [INFO] Better-Auth installed, configured for email+password
[2026-05-09 02:15:02] [CHECKPOINT 4] [INFO] Login page built, applied brand styles from tenant_settings
[2026-05-09 02:15:18] [CHECKPOINT 4] [INFO] Tenant resolution middleware writing app.current_tenant_id setting
[2026-05-09 02:15:44] [CHECKPOINT 4] [TEST] Smoke test: superadmin login → /superadmin (PASS)
[2026-05-09 02:15:48] [CHECKPOINT 4] [TEST] Smoke test: tenant_owner login → /admin (PASS)
[2026-05-09 02:15:52] [CHECKPOINT 4] [TEST] Smoke test: driver login → /driver (PASS)
[2026-05-09 02:16:01] [CHECKPOINT 4] [GIT] Committed 'auth foundation, RBAC routing, brand-themed login'
[2026-05-09 02:16:02] [CHECKPOINT 4] [DONE] ✅ 14 files changed, 312 insertions, 0 deletions
```

If anything fails, log:
```
[CHECKPOINT N] [ERROR] What failed, why, where, what you tried, what you decided to do
```

If you have to make a product decision the user should know about:
```
[CHECKPOINT N] [DECISION] Picked X over Y because Z. User should review.
```

---

## FINAL OUTPUTS Claude Code should produce

When done, the following must exist:

1. ✅ `https://nobledispatch.idhotshot.com` returns the login page over HTTPS
2. ✅ `https://idhotshot.com` still works exactly as before
3. ✅ `/opt/nobledispatch/` contains the project, git history, docker-compose.yml
4. ✅ `/var/log/nobledispatch-build.log` has a clean narrative of the build
5. ✅ `/opt/nobledispatch/WAKE_UP_README.md` has the wake-up package
6. ✅ Postgres + Redis + App containers running healthy
7. ✅ `/etc/nginx/sites-enabled/nobledispatch` exists, certbot cert active
8. ✅ ID Hotshot tenant exists with sample data, Danielle can log in and create a job

Final commit message: `[checkpoint 18] Phase 1 complete — wake-up package generated`

---

## ===== PROMPT END =====

## After Claude Code finishes — what to check

1. SSH in: `tail -50 /var/log/nobledispatch-build.log` — should end with checkpoint 18 ✅
2. `cat /opt/nobledispatch/WAKE_UP_README.md` — your full status report
3. Visit `https://nobledispatch.idhotshot.com` — login screen
4. Verify `https://idhotshot.com` still works
5. Login with `$ADMIN_EMAIL` / `$INITIAL_ADMIN_PASSWORD`, **change the password immediately**
6. Click around: create a test job, assign a truck, check the calendars

If something's broken: `cd /opt/nobledispatch && git log --oneline` shows every checkpoint as a commit. `git reset --hard <commit>` rolls back to any prior checkpoint.

If everything's good: text me (well, prompt me back here) and we plan Phase 2 — Driver Mode, TTS, real-time WebSocket, geofencing, photo capture, AI copilots.

---

**Created by The Noble Glitch · thenobleglitch.com · 2026**

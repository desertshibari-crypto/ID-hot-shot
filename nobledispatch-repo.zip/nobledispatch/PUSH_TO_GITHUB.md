# Pushing this to GitHub

Step-by-step instructions to get this repository onto your GitHub account as a **private** repo.

This assumes:

- You have a GitHub account (if not: sign up at https://github.com/signup)
- Git is installed on your computer (check by running `git --version` in your terminal; if not, install from https://git-scm.com/downloads)
- This `nobledispatch/` folder is extracted somewhere on your computer

---

## Step 1 — Create a new private repository on GitHub

1. Open https://github.com/new in your browser
2. Repository name: `nobledispatch` (or whatever you prefer)
3. Description (optional): "Multi-tenant trucking dispatch SaaS platform"
4. **Visibility: Private** (important — this contains business documents and unreleased platform IP)
5. **Do NOT** check any of the "Initialize this repository with..." boxes (no README, no .gitignore, no LICENSE — this folder already has them)
6. Click **Create repository**
7. GitHub will show you a setup page. Keep this tab open — you'll need the URL from it in Step 3.

---

## Step 2 — Initialize the local repo

Open your terminal and `cd` into the extracted `nobledispatch/` folder:

```bash
cd /path/to/nobledispatch
```

Initialize git, configure your identity if you haven't already, and make the first commit:

```bash
# Initialize
git init

# Tell git who you are (skip if already configured globally)
git config user.email "your-email@example.com"
git config user.name "Your Name"

# Stage everything
git add .

# Verify what you're about to commit
git status

# First commit
git commit -m "Initial commit — NobleDispatch project assembly"
```

---

## Step 3 — Connect to GitHub and push

On the GitHub setup page from Step 1, you'll see commands under the heading "...or push an existing repository from the command line". They look like this:

```bash
git remote add origin https://github.com/YOUR_USERNAME/nobledispatch.git
git branch -M main
git push -u origin main
```

Copy those three commands and run them in your terminal. The push will prompt for your GitHub credentials.

**If GitHub asks for a password and rejects it**: GitHub no longer accepts account passwords for git operations. You need a Personal Access Token instead:

1. Go to https://github.com/settings/tokens/new
2. Note: "git push for nobledispatch"
3. Expiration: 90 days (or whatever fits)
4. Scopes: check `repo` (full control of private repositories)
5. Click **Generate token** and copy the token value
6. Use the token as the password when git prompts you

Better long-term: set up SSH keys instead. Guide: https://docs.github.com/en/authentication/connecting-to-github-with-ssh

---

## Step 4 — Verify

Refresh your GitHub repository page. You should see all the files in the structure. Click around to confirm:

- `README.md` displays as the formatted overview
- `business/` shows the four PDFs
- `prompts/` shows the seven `.md` deployment prompts
- `website/idhotshot_site.html` is present
- `brand/` shows the five PNG files

---

## Future updates

When you change or add files in this folder, push them up like this:

```bash
git add .
git commit -m "Describe what changed"
git push
```

---

## A few good practices

1. **Keep it private.** This repo contains business documents (the service agreement, valuation, invoice with the friend coupon) that are sensitive. Don't switch it to public.

2. **Don't commit secrets.** If you ever add API keys, passwords, or `.env` files, the `.gitignore` will block most of them — but double-check `git status` before committing. If you accidentally commit a secret, rotate it immediately; removing it from git history afterward is messy.

3. **Don't put massive binaries in the repo.** GitHub's free tier supports files up to 100 MB. Larger assets (video, large datasets) belong in S3 / Backblaze / Drive, with links in the repo.

4. **Tag your milestones.** When you complete a meaningful step (e.g., Phase 1 deployed, first paying customer), tag it so you can reference that state later:

   ```bash
   git tag -a v0.1-phase1-deployed -m "Phase 1 live on Boston 2"
   git push --tags
   ```

5. **Branch for experiments.** When you're testing changes you might want to throw away:

   ```bash
   git checkout -b experiment-name
   # ... make changes ...
   git push -u origin experiment-name
   ```

   You can merge back to main later if it works, or just delete the branch.

---

That's it. The hard work was building the project; pushing to GitHub is the easy part.

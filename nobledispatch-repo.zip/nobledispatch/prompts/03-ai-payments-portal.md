# NobleDispatch — Phase 3 Deployment Prompt for Claude Code

**For:** Boston 2 VPS (continuing on Phases 1 + 2)
**Project root:** `/opt/nobledispatch` (existing)
**Phase:** 3 of 4 — AI Layer + Customer Portal + Payments + Reporting + Real-time Fleet Map
**Prerequisites:** Phases 1 AND 2 deployed, healthy, and verified in real use

---

## Honest read-this-first

This is the most complex phase of the four. AI features can hallucinate, cost money fast, and behave differently in production than in testing. Voice AI especially has latency, accuracy, and legal-recording considerations. Stripe Connect involves real money flowing through your platform.

**Two strong recommendations before running:**

1. **Run Phases 1 and 2 in production for at least a week before this one.** Watch how Danielle actually uses the system. The AI copilots will be 10x more useful if they're shaped by real workflow patterns.

2. **Phase 3 may not finish in one autonomous session.** It's larger than Phase 1 or 2 in scope, and AI integration is where things drift fastest. The prompt is structured so partial completion is recoverable — checkpoints commit independently and Phase 4 doesn't depend on Phase 3 being 100% done.

If you've read this and you still want to fire it tonight: keep going.

---

## How to run this

```bash
# 1. Verify Phases 1 and 2 are healthy
curl -I https://nobledispatch.idhotshot.com    # 200
curl -I https://idhotshot.com                  # 200
cd /opt/nobledispatch && git log --oneline | head -40   # all Phase 1 + 2 checkpoints

# 2. Add Phase 3 env vars to /root/nobledispatch.env (see PRE-FLIGHT)
nano /root/nobledispatch.env

# 3. Source and launch
source /root/nobledispatch.env
claude --dangerously-skip-permissions < /root/NOBLEDISPATCH_PHASE3_DEPLOY.md

# 4. Watch in another window:
tail -f /var/log/nobledispatch-build.log

# 5. Sleep. Check in the morning.
```

---

## PRE-FLIGHT — Phase 3 env vars

Append to `/root/nobledispatch.env`:

```bash
# === REQUIRED ===

# Anthropic API for AI copilots (https://console.anthropic.com/)
export ANTHROPIC_API_KEY="sk-ant-xxxxxxxxxxxxxxxxxxxxxxxx"
# Default model for routine tasks (cheap)
export ANTHROPIC_MODEL_FAST="claude-haiku-4-5-20251001"
# Premium model for complex extraction (smarter, costs more)
export ANTHROPIC_MODEL_SMART="claude-sonnet-4-6"

# Twilio (now required — Phase 1 stubbed it, Phase 3 wires it fully)
# https://console.twilio.com/
export TWILIO_ACCOUNT_SID="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
export TWILIO_AUTH_TOKEN="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
export TWILIO_FROM_NUMBER="+15551234567"        # purchased Twilio number with SMS + voice
export TWILIO_VOICE_NUMBER="+15551234567"       # can be same; this is what customers call

# Stripe Connect (https://dashboard.stripe.com/connect)
# Use TEST keys first — switch to live only when you've tested an end-to-end payment
export STRIPE_SECRET_KEY="sk_test_xxxxxxxxxxxxxxxxxxxxxxxx"
export STRIPE_PUBLISHABLE_KEY="pk_test_xxxxxxxxxxxxxxxxxxxxxxxx"
export STRIPE_WEBHOOK_SECRET="whsec_xxxxxxxxxxxxxxxxxxxxxxxx"
export STRIPE_CONNECT_CLIENT_ID="ca_xxxxxxxxxxxxxxxxxxxxxx"

# === REQUIRED FOR VOICE AI (Assisted Dispatch) ===

# Vapi (https://vapi.ai) — voice AI infrastructure
# Vapi handles the telephony bridge, transcription, TTS, latency optimization
export VAPI_PRIVATE_KEY="xxxxxxxxxxxxxxxxxxxxxxxx"
export VAPI_PUBLIC_KEY="xxxxxxxxxxxxxxxxxxxxxxxx"

# === COST CONTROLS — REQUIRED ===
export AI_TENANT_MONTHLY_CAP_USD="50"     # default per-tenant cap, owner can raise
export AI_USER_DAILY_CAP_USD="5"          # default per-user cap
export AI_VOICE_PER_CALL_CAP_USD="2"      # max spend on a single inbound call before fallback to human
export AI_LOG_ALL_CALLS="true"            # store full transcripts for audit

# === OPTIONAL ===

# OpenAI (fallback or alternative for some tasks)
export OPENAI_API_KEY=""

# Mapbox already set in Phase 1 — same key works for the live fleet map
```

Verify:
```bash
# Phase 1 + 2 services healthy
docker compose -f /opt/nobledispatch/docker-compose.yml ps

# Twilio inbound number is reachable (call it, hear default greeting)
# Stripe test mode confirmed
# Anthropic API key works:
curl https://api.anthropic.com/v1/messages -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" -H "content-type: application/json" \
  -d '{"model":"claude-haiku-4-5-20251001","max_tokens":10,"messages":[{"role":"user","content":"hi"}]}'
```

---

## ===== PROMPT BEGIN — EVERYTHING BELOW IS FOR CLAUDE CODE =====

You are extending **NobleDispatch** with Phase 3 — the AI layer, customer portal, payment processing, reporting, and the real-time fleet map. Phases 1 and 2 are deployed at `https://nobledispatch.idhotshot.com` and live. The first tenant is **ID Hotshot Transportation** (Danielle Riley, founder).

**This phase moves real money** (Stripe payments) and **costs real money on every call** (Anthropic API + Vapi voice). Build defensively. Cap costs hard. When in doubt about an AI response: hand off to a human, don't guess.

---

## HARD SAFETY RAILS — Phase 1 + 2 rules + new ones

All Phase 1/2 rails apply. Additions:

1. **AI cost guardrails are not optional.** Every call to Anthropic, Vapi, or any LLM must:
   - Check `tenant.ai_spend_this_month` against `AI_TENANT_MONTHLY_CAP_USD` (with tenant override) BEFORE the call
   - Increment a counter AFTER the call with the actual cost
   - Reject the call if cap is hit, with a clear UI message: "AI feature paused — monthly cap reached. Contact tenant owner to increase."
   - Default to `ANTHROPIC_MODEL_FAST` (Haiku) for everything except job extraction, which can opt into `ANTHROPIC_MODEL_SMART` if a checkbox is set
   - Log token counts + USD cost to `ai_usage` table for auditability

2. **AI never decides on actions that move money or commit obligations without human approval.** AI can SUGGEST a rate, AI can SUGGEST a driver assignment, AI can DRAFT a customer message — a human clicks "approve" before any of those become real.

3. **Voice AI must offer human handoff at any time.** "Press 0 or say 'human' to speak with dispatch." This is non-negotiable, both ethically and because some callers will refuse to talk to AI.

4. **Stripe is in TEST mode by default.** The deploy MUST start in test mode. There's a separate manual switch in superadmin settings to flip to live. Make this LOUD — banner in admin UI, "STRIPE TEST MODE — no real money is moving." When live, the banner inverts to a green confirmation.

5. **Recording disclosure is required.** Inbound voice calls must play a state-aware disclosure before recording: *"This call may be recorded for quality and training. Press 0 to speak with a human at any time."* Two-party-consent states (CA, FL, IL, MD, MA, MT, NV, NH, PA, WA + a few others) require explicit consent — the disclosure handles this.

6. **Customer portal is its own auth realm.** Customers do NOT log into the dispatch app. Customers log into `/portal` with separate session cookies, separate password rules (relaxed — they're not dispatchers), and STRICTLY scoped permissions. A customer should never be able to query data outside their own customer record. Test this explicitly — RLS policies need a customer-specific scope.

7. **Continue Phase 1/2 conventions:** git commits per checkpoint, status logging to `/var/log/nobledispatch-build.log`, additive-only migrations, verify Phase 1/2 functionality after every checkpoint.

8. **STOP conditions** for Phase 3:
   - Phases 1 or 2 stop responding
   - Anthropic API key invalid
   - Twilio number not yet provisioned/configured
   - Stripe keys invalid
   - Cost guardrails fail to register (would risk uncapped spend)
   - Customer portal RLS test fails (cross-customer data leak risk)

---

## STACK ADDITIONS for Phase 3

| Need | Choice | Why |
|---|---|---|
| LLM API | `@anthropic-ai/sdk` | First-party, well-supported |
| Voice AI | Vapi (REST + webhook) | Purpose-built for telephony, sub-1sec latency |
| SMS gateway | Twilio (`twilio` npm) | Industry standard |
| Payments | Stripe Connect | Tenants get their own Stripe accounts, payments flow to them |
| Charts | Recharts (already in Phase 1) | Reuse |
| Fleet map | Mapbox GL JS (already in Phase 1) | Reuse, add live position layer |
| Realtime fleet | Existing WebSocket from Phase 2 | Reuse |
| Email parsing | `mailparser` + Anthropic | Receive forwarded customer emails, parse to jobs |
| Cost tracking | Custom — log every API call to `ai_usage` table | Full audit trail |

---

## DATABASE MIGRATIONS — Phase 3 additions

All additive. New tables + columns. RLS enabled on all tenant-scoped tables.

```sql
-- Tenant-level AI configuration
ALTER TABLE app.tenant_settings ADD COLUMN ai_enabled BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE app.tenant_settings ADD COLUMN ai_monthly_cap_usd NUMERIC(10,2) DEFAULT 50.00;
ALTER TABLE app.tenant_settings ADD COLUMN ai_voice_enabled BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE app.tenant_settings ADD COLUMN ai_voice_assistant_id TEXT;       -- Vapi assistant ID
ALTER TABLE app.tenant_settings ADD COLUMN twilio_phone_number TEXT;          -- per-tenant inbound number (optional in Phase 3, plans for Phase 4)
ALTER TABLE app.tenant_settings ADD COLUMN stripe_account_id TEXT;            -- Stripe Connect account
ALTER TABLE app.tenant_settings ADD COLUMN stripe_account_status TEXT;        -- pending | enabled | restricted
ALTER TABLE app.tenant_settings ADD COLUMN stripe_payouts_enabled BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE app.tenant_settings ADD COLUMN stripe_charges_enabled BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE app.tenant_settings ADD COLUMN stripe_test_mode BOOLEAN NOT NULL DEFAULT true;

-- Customer-portal users (separate from dispatch users)
CREATE TABLE app.customer_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  customer_id UUID NOT NULL REFERENCES app.customers(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  password_hash TEXT,                    -- nullable: magic-link-only users have no password
  full_name TEXT NOT NULL,
  phone TEXT,
  is_primary BOOLEAN NOT NULL DEFAULT false,  -- the main contact
  is_active BOOLEAN NOT NULL DEFAULT true,
  last_login_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, email)
);
-- RLS: customer_users.id = current_setting('app.current_customer_user_id')::uuid OR
--      same tenant AS dispatch staff

-- AI usage tracking
CREATE TABLE app.ai_usage (
  id BIGSERIAL PRIMARY KEY,
  tenant_id UUID NOT NULL,
  user_id UUID,                          -- which user triggered (null for system tasks)
  feature TEXT NOT NULL,                 -- 'job_parser' | 'driver_suggester' | 'message_drafter' | 'voice_dispatch' | etc.
  model TEXT NOT NULL,
  input_tokens INTEGER NOT NULL DEFAULT 0,
  output_tokens INTEGER NOT NULL DEFAULT 0,
  cost_usd NUMERIC(10,6) NOT NULL DEFAULT 0,
  duration_ms INTEGER,
  status TEXT NOT NULL,                  -- 'success' | 'capped' | 'error'
  error_message TEXT,
  metadata JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON app.ai_usage (tenant_id, created_at DESC);
CREATE INDEX ON app.ai_usage (tenant_id, feature, created_at DESC);

-- Voice AI calls (Assisted Dispatch)
CREATE TABLE app.voice_calls (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  vapi_call_id TEXT UNIQUE,              -- Vapi's call ID
  twilio_call_sid TEXT UNIQUE,           -- Twilio's call SID
  direction TEXT NOT NULL,               -- 'inbound' | 'outbound'
  from_number TEXT,
  to_number TEXT,
  status TEXT NOT NULL,                  -- 'in_progress' | 'completed' | 'human_handoff' | 'failed' | 'voicemail'
  started_at TIMESTAMPTZ NOT NULL,
  ended_at TIMESTAMPTZ,
  duration_seconds INTEGER,
  transcript JSONB,                      -- array of {role, text, timestamp}
  recording_url TEXT,
  ai_summary TEXT,                       -- AI-generated post-call summary
  extracted_data JSONB,                  -- structured data the AI extracted (pickup, dropoff, etc.)
  resulting_inbound_request_id UUID REFERENCES app.inbound_requests(id),
  cost_usd NUMERIC(10,4),
  human_handoff_user_id UUID REFERENCES system.users(id),
  human_handoff_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON app.voice_calls (tenant_id, started_at DESC);

-- Invoices (Phase 1 has print-ready PDFs; Phase 3 makes them payable)
CREATE TABLE app.invoices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  invoice_number TEXT NOT NULL,
  customer_id UUID NOT NULL REFERENCES app.customers(id),
  job_id UUID REFERENCES app.jobs(id),
  amount_due NUMERIC(10,2) NOT NULL,
  amount_paid NUMERIC(10,2) NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'USD',
  status TEXT NOT NULL DEFAULT 'draft',  -- draft | sent | viewed | partial | paid | overdue | void
  issued_at TIMESTAMPTZ,
  due_at TIMESTAMPTZ,
  paid_at TIMESTAMPTZ,
  pdf_url TEXT,
  payment_link TEXT,                      -- Stripe Checkout / Payment Intent URL
  stripe_payment_intent_id TEXT,
  notes TEXT,
  line_items JSONB NOT NULL DEFAULT '[]',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, invoice_number)
);
CREATE INDEX ON app.invoices (tenant_id, status, due_at);
CREATE INDEX ON app.invoices (tenant_id, customer_id);

-- Stripe payment events (for reconciliation + audit)
CREATE TABLE app.payment_events (
  id BIGSERIAL PRIMARY KEY,
  tenant_id UUID,                        -- null only for platform-level events
  invoice_id UUID REFERENCES app.invoices(id),
  stripe_event_id TEXT UNIQUE NOT NULL,
  stripe_event_type TEXT NOT NULL,
  raw_payload JSONB NOT NULL,
  processed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Reporting cache (materialized snapshots for dashboards)
CREATE TABLE app.report_snapshots (
  id BIGSERIAL PRIMARY KEY,
  tenant_id UUID NOT NULL,
  report_type TEXT NOT NULL,             -- 'revenue_by_truck' | 'driver_scorecard' | 'customer_profitability' | etc.
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  data JSONB NOT NULL,
  generated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON app.report_snapshots (tenant_id, report_type, period_start);
```

---

## BUILD ORDER — execute with checkpoints

After EVERY checkpoint:
1. Smoke-test the new feature
2. Smoke-test that Phase 1 + 2 still work (login, jobs, calendars, Driver Mode, messaging)
3. Verify cost tracking is registering (where applicable)
4. `git add -A && git commit -m "[phase 3 / checkpoint N] description"`
5. Append status log entry
6. Continue

### Checkpoint 0 — Phase 1+2 health check + Phase 3 prereq verification
- Verify all Phase 1+2 services healthy
- Verify ALL required Phase 3 env vars set (Anthropic, Twilio, Stripe, Vapi, cost caps)
- Run a $0.001 test call to Anthropic API to confirm the key works (log it)
- Run a Twilio API health check (list account balance)
- Run a Stripe API health check (retrieve account)
- Apply all Phase 3 migrations
- Initialize cost tracking: each tenant gets a row in `ai_usage` for "month_init" with $0
- If anything fails: STOP, log clearly. Do not proceed without all integrations confirmed working.

### Checkpoint 1 — Real-time fleet map (admin)
- Route `/admin/fleet-map`
- Mapbox map (existing from Phase 1) with new layer: live driver positions
- Reads `employee_locations` table — most recent location per active employee in last 15 min
- WS subscription to `tenant:<id>:fleet` channel
- Phase 2's location updates broadcast to this channel; map updates live
- Pin per driver showing: avatar, name, current job (if any), speed, last update time
- Click pin → side panel: full job info, ETA, recent route polyline
- Filters: by truck, by status (in Driver Mode / idle / offline), by current job
- Drivers who haven't updated location in 1+ hour appear greyed out as "offline"
- Smoke test: in Driver Mode (Phase 2), drive simulation → admin map updates in real-time

### Checkpoint 2 — Live chat → SMS full Twilio integration
- Phase 1 created `chat_sessions` and `chat_messages` tables. Phase 3 wires SMS routing.
- Visitor sends chat message on idhotshot.com → already lands in NobleDispatch via Phase 1 webhook
- Phase 3 addition: Twilio outbound SMS to dispatcher's phone with format:
  ```
  [ID Hotshot Chat #ABC1] Visitor "John D" (5551234567):
  "Hey do you all do refrigerated trucking?"
  Reply to this msg, or text "#ABC1 ..." to route to specific session.
  Open: nobledispatch.idhotshot.com/admin/chat/ABC1
  ```
- Inbound webhook `/api/webhooks/twilio/sms` parses dispatcher's reply:
  - If body starts with `#XXXX` → route to that session
  - Else → route to MOST RECENT chat session that texted them within last 2 hours
  - Else → reply "No active chat session — visit /admin to assign"
- Reply text streams via WebSocket to visitor's open browser tab (existing chat widget)
- Session assignment: dispatcher in admin UI clicks "Claim" or auto-assigns based on round-robin
- Smoke test: open idhotshot.com chat as fake visitor, send message, verify dispatcher's phone receives SMS, reply, verify visitor sees it

### Checkpoint 3 — AI infrastructure foundation
- `lib/ai/client.ts` — Anthropic SDK wrapper that:
  1. Reads tenant's monthly cap before call
  2. Selects model (default: `ANTHROPIC_MODEL_FAST`)
  3. Makes the call
  4. Logs to `ai_usage` with token counts + cost
  5. Updates running tenant total
  6. Returns response or throws `AICapExceededError`
- `lib/ai/cost.ts` — pricing constants for current Anthropic models, cost calculation utility
- `lib/ai/prompts/` directory — every prompt template is a versioned file with metadata (purpose, expected input/output, last reviewed date)
- Generic helper: `await runAI({tenant, user, feature, model, system, messages, expectsJson})`
- Settings page section: "AI Features" — shows current month spend, monthly cap, per-feature breakdown, ability to enable/disable individual AI features
- Smoke test: send a prompt, verify response + cost log; deliberately exceed cap, verify rejection

### Checkpoint 4 — AI Copilot: Job Parser
- New action on inbound queue: "Parse with AI"
- Also accepts: paste raw email/SMS text → click "Extract job"
- Prompt template (`prompts/job_parser_v1.md`): instructs the model to extract:
  - Customer name, phone, email
  - Pickup address (street, city, state, zip)
  - Dropoff address
  - Pickup date/time (window if vague)
  - Dropoff date/time
  - Equipment type (with reasoning if ambiguous)
  - Weight, dimensions
  - Special instructions
  - Returns JSON with confidence scores per field
- Uses `ANTHROPIC_MODEL_SMART` (Sonnet) since extraction quality matters
- Pre-fills the job creation form; user reviews and edits before saving
- Confidence < 0.7 fields are highlighted yellow and require user confirmation
- Smoke test: paste a real-style customer email, verify extracted fields land in form

### Checkpoint 5 — AI Copilot: Smart Driver Assignment
- When creating/assigning a job, "Suggest a driver" button
- Prompt template considers:
  - Each available driver's recent location (closest to pickup)
  - Current Driver Mode status (don't suggest someone in the middle of another job)
  - Historical on-time % per driver (from `pay_periods` aggregation)
  - HOS compliance (driver's hours this week — use placeholder for Phase 3, full ELD integration is a separate project)
  - CDL endorsements vs job requirements
  - Equipment compatibility
- Returns top 3 drivers with reasoning for each
- Uses `ANTHROPIC_MODEL_FAST` (this is more deterministic logic with light reasoning, Haiku is fine)
- Dispatcher can accept a suggestion or override
- Smoke test: create a test job with assigned drivers having varied current locations, verify ranked suggestions

### Checkpoint 6 — AI Copilot: Route Optimizer (multi-stop)
- For days where a driver has 3+ jobs, "Optimize route order" button
- Sends jobs' pickup/dropoff coordinates + time windows to AI
- Returns suggested order with reasoning, total miles saved estimate
- Dispatcher can apply the suggestion or revert
- This is a "nice-to-have" — keep the AI prompt focused. Don't try to be Google's routing engine.
- Smoke test: create 3 jobs in different cities for same driver/day, verify optimization suggestion

### Checkpoint 7 — AI Copilot: Inbound Triage
- Background task (BullMQ) runs every 30 seconds on `inbound_requests` with status='pending' that haven't been triaged
- AI assigns: urgency (low/medium/high/critical), suggested rate range, equipment match, completion confidence
- Surfaced in admin dashboard inbound queue: badge color, sort by urgency
- Uses `ANTHROPIC_MODEL_FAST`
- Smoke test: insert a few fake inbound requests with varied urgency, verify triage labels them correctly

### Checkpoint 8 — AI Copilot: Customer Message Drafter
- In any chat thread, "Draft reply" button
- Sends recent message context + tenant brand voice ("friendly, direct, trucking-industry") to AI
- Returns draft text in the input field; dispatcher edits and sends
- Saves dispatchers from blank-page paralysis on common questions
- Uses `ANTHROPIC_MODEL_FAST`
- Smoke test: open a chat with a few messages, click Draft, verify a reasonable draft appears

### Checkpoint 9 — Voice AI infrastructure (Vapi)
- Vapi agent configuration via API:
  - Voice: warm, professional female (Vapi has presets — pick "Sarah" or equivalent)
  - First message: "Thanks for calling [tenant brand_name]. This is the AI dispatcher — I can help you book a load or take a quote, or you can press 0 anytime for a human. How can I help today?"
  - System prompt: detailed instructions to extract job details (similar to Job Parser), quote rates using tenant's rate calculator logic, escalate to human on any ambiguity or request
  - Functions: `look_up_rate(equipment, miles)`, `check_availability(date)`, `submit_inbound_request(...)`, `transfer_to_human()`, `take_voicemail()`
  - Recording: enabled, with mandatory disclosure played first
  - Max call duration: 8 minutes (configurable per tenant)
- Webhook from Vapi to `/api/webhooks/vapi` for call events: started, ended, function-called, transcript-update
- Webhook from Twilio: configured to forward inbound calls to Vapi's SIP/HTTP endpoint
- Voicemail fallback: if AI fails or hits cap, take voicemail and SMS the dispatcher
- Cost tracking per call against `AI_VOICE_PER_CALL_CAP_USD`
- Smoke test: configure a test Twilio number, call it, verify AI answers, request human transfer, verify it routes to dispatcher

### Checkpoint 10 — Assisted Dispatch — call handling + post-call
- Inbound call → Vapi handles conversation → submits structured data via `submit_inbound_request` function
- Server creates `inbound_requests` row with parsed_payload populated by AI
- Creates `voice_calls` row with full transcript and recording URL
- AI generates post-call summary (separate Anthropic call): 2-3 sentences for the dispatcher's queue view
- Dispatcher sees the call in inbound queue with audio playback, transcript, AI summary, and a "Convert to Job" button (pre-fills job form)
- All voice calls visible in `/admin/calls` route — list, filter, listen, search transcripts
- Smoke test: full inbound call → dispatcher reviews → converts to job → verify everything threaded together

### Checkpoint 11 — Customer portal foundation
- New route group `/portal/*` — separate auth realm
- Login at `/portal/login` (visually distinct from dispatch login — softer, customer-facing)
- Auth options:
  - Password (if customer set one)
  - Magic link via email (default — customers shouldn't need to remember another password)
- Layout: simplified nav (Dashboard, Loads, Invoices, Documents, Contact)
- Tenant brand applied (logo, colors)
- Footer: "Powered by [tenant brand_name] using NobleDispatch by The Noble Glitch"
- Customer onboarding: dispatcher clicks "Create portal access" on customer record → emails magic-link invite → customer sets up account
- Hard test: customer A cannot access customer B's data (cross-customer query attempts MUST fail)
- Smoke test: full flow — invite, login, dashboard renders with their data only

### Checkpoint 12 — Customer portal: Loads in flight
- `/portal/loads` lists customer's loads (active, scheduled, completed)
- Detail view: pickup/dropoff, status, ETA, driver name (configurable per tenant whether to show)
- Map view: live truck position (reuses fleet map data, scoped to this customer's active jobs)
- Communication: customer can message dispatch from this page (creates a chat session)
- Smoke test: customer logs in, sees their loads, opens map, sees live truck position

### Checkpoint 13 — Customer portal: Self-service booking
- `/portal/book` — same form as the marketing site booking, pre-filled with customer info
- Submits to `inbound_requests` with `source='customer_portal'`, `customer_id` set
- Triggers AI triage (Checkpoint 7) automatically
- Customer sees confirmation: "Request received — dispatcher will confirm within 1 hour"
- Tenant setting to require dispatcher approval vs. instant-book (Phase 3 default: requires approval)
- Smoke test: customer submits booking, dispatcher gets notified, accepts, customer sees confirmation

### Checkpoint 14 — Customer portal: Invoices + documents
- `/portal/invoices` lists customer's invoices, status, amount, due date
- "Pay Now" button on unpaid invoices → Stripe Checkout (set up in checkpoint 16)
- Download PDF
- Past invoice history with full detail
- `/portal/documents` lists BOLs, PODs, signed delivery receipts for this customer's loads
- Download with auth check (RLS scoped to this customer)
- Smoke test: customer sees their invoices, downloads a PDF, sees the documents

### Checkpoint 15 — Stripe Connect onboarding
- Tenant settings → Payments tab → "Connect Stripe Account" button
- OAuth flow: tenant_owner clicks → redirected to Stripe Connect onboarding → completes KYC → returns to NobleDispatch
- Saves `stripe_account_id`, `stripe_account_status`, `stripe_payouts_enabled`, `stripe_charges_enabled`
- Webhook subscribes to: `account.updated`, `account.application.deauthorized`, `payment_intent.succeeded`, `payment_intent.payment_failed`, `charge.refunded`
- Webhook signature verification using `STRIPE_WEBHOOK_SECRET`
- HUGE BANNER in admin UI: "STRIPE TEST MODE" until tenant_owner explicitly switches to live (separate confirmation modal)
- Smoke test: complete test-mode onboarding for ID Hotshot, verify saved + can create test payment intent

### Checkpoint 16 — Invoice payments via Stripe
- Convert existing `app.jobs` rate_final into `app.invoices` records on job completion
- Auto-generate invoice number per tenant: `IDH-INV-YYYY-NNNN`
- Generate Stripe Payment Intent at invoice creation, save `payment_link`
- Email invoice to customer with payment link (uses Phase 2 email infra)
- Customer portal "Pay Now" → Stripe Checkout in tenant's Connect account context
- Webhook handler updates `invoices.amount_paid`, `paid_at`, `status`; logs to `payment_events`
- Reconciliation export: "Settlement report" CSV per period for the tenant
- Failed payment: email customer + dispatcher, retry logic per tenant settings
- Refund flow: dispatcher clicks "Refund" on invoice → confirms amount → Stripe API → webhook updates state
- Smoke test: full payment flow in test mode (Stripe test card `4242 4242 4242 4242`), verify everything updates

### Checkpoint 17 — Reporting: Revenue + utilization dashboards
- `/admin/reports` route, gated to tenant_owner + accountant + dispatcher
- Date range picker (preset: this week, last week, this month, last month, this quarter, YTD, custom)
- Cards (top of page):
  - Total revenue (paid invoices)
  - Outstanding (unpaid invoices)
  - Jobs completed
  - Total miles
  - Average rate per mile
  - Average margin per job (revenue - estimated costs; estimated cost = fuel + driver pay; configurable fuel cost per mile in tenant settings)
- Charts (Recharts):
  - Revenue over time (line)
  - Jobs by equipment type (pie)
  - Top customers by revenue (bar)
  - Truck utilization % (bar — based on calendar block density)
  - On-time delivery % (line)
- Snapshot cache: server pre-computes aggregations daily into `report_snapshots` for fast dashboard loads
- Export: any chart → CSV
- Smoke test: load reports for ID Hotshot with sample data, verify numbers add up

### Checkpoint 18 — Reporting: Driver scorecards + customer profitability
- `/admin/reports/drivers` — per-driver: jobs completed, miles, on-time %, avg margin, customer feedback (Phase 4)
- Sortable, with date range filter
- Click driver → individual drilldown
- `/admin/reports/customers` — per-customer: total revenue, total jobs, avg job value, on-time %, payment timeliness (avg days to pay)
- Color-coded profitability: top 20% green, middle 60% gray, bottom 20% red
- Helps tenant_owner see which customers are worth keeping vs. firing
- Smoke test: verify scorecards compute correctly with sample data

### Checkpoint 19 — Final integration tests + wake-up package

End-to-end Phase 3 scenarios:

**Scenario A: AI-handled inbound call**
1. External party calls Twilio number → Vapi answers → AI extracts job → submits inbound_request
2. AI triage marks it "high urgency"
3. Dispatcher sees it in queue with summary, transcript playback
4. Dispatcher clicks "Suggest driver" → AI ranks 3 drivers
5. Dispatcher accepts top suggestion → job created → driver gets push + TTS
6. Driver completes job (Phase 2 flow)
7. Invoice auto-created → emailed to customer
8. Customer logs into portal → pays via Stripe → webhook updates invoice
9. Tenant_owner runs report → revenue counted

**Scenario B: Cross-customer security**
1. Customer A logs in → tries to access `/api/loads/<customer-B-job-id>` → 403
2. Customer A modifies URL/payload to claim other tenant_id → still 403
3. Verify RLS policy prevents data leak even if app-level check fails

**Scenario C: Cost cap behavior**
1. Mock tenant at 99% of monthly cap
2. Trigger AI feature → succeeds
3. Trigger again → succeeds, hits 100%
4. Trigger third time → rejected with "Cap reached" UI message
5. Tenant_owner increases cap → next trigger succeeds again

Update `/opt/nobledispatch/WAKE_UP_README.md` with Phase 3 section:
- Status of every checkpoint
- Stripe TEST mode reminder + how to switch to live
- Anthropic + Vapi monthly cost projections at current usage
- New routes (admin reports, customer portal, voice calls dashboard)
- Phase 4 stubs

Final commit: `[phase 3 / checkpoint 19] Phase 3 complete — AI layer + customer portal + payments + reporting live`

---

## PHASE 3 SCOPE — what to BUILD vs PHASE 4

### BUILD (Phase 3 — this session):
✅ Real-time admin fleet map
✅ Live chat → SMS full Twilio integration
✅ AI cost-control infrastructure
✅ AI: Job parser (email/SMS → job)
✅ AI: Smart driver assignment suggestions
✅ AI: Route optimizer (multi-stop)
✅ AI: Inbound triage
✅ AI: Customer message drafter
✅ Voice AI: Assisted Dispatch (Vapi)
✅ Customer portal: auth, loads, booking, invoices, documents
✅ Stripe Connect onboarding
✅ Invoice payment flow + webhooks + refunds
✅ Reporting: revenue + utilization + driver scorecards + customer profitability

### DO NOT BUILD (Phase 4 — multi-tenant scaling & sales):
❌ nobledispatch.com marketing site
❌ Custom domain UI for white-label tenants (database is ready, UI not yet)
❌ Tenant onboarding wizard (self-service signup for new trucking companies)
❌ Platform-level billing (Noble Glitch billing the tenants, recurring SaaS)
❌ Sales materials, pitch deck, ROI calculator
❌ Multi-region deployment / CDN
❌ Advanced compliance (HIPAA, SOC 2, etc.)
❌ Mobile-native apps (React Native — PWA covers most use cases for now)
❌ Customer feedback / review collection post-delivery
❌ ELD integration (Hours of Service compliance — separate project, partner with KeepTruckin/Samsara)

If you find yourself drifting toward any of these, stop and stub it for Phase 4.

---

## OUTPUT FORMAT FOR THE STATUS LOG

Continue the format from Phases 1+2 with `[PHASE 3 / CHECKPOINT N]` tag.

Example with cost annotation:
```
[2026-06-02 02:14:33] [PHASE 3 / CHECKPOINT 4] [START] AI Job Parser
[2026-06-02 02:14:51] [PHASE 3 / CHECKPOINT 4] [INFO] Prompt template v1 saved to prompts/job_parser_v1.md
[2026-06-02 02:15:08] [PHASE 3 / CHECKPOINT 4] [TEST] Test extraction from sample email — confidence 0.92 across all fields (PASS)
[2026-06-02 02:15:09] [PHASE 3 / CHECKPOINT 4] [COST] Test call: 432 input tokens, 187 output, $0.0021
[2026-06-02 02:15:18] [PHASE 3 / CHECKPOINT 4] [TEST] Phase 1+2 regression — login + Driver Mode (PASS)
[2026-06-02 02:15:25] [PHASE 3 / CHECKPOINT 4] [GIT] Committed
[2026-06-02 02:15:26] [PHASE 3 / CHECKPOINT 4] [DONE] ✅
```

---

## FINAL OUTPUTS Claude Code should produce

1. ✅ All Phase 1 + 2 functionality remains working
2. ✅ Phase 3 features live at `https://nobledispatch.idhotshot.com`
3. ✅ `/var/log/nobledispatch-build.log` has clean Phase 3 narrative
4. ✅ `/opt/nobledispatch/WAKE_UP_README.md` updated with Phase 3 section + clear cost projections
5. ✅ Git history shows all Phase 3 checkpoints
6. ✅ Stripe is in TEST mode — banner is loud
7. ✅ Test transactions confirmed working
8. ✅ AI cost guardrails verified by deliberately triggering rejection
9. ✅ Cross-customer security verified by failed access test

---

## ===== PROMPT END =====

## After Claude Code finishes — what to check

1. **SSH in:** `tail -150 /var/log/nobledispatch-build.log` — should end with Phase 3 checkpoint 19 ✅
2. **Read** `/opt/nobledispatch/WAKE_UP_README.md` Phase 3 section
3. **Test the AI Assisted Dispatch:** call the Twilio number — does it answer? Does it ask reasonable questions? Does pressing 0 transfer to a human?
4. **Test the customer portal:** create a test customer, send yourself an invite, log in, verify you only see that customer's data
5. **Test a Stripe payment in TEST mode:** generate an invoice, click pay, use test card 4242, verify webhook updates
6. **Check AI costs:** `/admin/settings/ai` — what did the build session itself spend? Set the monthly cap to a comfortable number (default $50 is conservative)
7. **Don't switch Stripe to LIVE mode** until you've tested an end-to-end real payment flow with a small dollar amount and confirmed everything reconciles

---

## What's left after Phase 3 — Phase 4

When you're ready to actually start selling NobleDispatch as a product to other trucking companies:

**Phase 4 — Multi-tenant scaling & sales:**
- `nobledispatch.com` marketing site (the "buy NobleDispatch" funnel)
- Self-service tenant signup wizard (new company → trial account → paid)
- Platform billing engine (Stripe subscriptions for tenants paying YOU monthly)
- Custom domain mapping UI (tenants point their own domains at NobleDispatch)
- Sales pages, pricing page, demo videos, ROI calculator
- Onboarding checklist for new tenants
- Migration tools (when a customer wants to move to their own VPS — the portability you architected in Phase 1 cashes in here)
- Status page (uptime, incidents) at `status.nobledispatch.com`
- Documentation site for tenant admins

**Honest cost discussion:**
At Phase 3 deployed, your monthly running costs roughly:
- Hostinger KVM8: $10–25 depending on plan
- Mapbox: free under 50K loads/mo, scales with usage
- Google Maps Directions: ~$5/mo at ID Hotshot's volume
- Anthropic API: $20–80/mo depending on AI feature usage (the cap controls this)
- Vapi: ~$0.07/min of voice AI = $20–60/mo at Danielle's call volume
- Twilio: ~$1/mo number + $0.0075/SMS + $0.014/min voice = $10–30/mo
- Resend: free under 3K/mo, ID Hotshot probably stays free
- Stripe: 2.9% + 30¢ per transaction (paid by tenant, not you, in Connect model)

**Total: $65–195/mo to run NobleDispatch + ID Hotshot.** When you have 10 tenants paying you $200/mo, you're at ~$2K/mo revenue against costs that scale sub-linearly. Solid SaaS economics.

---

**Created by The Noble Glitch · thenobleglitch.com · 2026**

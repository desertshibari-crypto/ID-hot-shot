# Business Documents

The legal, financial, and strategic documents for the NobleDispatch project. These are the documents you'd hand to an attorney, accountant, banker, or potential buyer.

## Files

| File | What it is |
|---|---|
| `Project_Brief.pdf` | The complete project overview — what's being built, in what phases, what it costs, what it's worth, and how to commercialize it. The primary document to read first. |
| `Service_Agreement.pdf` | The contract between The Noble Glitch and ID Hotshot covering payment options (Options A through E), intellectual property assignment, training, hosting, and post-handoff support. Has signature lines. |
| `Value_Estimation.pdf` | A realistic, comparables-based valuation analysis showing what the platform adds to ID Hotshot's business and what it would sell for under different scenarios (whole business, IP only, mature SaaS). |
| `Invoice.pdf` | The invoice with the full discount math shown transparently: market value → 25% below-market adjustment → HOMIE-FOR-LIFE coupon → final due. |

## Editable source files

The HTML source files for every PDF are in `source-html/`. Edit those if you need to update any document, then regenerate the PDF:

```bash
# Requires wkhtmltopdf installed
wkhtmltopdf --enable-local-file-access \
  --margin-top 12mm --margin-bottom 12mm --margin-left 14mm --margin-right 14mm \
  --page-size Letter \
  source-html/Project_Brief.html \
  Project_Brief.pdf
```

Same pattern for the other three documents.

## Honest notes

These documents represent a substantial amount of professional work — a contract with real intellectual property assignment language, a valuation with comparable data, an invoice with custom-applied discounts. But they are:

- **Not certified.** The valuation is not a formal business appraisal. The contract has not been reviewed by an attorney. Get professional review before signing or relying on these for anything legally or financially binding. Cost: usually $200–$500 for legal review, $3,000–$15,000 for a formal valuation if you need one for litigation or a bank.

- **Templates worth refining.** Each document has been built to a high standard but every contract benefits from attorney review for the specific jurisdiction and situation. Each valuation benefits from a qualified appraiser if the stakes are real.

These are the strongest starting points possible, not the finish line.

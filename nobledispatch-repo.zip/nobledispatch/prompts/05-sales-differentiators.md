# NobleDispatch — Phase 5 Deployment Prompt for Claude Code

**For:** Boston 2 VPS (continuing on Phases 1, 2, 3, 4)
**Project root:** `/opt/nobledispatch` (existing)
**Phase:** 5 of 5 — Sales Differentiators: POD-to-Invoice, ELD, IFTA, Marketing
**Prerequisites:** Phases 1–4 deployed and healthy. Ideally Phase 4 marketing site live, at least one paying tenant beyond ID Hotshot.

---

## Why this phase exists and what it ISN'T

Phase 5 is different from Phases 1–4. The first four phases built the platform. Phase 5 builds **the features that close more deals**, based on what's actually selling in the 2026 small-fleet TMS market.

Three things this phase deliberately is NOT:

1. **Not a sprawl.** Four focused features, five checkpoints. If a feature isn't in this prompt, it isn't in Phase 5. Resist scope creep.
2. **Not infrastructure.** Almost everything uses existing Phase 1–4 infrastructure. No new databases, no new services, no new auth flows. Just bridges between things that already exist.
3. **Not for tenants who aren't paying.** Each feature ships gated to the tier that should get it (Pro and above for ELD, Growth and above for IFTA, all paid tiers for POD-to-Invoice).

The four features:

1. **POD-to-Invoice automation pipeline** — the killer feature; uses Phase 2 photo capture + Phase 3 AI + Phase 3 invoicing
2. **ELD integration (Motive first, Samsara second)** — legally required for half your target market
3. **IFTA fuel tax reporting** — quarterly pain point, real $/value differentiator
4. **Marketing site copy update** — leads with these new features

---

## How to run this

```bash
# 1. Verify Phases 1–4 healthy
curl -I https://nobledispatch.idhotshot.com
curl -I https://idhotshot.com
curl -I https://nobledispatch.com
cd /opt/nobledispatch && git log --oneline | head -80

# 2. Add Phase 5 env vars to /root/nobledispatch.env
nano /root/nobledispatch.env

# 3. Source and launch
source /root/nobledispatch.env
claude --dangerously-skip-permissions < /root/NOBLEDISPATCH_PHASE5_DEPLOY.md

# 4. Watch
tail -f /var/log/nobledispatch-build.log
```

---

## PRE-FLIGHT — Phase 5 env vars

Append to `/root/nobledispatch.env`:

```bash
# === REQUIRED ===

# Motive (ELD provider — register for API access at https://developer.gomotive.com/)
# OAuth flow — these are your app credentials, not tenant credentials
export MOTIVE_CLIENT_ID="xxxxxxxx"
export MOTIVE_CLIENT_SECRET="xxxxxxxx"
export MOTIVE_REDIRECT_URI="https://nobledispatch.idhotshot.com/api/integrations/motive/callback"

# AI vision pricing controls (BOL extraction uses Claude vision = more $/call than text)
export AI_POD_AUTO_SEND_THRESHOLD_USD="500"        # invoices below this auto-send; above requires dispatcher approval
export AI_POD_DAILY_PER_TENANT_CAP="100"           # max BOL extractions per tenant per day (sanity limit)
export AI_VISION_MODEL="claude-sonnet-4-6"          # vision-capable model

# === OPTIONAL — graceful degradation if missing ===

# Samsara (second ELD provider — register at https://developers.samsara.com/)
export SAMSARA_CLIENT_ID=""
export SAMSARA_CLIENT_SECRET=""
export SAMSARA_REDIRECT_URI="https://nobledispatch.idhotshot.com/api/integrations/samsara/callback"

# Geotab (third — only if asked for)
export GEOTAB_API_KEY=""
```

Verify before running:

```bash
# Motive API reachable with credentials
curl -X POST https://api.gomotive.com/oauth/token \
  -d "grant_type=client_credentials&client_id=$MOTIVE_CLIENT_ID&client_secret=$MOTIVE_CLIENT_SECRET"
# Should return an access_token
```

---

## ===== PROMPT BEGIN — EVERYTHING BELOW IS FOR CLAUDE CODE =====

You are completing **NobleDispatch Phase 5** — the sales differentiator layer. Phases 1–4 are deployed and healthy. The first tenant (ID Hotshot Transportation) is live, and per the platform roadmap, additional tenants are signing up via nobledispatch.com.

Your job is to ship four focused features that turn NobleDispatch from "great platform" into "the obvious pick" for small fleets. **Stay focused.** This phase has fewer checkpoints than prior phases on purpose. Quality and tight scope matter more than breadth.

---

## HARD SAFETY RAILS — Phase 1–4 rules + Phase 5 additions

All prior rails apply. Phase 5 additions:

1. **AI vision is expensive.** Vision API calls (BOL extraction) cost roughly 3–10x what text calls cost. The cost guardrails from Phase 3 must apply to vision calls, plus the new per-tenant daily cap (`AI_POD_DAILY_PER_TENANT_CAP`). If the cap is hit, fall back to manual invoice creation with the photo attached for human review.

2. **POD extraction never auto-sends invoices above the threshold.** Invoices below `$AI_POD_AUTO_SEND_THRESHOLD_USD` (default $500) can auto-send. Above that, the invoice is created in `draft` status with the AI extraction visible and a dispatcher must approve and click Send. This is non-negotiable — auto-sending a wrong $5,000 invoice to a customer is a relationship-ending bug.

3. **ELD data is read-only.** NobleDispatch never modifies ELD records. ELD systems are the federally-required system of record for HOS compliance. We read their data and display it. We do not write to them. Ever.

4. **HOS suggestions never block driver assignment.** The dispatcher always has the final call. If the driver doesn't have enough hours per ELD data, we surface a clear WARNING ("Driver shows 2.5 hours remaining — this 6-hour run will exceed HOS") but the dispatcher can still assign if they have reason (e.g., driver is in their truck right now and ELD hasn't updated). Surface, don't block.

5. **IFTA report math must be auditable.** Every number in the generated IFTA report must trace back to specific job route segments and specific fuel purchases. The report PDF includes a detail appendix showing every input that produced every total. Tax authorities can audit; we need to be defensible.

6. **STOP conditions** for Phase 5:
   - Any Phase 1–4 service unhealthy
   - Motive API credentials invalid
   - AI vision cost guardrails fail to register
   - Database migrations fail
   - Existing POD photo upload (Phase 2) is broken

---

## STACK — almost everything reused

| Need | Choice | Notes |
|---|---|---|
| AI vision | `@anthropic-ai/sdk` with `claude-sonnet-4-6` model | Existing Phase 3 client, just enable vision content blocks |
| Motive integration | Direct REST calls + OAuth2 | No SDK needed; well-documented API |
| Samsara integration | Direct REST calls + OAuth2 | Same pattern as Motive |
| IFTA route splitting | PostGIS + Google Directions polyline data (already cached) | Compute miles per jurisdiction from existing route_geojson |
| PDF generation | `@react-pdf/renderer` (already in Phase 1) | Reuse for IFTA reports |
| Marketing copy | MDX files in `content/` (already in Phase 4) | Edit existing pages |

---

## DATABASE MIGRATIONS — Phase 5 additions (small)

All additive. Most logic uses existing tables.

```sql
-- ELD provider connections per tenant
CREATE TABLE app.eld_integrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  provider TEXT NOT NULL,                       -- 'motive' | 'samsara' | 'geotab'
  access_token TEXT NOT NULL,                   -- encrypted
  refresh_token TEXT,                           -- encrypted
  token_expires_at TIMESTAMPTZ,
  account_id TEXT,                              -- provider's tenant ID
  account_name TEXT,
  status TEXT NOT NULL DEFAULT 'active',        -- active | error | disconnected
  last_sync_at TIMESTAMPTZ,
  last_error TEXT,
  connected_by UUID REFERENCES system.users(id),
  connected_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, provider)
);

-- Driver HOS snapshots (we cache; don't query ELD every render)
CREATE TABLE app.driver_hos_status (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  employee_id UUID NOT NULL REFERENCES app.employees(id) ON DELETE CASCADE,
  eld_provider TEXT NOT NULL,
  eld_driver_id TEXT NOT NULL,                  -- the provider's driver ID
  current_status TEXT,                          -- 'off_duty' | 'sleeper' | 'driving' | 'on_duty'
  driving_hours_remaining NUMERIC(4,2),         -- 11-hour rule
  duty_hours_remaining NUMERIC(4,2),            -- 14-hour rule
  cycle_hours_remaining NUMERIC(5,2),           -- 70-hour rule
  next_break_required_at TIMESTAMPTZ,
  fetched_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  raw_payload JSONB
);
CREATE INDEX ON app.driver_hos_status (tenant_id, employee_id, fetched_at DESC);

-- Match an employee to their ELD identity (configured by tenant)
ALTER TABLE app.employees ADD COLUMN eld_driver_id TEXT;
ALTER TABLE app.employees ADD COLUMN eld_vehicle_id TEXT;

-- POD extractions (audit trail for every AI-extracted BOL)
CREATE TABLE app.pod_extractions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  job_id UUID NOT NULL REFERENCES app.jobs(id) ON DELETE CASCADE,
  document_id UUID NOT NULL REFERENCES app.documents(id),
  extracted_data JSONB NOT NULL,                -- what AI returned
  confidence_overall NUMERIC(3,2),              -- 0.00 to 1.00
  matched_job_confidence NUMERIC(3,2),
  amount_extracted NUMERIC(10,2),
  invoice_id UUID REFERENCES app.invoices(id),
  auto_send_eligible BOOLEAN NOT NULL DEFAULT false,
  status TEXT NOT NULL DEFAULT 'pending',       -- pending | approved | sent | rejected | failed
  reviewed_by UUID REFERENCES system.users(id),
  reviewed_at TIMESTAMPTZ,
  cost_usd NUMERIC(10,6),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Fuel purchases (for IFTA)
CREATE TABLE app.fuel_purchases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  truck_id UUID REFERENCES app.trucks(id),
  employee_id UUID REFERENCES app.employees(id),
  purchase_date DATE NOT NULL,
  jurisdiction TEXT NOT NULL,                   -- state/province code: 'AZ', 'CO', 'CA', 'ON'
  gallons NUMERIC(8,3) NOT NULL,
  price_per_gallon NUMERIC(6,3),
  total_cost NUMERIC(10,2),
  receipt_document_id UUID REFERENCES app.documents(id),
  fuel_card_provider TEXT,                      -- 'comdata' | 'efs' | 'manual' | etc.
  fuel_card_transaction_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON app.fuel_purchases (tenant_id, purchase_date);
CREATE INDEX ON app.fuel_purchases (tenant_id, jurisdiction, purchase_date);

-- Miles per jurisdiction per job (computed from route polylines)
CREATE TABLE app.job_jurisdiction_miles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  job_id UUID NOT NULL REFERENCES app.jobs(id) ON DELETE CASCADE,
  jurisdiction TEXT NOT NULL,
  miles NUMERIC(8,2) NOT NULL,
  computed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON app.job_jurisdiction_miles (tenant_id, jurisdiction);
CREATE UNIQUE INDEX ON app.job_jurisdiction_miles (job_id, jurisdiction);

-- IFTA tenant settings (base jurisdiction, decal info)
ALTER TABLE app.tenant_settings ADD COLUMN ifta_base_jurisdiction TEXT;
ALTER TABLE app.tenant_settings ADD COLUMN ifta_decal_number TEXT;
ALTER TABLE app.tenant_settings ADD COLUMN ifta_enabled BOOLEAN NOT NULL DEFAULT false;

-- Generated IFTA reports
CREATE TABLE app.ifta_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  quarter TEXT NOT NULL,                        -- '2026-Q1', '2026-Q2', etc.
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  total_miles NUMERIC(10,2),
  total_gallons NUMERIC(10,3),
  fleet_mpg NUMERIC(5,2),
  jurisdiction_summary JSONB NOT NULL,          -- per-jurisdiction miles + gallons + net tax
  tax_due NUMERIC(10,2),
  tax_refund NUMERIC(10,2),
  pdf_url TEXT,
  csv_url TEXT,
  generated_by UUID REFERENCES system.users(id),
  generated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, quarter)
);
```

Enable RLS on all new tenant-scoped tables with the standard `tenant_isolation` policy.

---

## BUILD ORDER — 5 checkpoints

After EVERY checkpoint:
1. Smoke-test the new feature
2. Smoke-test that Phases 1–4 still work
3. Verify cost tracking registers (where AI is used)
4. `git add -A && git commit -m "[phase 5 / checkpoint N] description"`
5. Append status log
6. Continue

---

### Checkpoint 0 — Phase 1–4 health + Phase 5 prereq verification

- All prior phases healthy
- Required Phase 5 env vars set
- Apply Phase 5 migrations
- Verify Motive API token can be obtained with credentials
- Test Anthropic vision call works (send a tiny test image, log cost)
- If anything fails: STOP, log clearly

---

### Checkpoint 1 — POD-to-Invoice automation pipeline (the killer feature)

This is the headline feature of Phase 5. Build it carefully.

**Architecture:**

1. **Trigger:** Driver uploads a photo via Phase 2 photo capture, categorizes it as `document_type='pod'`. A background job picks it up within 30 seconds.

2. **Extraction prompt** at `prompts/pod_extractor_v1.md`:
   ```
   You are extracting structured data from a Bill of Lading or Proof of Delivery photo.
   Return JSON with these fields, each with a confidence score 0.0–1.0:
   - customer_name (the bill-to entity)
   - delivery_date (ISO format)
   - delivery_time (HH:MM if visible)
   - receiver_name (printed name of who signed)
   - receiver_signature_present (boolean)
   - driver_signature_present (boolean)
   - load_description
   - quantity / pieces
   - weight (lbs)
   - special_notes (damage, weather, time discrepancies, anything unusual)
   - rate_or_amount (if visible — sometimes BOLs have the agreed rate)
   - reference_numbers (BOL number, PO number, job number)
   - overall_image_quality (good | partial | poor)
   
   If a field is illegible or missing, return null with confidence 0.0.
   Do not infer; only extract what's visibly in the image.
   ```

3. **Job matching:** Use `extracted.reference_numbers` first (highest confidence match). Fall back to customer name + delivery date proximity. Match must be >= 0.7 confidence to proceed; below that, surface as "needs human review."

4. **Invoice generation logic:**
   - Pull job rate from `jobs.rate_final` (or `rate_quoted` if final not set)
   - Generate `app.invoices` row in `status='draft'`
   - If amount < `AI_POD_AUTO_SEND_THRESHOLD_USD` AND match confidence >= 0.85: set `auto_send_eligible=true`
   - If both conditions met: auto-send via existing Phase 3 email + Stripe payment link flow
   - Otherwise: notify dispatcher with banner: "POD extracted for Job IDH-2026-0042 — review and approve to send"

5. **Audit trail:** Every extraction creates `pod_extractions` row with full extracted data, confidence scores, AI cost, and the resulting invoice ID.

6. **Dispatcher review UI:** `/admin/jobs/[id]/pod-review` page shows side-by-side: POD photo + extracted fields with confidence highlighting + matched job data + draft invoice. Buttons: "Approve & Send", "Edit & Send", "Reject" (keeps photo on job but no invoice).

7. **Cost protection:**
   - Before extraction: check tenant daily cap (`AI_POD_DAILY_PER_TENANT_CAP`)
   - If at cap: skip extraction, attach photo to job normally with note "Daily POD extraction cap reached — invoice manually"
   - Log every extraction cost to `ai_usage` table (existing from Phase 3)

8. **Special notes routing:** If `special_notes` extracted text matches damage/discrepancy keywords ("damage", "short", "refused", "missing", "delayed"), elevate to dispatcher priority alert. Don't auto-send the invoice — these need human eyes.

**Smoke tests:**
- Upload a clean test BOL photo → verify extraction → verify auto-send for amount under threshold
- Upload BOL with amount over threshold → verify draft status, dispatcher notified
- Upload BOL with damage note → verify priority alert, no auto-send
- Upload BOL for non-existent job → verify "needs review" status
- Verify cost logged correctly in ai_usage

**Marketing copy update simultaneously:** Add new feature page at `/features/pod-to-invoice` with the pitch: "Drivers snap a photo. You get paid 5–10 days faster on every load."

---

### Checkpoint 2 — ELD integration (Motive first, Samsara optional)

**Motive OAuth setup:**

1. `/admin/settings/integrations/eld` page lists supported providers
2. "Connect Motive" → OAuth redirect to `https://api.gomotive.com/oauth/authorize?...`
3. Callback at `/api/integrations/motive/callback` exchanges code for token, stores encrypted in `eld_integrations`
4. After connect: tenant maps each employee to their Motive driver ID via a setup wizard (fetches Motive driver list, dispatcher picks matches)

**HOS data fetching:**

5. Background job (BullMQ) runs every 15 minutes per active integration:
   - Refreshes access token if needed
   - Fetches HOS status for all linked employees
   - Updates `driver_hos_status` table (insert new row, don't update — preserves history)
6. On-demand fetch when a dispatcher opens an employee profile or assignment dialog

**UI integration:**

7. Employee list page: HOS status badge next to each driver:
   - Green: > 4 driving hours remaining
   - Yellow: 1–4 hours
   - Red: < 1 hour or break required
   - Gray: ELD not connected for this driver
8. Job assignment dialog: when picking a driver, show their HOS:
   - "Driver shows 8.2 hours remaining — this 6-hour run fits"
   - "Driver shows 2.5 hours remaining — this 6-hour run will exceed HOS. Confirm?" (WARN, not BLOCK)
9. Phase 3 AI Driver Suggester: factor HOS into ranking (drivers below 4 hours remaining drop in priority for jobs longer than their remaining hours)

**Samsara (optional, same pattern):**

10. If `SAMSARA_CLIENT_ID` env var is set, expose Samsara as a connection option using identical OAuth flow with provider='samsara'

**Smoke tests:**
- Connect Motive in test mode (use Motive's developer sandbox)
- Verify driver list fetches and mapping wizard works
- Verify HOS data appears in dispatcher view within 15 minutes
- Verify job assignment surfaces HOS warning when applicable
- Verify HOS warning does not BLOCK assignment

---

### Checkpoint 3 — IFTA fuel tax reporting

**Compute miles per jurisdiction:**

1. New service `lib/ifta/route-splitter.ts`:
   - Takes a job's `route_geojson` (cached from Google Directions in Phase 1)
   - Splits the polyline by state/province boundaries (use a static GeoJSON file of US state boundaries + Canadian provinces, included in `data/jurisdictions.geojson`)
   - Returns miles per jurisdiction
2. Background job (runs nightly): for any completed job in last 30 days without `job_jurisdiction_miles` rows, compute and store them
3. Existing completed jobs (Phase 1+) get backfilled in a one-time job during this checkpoint

**Fuel purchase entry:**

4. `/admin/fuel` page:
   - List view: all fuel purchases, filterable by date, truck, driver, jurisdiction
   - Manual entry form: date, truck, driver, jurisdiction (state dropdown), gallons, price/gal, receipt photo upload
   - Bulk import via CSV (column names match the form)
5. Driver mobile UI (in Driver Mode): "Log Fuel Stop" button — quick entry: photo of receipt, state auto-filled from current location, gallons + cost
   - AI extraction of receipt photo (uses same vision API, similar pattern to POD extraction but simpler) — extracts gallons, total cost, date, location
   - Driver confirms before saving

**Quarterly IFTA report:**

6. `/admin/reports/ifta` page:
   - Quarter picker (defaults to most recent complete quarter)
   - "Generate Report" button
   - Background generation (BullMQ) computes:
     - Total miles per jurisdiction (from `job_jurisdiction_miles`)
     - Total gallons per jurisdiction (from `fuel_purchases`)
     - Fleet MPG = total miles / total gallons
     - Taxable miles per jurisdiction
     - Tax owed (multiply by current IFTA tax rates — keep a static table in `data/ifta_tax_rates.json` updated quarterly)
     - Net tax due or refund per jurisdiction
   - PDF report with:
     - Cover page: tenant name, USDOT, IFTA decal, quarter, summary totals
     - Per-jurisdiction breakdown (miles, gallons, tax)
     - Detail appendix: every job's contribution to each jurisdiction's miles, every fuel purchase
   - CSV export in IFTA-standard column format (can be uploaded to most state IFTA portals)
   - Save to `ifta_reports` table; PDF + CSV stored via existing document storage

**Settings:**

7. `/admin/settings/ifta` page:
   - Enable IFTA reporting (toggle in `tenant_settings.ifta_enabled`)
   - Base jurisdiction (where IFTA registered)
   - Decal number
   - Notice if Phase 5 backfill is still running

**Smoke tests:**
- Create a few test fuel purchases manually in different states
- Backfill jurisdiction miles for ID Hotshot's completed jobs
- Generate a Q1 2026 IFTA report
- Verify PDF renders, CSV exports cleanly
- Verify math: sum of jurisdiction miles = total job miles; sum of jurisdiction gallons = total fuel
- Verify audit trail in report appendix is complete

---

### Checkpoint 4 — Marketing site updates

**This is content work, not heavy engineering. Spend 1–2 hours, not more.**

1. **Homepage hero update** (`content/marketing/home.mdx`):
   - New headline emphasizing automation: "Stop chasing paperwork. Start getting paid faster."
   - Sub-headline: "NobleDispatch turns signed BOL photos into sent invoices in 30 seconds. ELD-integrated, IFTA-ready, AI-powered. Built by truckers, priced for small fleets."
   - Three feature highlights with icons: POD-to-Invoice, ELD integration, IFTA reporting

2. **New feature pages:**
   - `/features/pod-to-invoice` — explains the photo-to-invoice pipeline with a step-by-step visual
   - `/features/eld-integration` — lists supported providers (Motive logo, Samsara logo if implemented), shows HOS warning screenshot
   - `/features/ifta-reporting` — quarterly IFTA pain → 30-second report generation

3. **Updated comparison page** (`/comparison`):
   - Side-by-side feature grid: NobleDispatch vs Truckpedia vs Tailwind vs Truckbase
   - Honest about what we DO have vs DON'T have (no inflated claims — they kill trust)
   - Price column at the bottom: Pro tier = $599/month for 100 trucks; competitors at equivalent tier

4. **Updated pricing page:**
   - Feature gating clarified: which tier gets POD-to-Invoice (all paid tiers), ELD integration (Pro and above), IFTA reporting (Growth and above)
   - "Most popular" badge on Growth tier (default upsell target for fleet-size 6–25)

5. **Case study placeholder:** New page `/customers/id-hotshot` with structured layout — to be filled in with real Danielle quotes and numbers once she has 90+ days of usage data. Mark as `noindex` for now so it doesn't show in search until populated.

**Don't:**
- Add testimonials you don't have
- Use stock photos of trucks (Danielle's actual truck if she'll share, or none)
- Promise features that aren't shipped
- Inflate the founder story beyond what's true

---

### Checkpoint 5 — Smoke tests + wake-up package

End-to-end scenario:

1. **Onboard a fake Motive sandbox account** — link a test driver
2. **Create a test job** for that driver
3. **Driver completes job in Driver Mode** — uploads a real-looking BOL photo
4. **Verify POD extraction fires** — AI reads BOL, matches job, draft invoice created
5. **If under threshold:** verify auto-send to test customer email + payment link works
6. **If over threshold:** verify dispatcher sees review banner
7. **Verify HOS data** shows in the driver's profile and assignment dialog
8. **Log a test fuel purchase** in a different state
9. **Run an IFTA report** for the current quarter — verify the test job's miles split correctly across states, fuel shows up, PDF generates
10. **Visit marketing site** — verify new feature pages render correctly on mobile and desktop

**Update `/opt/nobledispatch/WAKE_UP_README.md` with Phase 5 section:**

- Status of every checkpoint
- New env vars + what they cost (Motive API: free for low volume; AI vision: ~$0.01–0.05 per BOL extraction)
- Per-tenant onboarding steps for ELD (different than self-serve — manual provider linking)
- IFTA tax rate update procedure (quarterly, before tax filing season)
- Phase 5 stubs intentionally not built:
  - Factoring integration (separate phase)
  - Load board integration (separate phase)
  - Fuel card direct integration (separate phase — manual entry works for now)
  - Maintenance & DOT inspection tracking (separate phase)
- Marketing pages that need follow-up content work (ID Hotshot case study)

Final commit: `[phase 5 / checkpoint 5] Phase 5 complete — sales differentiators live`

---

## PHASE 5 SCOPE — what to BUILD vs what's deliberately NOT here

### BUILD (Phase 5):
✅ POD-to-Invoice automation pipeline (the killer feature)
✅ ELD integration with Motive (read-only, with optional Samsara)
✅ HOS warnings in assignment flow
✅ IFTA fuel tax reporting (quarterly PDF + CSV)
✅ Fuel purchase entry (manual + receipt-photo AI)
✅ Marketing site updates leading with these features
✅ Pricing page tier-gating clarified

### DO NOT BUILD (later phases or never):
❌ Factoring company integration (TBS, Apex, RTS) — separate feature
❌ Load board integration (DAT, Truckstop) — separate feature
❌ Direct fuel card integration (Comdata, EFS) — manual entry works for Phase 5
❌ Maintenance & DOT inspection tracking — separate feature
❌ Driver qualification file (DQF) management — separate feature
❌ Native mobile apps — PWA is fine
❌ Real testimonials in marketing site until Danielle has 90 days of data
❌ Becoming a certified ELD ourselves — multi-year regulated project, not happening

If you find yourself wanting to add any of these mid-checkpoint, STOP. They're separate phases. Phase 5 is four features. That's it.

---

## OUTPUT FORMAT FOR THE STATUS LOG

Continue the format from Phases 1–4 with `[PHASE 5 / CHECKPOINT N]` tag.

```
[2026-08-10 02:14:33] [PHASE 5 / CHECKPOINT 1] [START] POD-to-Invoice pipeline
[2026-08-10 02:14:51] [PHASE 5 / CHECKPOINT 1] [INFO] pod_extractor_v1 prompt saved
[2026-08-10 02:15:08] [PHASE 5 / CHECKPOINT 1] [TEST] Sample BOL extraction — confidence 0.91 across 8 fields (PASS)
[2026-08-10 02:15:09] [PHASE 5 / CHECKPOINT 1] [COST] Vision call: 1,247 input tokens (image), 312 output, $0.0274
[2026-08-10 02:15:34] [PHASE 5 / CHECKPOINT 1] [TEST] Auto-send threshold check — $487 invoice auto-sent (PASS)
[2026-08-10 02:15:48] [PHASE 5 / CHECKPOINT 1] [TEST] Auto-send threshold check — $1,250 invoice draft, dispatcher notified (PASS)
[2026-08-10 02:16:02] [PHASE 5 / CHECKPOINT 1] [TEST] Phase 1–4 regression — login + Driver Mode + signup flow (PASS)
[2026-08-10 02:16:18] [PHASE 5 / CHECKPOINT 1] [GIT] Committed
[2026-08-10 02:16:19] [PHASE 5 / CHECKPOINT 1] [DONE] ✅
```

---

## FINAL OUTPUTS Claude Code should produce

1. ✅ All Phase 1–4 functionality remains working
2. ✅ POD-to-Invoice pipeline tested end-to-end with at least 3 test BOL photos
3. ✅ Motive ELD integration live (sandbox connection verified)
4. ✅ IFTA report for ID Hotshot's Q1 2026 data generated successfully (even if numbers are partial)
5. ✅ Marketing site shows new feature pages, comparison table, updated pricing
6. ✅ `/var/log/nobledispatch-build.log` has clean Phase 5 narrative
7. ✅ `/opt/nobledispatch/WAKE_UP_README.md` updated with Phase 5 section
8. ✅ AI cost guardrails verified — vision calls log correctly, daily cap enforced

---

## ===== PROMPT END =====

## After Claude Code finishes — what to check

1. **SSH in:** `tail -100 /var/log/nobledispatch-build.log` — should end with Phase 5 checkpoint 5 ✅
2. **Read** `/opt/nobledispatch/WAKE_UP_README.md` Phase 5 section
3. **Test the killer feature on your phone:**
   - Log in as a driver
   - Pick a job in Driver Mode
   - Take a photo of any document (even a hand-written test BOL)
   - Watch the dispatcher view — does an invoice appear within 60 seconds?
4. **Check the AI vision cost** in `/admin/settings/ai` — what did the test BOLs cost? Should be $0.02–$0.05 each.
5. **Try the Motive sandbox connection** if you set up developer credentials
6. **Visit nobledispatch.com** — does the new homepage lead with the right message?

---

## What this changes for sales

After Phase 5 deploys, your demo and pitch get sharper:

**Old pitch:** "It's a complete dispatch platform for small fleets."
**New pitch:** "Your drivers snap a photo of the signed BOL. We OCR it, match it to the job, and email your customer an invoice with a payment link — all before the driver gets back to the yard. ELD-integrated so you stop assigning drivers who don't have hours. IFTA reports run in 30 seconds instead of 30 hours. $249/month."

Three concrete features, all addressing pain points that came up across every TMS comparison in the 2026 market research. That's the sales weapon.

---

**Created by The Noble Glitch · thenobleglitch.com · 2026**

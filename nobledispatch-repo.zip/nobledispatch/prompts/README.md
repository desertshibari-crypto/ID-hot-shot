# Deployment Prompts

These are the executable specifications that build the NobleDispatch platform. Each is a self-contained markdown document that Claude Code can read and execute autonomously on a target server.

## Run order

The prompts are numbered for execution order. Each phase depends on the prior ones being complete.

| File | Phase | Approx. wall time |
|---|---|---|
| `00-website-deploy.md` | idhotshot.com marketing site | 1–2 hours |
| `01-foundation.md` | Multi-tenant core, calendars, jobs, customers, trucks, employees, messaging | 6–10 hours |
| `02-driver-experience.md` | Real-time sync, Driver Mode, voice, geofencing, payroll, 2FA | 8–14 hours |
| `03-ai-payments-portal.md` | AI dispatcher, customer portal, Stripe Connect, reporting | 12–20 hours |
| `04-sales-platform.md` | Marketing site, self-serve signup, platform billing, custom domains | 8–12 hours |
| `05-sales-differentiators.md` | POD-to-Invoice, ELD integration, IFTA reporting | 4–8 hours |
| `99-brand-integration.md` | Login + dashboard skinning, per-tenant logo upload | 2–3 hours |

Wall-clock estimates assume autonomous Claude Code execution on a Hostinger KVM8-class VPS (8 vCPU / 32GB RAM). Times vary with API latency, retry counts, and whether the operator needs to intervene at checkpoints.

## How to run a prompt

These prompts assume:

1. The target VPS (referenced in our project as "Boston 2") is provisioned, accessible by SSH, and has:
   - Ubuntu 22.04+ or similar
   - Docker, Docker Compose, Nginx, certbot installed
   - Claude Code installed and authenticated (`claude --version` works)
   - A `.env` file at `/root/nobledispatch.env` with all required credentials for the relevant phase (each prompt's pre-flight section lists what's needed)

2. The operator has run the prior phase(s) successfully and confirmed each as healthy.

3. The operator has read the prompt before running it. **Don't run prompts you haven't read.** Each one has hard safety rails, STOP conditions, and assumptions that matter.

Run pattern:

```bash
# 1. Source the env file
source /root/nobledispatch.env

# 2. Verify prior phases healthy
curl -I https://idhotshot.com
curl -I https://nobledispatch.idhotshot.com

# 3. Launch the prompt
claude --dangerously-skip-permissions < /root/01-foundation.md

# 4. From another SSH session, watch the status log
tail -f /var/log/nobledispatch-build.log
```

The `--dangerously-skip-permissions` flag lets Claude Code make filesystem and network changes without prompting for each one. The prompts compensate with internal safety rails: git checkpoints, additive-only migrations, regression tests after every checkpoint, and explicit STOP conditions.

## What the prompts produce

Each prompt produces:

1. **Real, working code on the VPS** — committed to a local git repo at `/opt/nobledispatch/`
2. **A status log** at `/var/log/nobledispatch-build.log` documenting every action and test
3. **A `WAKE_UP_README.md`** at `/opt/nobledispatch/` summarizing what was built, what's stubbed, and what needs operator follow-up

The platform is **not** pushed to this GitHub repository — that's the operator's call, separately. The repository you're looking at is the design / spec / brand assets, not the runtime codebase.

## Safety rails common to all prompts

Every prompt enforces:

- **Git checkpoints after every meaningful step** — rollback is one command if something breaks
- **Phase regression tests** — every checkpoint re-tests prior phase functionality, so we catch breakage early
- **Additive-only migrations** — database schema only grows, never shrinks (no destructive `DROP TABLE`, no column removal)
- **Cost guardrails** — AI features have per-tenant, per-user, and per-call caps that cannot be bypassed
- **STOP conditions** — defined points where Claude Code halts and waits for operator intervention rather than guessing

## If something goes wrong

The status log at `/var/log/nobledispatch-build.log` is the source of truth. Read it from the bottom up to find the last successful checkpoint, then read forward to see what failed and why.

The git history at `/opt/nobledispatch/` lets you roll back to any checkpoint:

```bash
cd /opt/nobledispatch
git log --oneline | head -30           # see recent commits
git checkout <commit-hash>             # roll back to that state
```

The `WAKE_UP_README.md` is intended as the document a fresh operator (or future you) reads to come up to speed on what's deployed and what's pending.

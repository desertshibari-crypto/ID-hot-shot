# NobleDispatch — Phase 4 Deployment Prompt for Claude Code

**For:** Boston 2 VPS (continuing on Phases 1, 2, 3)
**Project root:** `/opt/nobledispatch` (existing)
**Phase:** 4 of 4 — Multi-Tenant Sales Platform: Marketing, Self-Serve Onboarding, Platform Billing, Custom Domains
**Prerequisites:** Phases 1, 2, AND 3 deployed, healthy, and verified in real use. Ideally at least one paying tenant outside ID Hotshot already manually onboarded.

---

## Honest read-this-first

Phase 4 is not more software for trucking. **Phase 4 is software for selling NobleDispatch.** It's the marketing site at nobledispatch.com, the self-service signup flow, the billing engine that charges tenants their monthly subscription, and the custom-domain mapping that lets a trucking company point dispatch.theircompany.com at the platform.

Three honest cautions:

1. **Don't build this until you've validated demand.** If no one outside your friend network has paid for NobleDispatch yet, Phase 4 is premature. Sell the platform manually to 3–5 customers first. Learn what they actually pay for, what they balk at, what objections they raise. Phase 4 should bake those lessons in.

2. **Phase 4 introduces real legal exposure.** When companies pay you monthly, you're providing a service. That triggers obligations: terms of service, privacy policy, DPA (if you handle their data — and you do), refund policy, dispute resolution. Stubs are included; **before live launch get a SaaS-experienced attorney to review them**. Cost: $1,500–$5,000. Cheap insurance.

3. **You become a tax-collecting entity.** Sales tax on SaaS varies by state (some tax it, some don't, some only over thresholds). At any meaningful scale you need a service like Stripe Tax, Anrok, or TaxJar, plus a CPA who understands SaaS. Stub for Stripe Tax is included.

If you've read these and you're ready: keep going.

---

## How to run this

```bash
# 1. Phase 1, 2, 3 health check
curl -I https://nobledispatch.idhotshot.com
curl -I https://idhotshot.com
cd /opt/nobledispatch && git log --oneline | head -60   # Phase 1+2+3 commits

# 2. Phase 4 env vars
nano /root/nobledispatch.env

# 3. Run autonomously
source /root/nobledispatch.env
claude --dangerously-skip-permissions < /root/NOBLEDISPATCH_PHASE4_DEPLOY.md

# 4. Watch from another window
tail -f /var/log/nobledispatch-build.log
```

---

## PRE-FLIGHT — Phase 4 env vars

Append to `/root/nobledispatch.env`:

```bash
# === REQUIRED ===

# nobledispatch.com domain (you must register this BEFORE running)
export PLATFORM_DOMAIN="nobledispatch.com"
export PLATFORM_APP_DOMAIN="app.nobledispatch.com"
export PLATFORM_DOCS_DOMAIN="docs.nobledispatch.com"
export PLATFORM_STATUS_DOMAIN="status.nobledispatch.com"

# Stripe — platform billing (separate from per-tenant Stripe Connect from Phase 3)
# This is YOU billing other trucking companies for their NobleDispatch subscription.
export STRIPE_PLATFORM_SECRET_KEY="sk_test_xxxx"            # start in test mode
export STRIPE_PLATFORM_PUBLISHABLE_KEY="pk_test_xxxx"
export STRIPE_PLATFORM_WEBHOOK_SECRET="whsec_xxxx"

# Stripe price IDs for each plan (create in Stripe dashboard first)
export STRIPE_PRICE_STARTER="price_xxxxxxxx"        # $99/mo
export STRIPE_PRICE_GROWTH="price_xxxxxxxx"         # $249/mo + $500 setup
export STRIPE_PRICE_PRO="price_xxxxxxxx"            # $599/mo + $1500 setup
export STRIPE_PRICE_ENTERPRISE="price_xxxxxxxx"     # $1499/mo + $5000 setup
export STRIPE_PRICE_WHITELABEL_LICENSE="price_xxxxxxxx"  # $799/mo + $10000 setup

# Stripe Tax (sales tax handling)
export STRIPE_TAX_ENABLED="true"

# Trial duration (days)
export TRIAL_DAYS="14"

# === BUSINESS / LEGAL ===
export PLATFORM_LEGAL_ENTITY_NAME="The Noble Glitch, LLC"     # update with your real entity
export PLATFORM_LEGAL_ADDRESS="..."                            # required for ToS, privacy, invoices
export PLATFORM_SUPPORT_EMAIL="support@nobledispatch.com"
export PLATFORM_BILLING_EMAIL="billing@nobledispatch.com"
export PLATFORM_LEGAL_EMAIL="legal@nobledispatch.com"
export PLATFORM_DPA_REVIEW_DATE=""                             # leave blank until attorney has reviewed

# === OPTIONAL ===

# Cloudflare (recommended for custom domain SSL automation)
export CLOUDFLARE_API_TOKEN=""                                 # if using Cloudflare for SSL
export CLOUDFLARE_ZONE_ID=""

# Plausible (privacy-friendly analytics) or Google Analytics
export PLAUSIBLE_DOMAIN="nobledispatch.com"

# Statuspage / UptimeRobot
export UPTIMEROBOT_API_KEY=""

# Loops or ConvertKit for marketing emails (separate from transactional Resend)
export LOOPS_API_KEY=""
```

Verify before running:

```bash
# Domains resolve to Boston 2's IP
dig +short nobledispatch.com
dig +short app.nobledispatch.com
dig +short docs.nobledispatch.com
dig +short status.nobledispatch.com

# Stripe platform account is in TEST mode (you'll switch live manually)
curl https://api.stripe.com/v1/account -u "$STRIPE_PLATFORM_SECRET_KEY:"

# Stripe price IDs exist for each plan
for price in $STRIPE_PRICE_STARTER $STRIPE_PRICE_GROWTH $STRIPE_PRICE_PRO $STRIPE_PRICE_ENTERPRISE $STRIPE_PRICE_WHITELABEL_LICENSE; do
  curl -s "https://api.stripe.com/v1/prices/$price" -u "$STRIPE_PLATFORM_SECRET_KEY:" | grep -E '"id"|"unit_amount"'
done
```

---

## ===== PROMPT BEGIN — EVERYTHING BELOW IS FOR CLAUDE CODE =====

You are completing **NobleDispatch Phase 4** — the platform's go-to-market layer. Phases 1, 2, and 3 are deployed at `https://nobledispatch.idhotshot.com` and serving ID Hotshot Transportation as the founding tenant. Your job is to add the marketing site, signup flow, billing, custom domains, and operator dashboard so The Noble Glitch can sell NobleDispatch as a product.

**Critical mental model:** Phase 4 has *two distinct user journeys* that must not be confused:

- **Tenants billing their customers** — Phase 3's Stripe Connect, money flowing to the trucking company. Already built. Don't touch it.
- **The platform billing the tenants** — Phase 4's new flow, money flowing to The Noble Glitch. New thing.

These are two separate Stripe accounts, two separate webhook handlers, two separate sets of customer records, two separate payment flows. Mixing them is a fraud-class bug. Be deliberate.

---

## HARD SAFETY RAILS — Phase 1+2+3 rules + new ones

All prior rails apply. Additions:

1. **Two Stripe accounts must never be confused.** Phase 3's `STRIPE_SECRET_KEY` is for tenants billing their customers. Phase 4's `STRIPE_PLATFORM_SECRET_KEY` is for the platform billing tenants. Use distinct env var names everywhere. Lint check: anywhere code references Stripe, it must explicitly indicate which account it operates on. The same key should never be loaded by both flows.

2. **Trial periods cannot extend forever.** A self-serve signup gets a 14-day trial. After that, payment is required or the tenant is suspended (read-only access for 30 days, then archived). Don't build "extend trial" UI for self-serve tenants — only superadmin can manually extend.

3. **Custom domain SSL must not break the platform's own SSL.** When a tenant points dispatch.theircompany.com at NobleDispatch, certbot provisions a cert just for that domain. Use a dedicated nginx server block. Never modify the existing nobledispatch.idhotshot.com or idhotshot.com configs.

4. **Self-serve signup must not create a billable charge until trial ends.** Stripe Checkout in `subscription_data: { trial_period_days: 14 }` mode. Tenants can cancel during trial with one click and never see a charge. This is non-negotiable for legal and regulatory reasons.

5. **Cancellation must be one-click and self-serve.** No "call to cancel" pattern. No retention dark patterns. The FTC has been actively enforcing this and you do not want to be the test case. Cancel button → confirmation modal → cancel webhook fired → access continues until end of paid period. Done.

6. **GDPR / CCPA basic compliance is mandatory before public launch.** Privacy policy must list: what data you collect, why, where it's stored, how long, who it's shared with, how to request deletion. Even if your customers are all in the US, you may have employees of those customers in California, and CCPA still applies. Stub policies are provided; mark them clearly as drafts requiring legal review.

7. **Stripe must be in TEST mode by default.** Loud banner. Switch to live only after a real attorney has reviewed the ToS, privacy policy, and DPA. Build the switch but make it require typing "I HAVE LEGAL REVIEW DOCUMENTED" to enable.

8. **STOP conditions** for Phase 4:
   - Phases 1, 2, or 3 stop responding
   - DNS for any of the four new subdomains (nobledispatch.com, app., docs., status.) doesn't resolve
   - Stripe platform account is unreachable
   - Stripe price IDs in env don't match real prices in the Stripe dashboard
   - Required legal entity info missing

---

## STACK ADDITIONS for Phase 4

| Need | Choice | Why |
|---|---|---|
| Marketing site | Next.js static export, served from app | Reuse stack, simple deployment |
| Documentation | MDX + a minimal docs theme | Content lives in repo, version-controlled |
| Status page | Self-hosted (Cachet or simple custom) or hosted (BetterStack, Atlassian Statuspage) | Self-hosted is free and fits your portability ethos |
| Marketing emails | Loops or ConvertKit (separate from transactional Resend) | Don't mix marketing and transactional sender reputation |
| Subscription billing | Stripe Subscriptions + Customer Portal | Stripe Customer Portal handles cancel/upgrade/billing UI for free |
| Custom domain SSL | certbot + nginx OR Cloudflare for SaaS | Cloudflare for SaaS is easier at scale; certbot is fine for first 10 domains |
| Onboarding | Custom React multi-step wizard | Has to feel good — first impression matters |
| Analytics | Plausible (privacy-first, self-hostable) | GDPR-friendly, no cookie banner needed |

---

## DATABASE MIGRATIONS — Phase 4 additions

```sql
-- Subscription plans (mirror of Stripe products)
CREATE TABLE system.subscription_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,                  -- 'starter' | 'growth' | 'pro' | 'enterprise' | 'whitelabel'
  name TEXT NOT NULL,
  description TEXT,
  monthly_price_usd NUMERIC(10,2) NOT NULL,
  setup_fee_usd NUMERIC(10,2) NOT NULL DEFAULT 0,
  stripe_price_id TEXT NOT NULL,
  stripe_setup_fee_price_id TEXT,
  features JSONB NOT NULL DEFAULT '[]',       -- list of feature flags this plan unlocks
  max_trucks INTEGER,
  max_users INTEGER,
  ai_monthly_cap_usd NUMERIC(10,2),
  is_active BOOLEAN NOT NULL DEFAULT true,
  display_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Tenant subscriptions (the platform billing tenants)
CREATE TABLE system.subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES system.tenants(id) ON DELETE CASCADE,
  plan_id UUID NOT NULL REFERENCES system.subscription_plans(id),
  status TEXT NOT NULL,                       -- trialing | active | past_due | canceled | suspended | archived
  stripe_customer_id TEXT,
  stripe_subscription_id TEXT,
  trial_start TIMESTAMPTZ,
  trial_end TIMESTAMPTZ,
  current_period_start TIMESTAMPTZ,
  current_period_end TIMESTAMPTZ,
  canceled_at TIMESTAMPTZ,
  cancel_at_period_end BOOLEAN NOT NULL DEFAULT false,
  past_due_since TIMESTAMPTZ,
  suspended_at TIMESTAMPTZ,
  archived_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Platform invoices (separate from tenant.invoices which is tenant's customer invoices)
CREATE TABLE system.platform_invoices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES system.tenants(id),
  subscription_id UUID REFERENCES system.subscriptions(id),
  stripe_invoice_id TEXT UNIQUE NOT NULL,
  invoice_number TEXT,
  amount_due_usd NUMERIC(10,2) NOT NULL,
  amount_paid_usd NUMERIC(10,2) NOT NULL DEFAULT 0,
  tax_amount_usd NUMERIC(10,2) DEFAULT 0,
  status TEXT NOT NULL,                       -- draft | open | paid | uncollectible | void
  issued_at TIMESTAMPTZ,
  due_at TIMESTAMPTZ,
  paid_at TIMESTAMPTZ,
  invoice_pdf_url TEXT,
  hosted_invoice_url TEXT,
  raw_payload JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Custom domain mappings
CREATE TABLE system.tenant_domains (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES system.tenants(id) ON DELETE CASCADE,
  domain TEXT UNIQUE NOT NULL,
  ssl_status TEXT NOT NULL DEFAULT 'pending', -- pending | provisioning | active | failed
  ssl_provider TEXT,                          -- 'letsencrypt' | 'cloudflare' | 'manual'
  ssl_cert_path TEXT,
  ssl_expires_at TIMESTAMPTZ,
  verification_token TEXT,
  verified_at TIMESTAMPTZ,
  is_primary BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Self-serve signup leads (people who started signup but didn't finish)
CREATE TABLE system.signup_leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL,
  full_name TEXT,
  phone TEXT,
  company_name TEXT,
  fleet_size_estimate TEXT,                   -- '1-5' | '6-25' | '26-100' | '100+'
  selected_plan TEXT,
  utm_source TEXT,
  utm_medium TEXT,
  utm_campaign TEXT,
  step_reached TEXT,                          -- which step they got to before dropping
  converted_tenant_id UUID REFERENCES system.tenants(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_activity_at TIMESTAMPTZ
);
CREATE INDEX ON system.signup_leads (email);
CREATE INDEX ON system.signup_leads (created_at DESC);

-- Onboarding checklist progress (per tenant)
CREATE TABLE app.onboarding_progress (
  tenant_id UUID PRIMARY KEY,
  added_first_truck BOOLEAN NOT NULL DEFAULT false,
  added_first_employee BOOLEAN NOT NULL DEFAULT false,
  added_first_customer BOOLEAN NOT NULL DEFAULT false,
  created_first_job BOOLEAN NOT NULL DEFAULT false,
  uploaded_logo BOOLEAN NOT NULL DEFAULT false,
  set_brand_colors BOOLEAN NOT NULL DEFAULT false,
  invited_team_member BOOLEAN NOT NULL DEFAULT false,
  connected_stripe BOOLEAN NOT NULL DEFAULT false,
  configured_dispatch_hours BOOLEAN NOT NULL DEFAULT false,
  completed_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Platform-wide metrics (rolled up for operator dashboard)
CREATE TABLE system.platform_metrics_daily (
  date DATE PRIMARY KEY,
  total_tenants INTEGER NOT NULL DEFAULT 0,
  trialing_tenants INTEGER NOT NULL DEFAULT 0,
  active_tenants INTEGER NOT NULL DEFAULT 0,
  past_due_tenants INTEGER NOT NULL DEFAULT 0,
  canceled_tenants INTEGER NOT NULL DEFAULT 0,
  mrr_usd NUMERIC(10,2) NOT NULL DEFAULT 0,
  arr_usd NUMERIC(10,2) NOT NULL DEFAULT 0,
  new_signups_today INTEGER NOT NULL DEFAULT 0,
  trial_conversions_today INTEGER NOT NULL DEFAULT 0,
  cancellations_today INTEGER NOT NULL DEFAULT 0,
  churn_rate_30d NUMERIC(5,4),
  computed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Status page incidents
CREATE TABLE system.status_incidents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  status TEXT NOT NULL,                       -- investigating | identified | monitoring | resolved
  severity TEXT NOT NULL,                     -- minor | major | critical
  affected_services TEXT[],
  started_at TIMESTAMPTZ NOT NULL,
  resolved_at TIMESTAMPTZ,
  created_by UUID REFERENCES system.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE system.status_incident_updates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  incident_id UUID NOT NULL REFERENCES system.status_incidents(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Seed the subscription plans
INSERT INTO system.subscription_plans (slug, name, monthly_price_usd, setup_fee_usd, stripe_price_id, features, max_trucks, ai_monthly_cap_usd, display_order) VALUES
  ('starter',     'Starter',        99.00,    0.00,   :starter_price_id,     '["jobs","calendars","customers","trucks","employees","messaging","map"]'::jsonb,                                                   5,   25.00,  10),
  ('growth',      'Growth',         249.00,   500.00, :growth_price_id,      '["jobs","calendars","customers","trucks","employees","messaging","map","driver_mode","tts","push","payroll"]'::jsonb,           25,  50.00,  20),
  ('pro',         'Pro',            599.00,   1500.00, :pro_price_id,         '["all_phase_1","all_phase_2","ai_copilots","customer_portal","stripe_connect","reporting"]'::jsonb,                              100, 150.00, 30),
  ('enterprise',  'Enterprise',     1499.00,  5000.00, :enterprise_price_id,  '["everything","custom_domain","priority_support","sla"]'::jsonb,                                                                NULL, 500.00, 40),
  ('whitelabel',  'White Label',    799.00,   10000.00, :whitelabel_price_id, '["everything","custom_domain","remove_attribution","license_to_resell"]'::jsonb,                                                NULL, 200.00, 50);
```

---

## BUILD ORDER — execute with checkpoints

After EVERY checkpoint:
1. Smoke-test the new feature end-to-end
2. Verify Phase 1+2+3 still work
3. `git add -A && git commit -m "[phase 4 / checkpoint N] description"`
4. Append status log
5. Continue

### Checkpoint 0 — Phase 1+2+3 health + Phase 4 prereq verification
- All prior phases healthy
- All Phase 4 env vars set
- DNS for nobledispatch.com, app., docs., status. all resolve to Boston 2's IP
- Stripe platform account in test mode confirmed
- Stripe price IDs all valid
- Apply Phase 4 migrations
- Seed subscription plans (use the env var price IDs)
- If anything fails: STOP

### Checkpoint 1 — Marketing site at nobledispatch.com
- New Next.js route group `(marketing)` separate from `(app)` and `(portal)`
- Pages:
  - `/` — Hero, social proof (ID Hotshot case study placeholder), feature tour, pricing teaser, CTA
  - `/features` — Detailed feature pages (one per major module: Dispatch, Driver Mode, AI, Customer Portal, Reporting)
  - `/pricing` — Plan comparison grid, FAQs, ROI calculator
  - `/about` — About The Noble Glitch, mission, team (just you for now)
  - `/contact` — Contact form, support email, sales meeting calendar link
  - `/legal/terms` — Terms of Service (DRAFT — see Checkpoint 12)
  - `/legal/privacy` — Privacy Policy (DRAFT)
  - `/legal/dpa` — Data Processing Agreement (DRAFT)
  - `/legal/security` — Security overview
- Design: same brand language as the project brief PDF — clean, off-white background, single red accent (#a01818), Anton + Barlow typography. Don't make it look like every other SaaS landing page; lean into the trucking-industry visual language (the hero on idhotshot.com is a good reference).
- All marketing copy in `content/` directory as MDX so non-technical edits are easy
- Plausible analytics installed
- Smoke test: visit `https://nobledispatch.com`, navigate all pages, verify mobile responsiveness

### Checkpoint 2 — ROI calculator (interactive)
- Embedded on the pricing page and /features
- Inputs: number of trucks, average jobs per week, average revenue per job
- Outputs: estimated annual operational savings, time saved per week, AI dispatcher revenue capture estimate
- Uses the same numbers from the Value Estimation document (operational value $15K–$42K range)
- Generates a shareable URL with their inputs encoded — useful for sales follow-up
- Smoke test: enter realistic values for a 5-truck operation, verify outputs match the Value Estimation ranges

### Checkpoint 3 — Self-serve signup flow
- Multi-step wizard at `/signup`:
  - Step 1: Email + password (creates `signup_leads` row, captures UTM params)
  - Step 2: Company info — legal name, display name, phone, fleet size
  - Step 3: Plan selection — pulls from `subscription_plans`, highlights the recommended plan based on fleet size
  - Step 4: Stripe Checkout in trial mode (`trial_period_days: 14`, no charge until trial ends)
  - Step 5: Welcome screen with link to their tenant subdomain (`<slug>.nobledispatch.com`)
- On Checkout success webhook (`checkout.session.completed`):
  - Create `system.tenants` row (slug auto-generated from company name, with collision handling)
  - Create `system.subscriptions` row (status='trialing')
  - Create initial tenant_owner user with the email from step 1
  - Create `app.tenant_settings` with sensible defaults
  - Create `app.onboarding_progress` row
  - Send welcome email (Resend) with login link and onboarding checklist
- Email reminders during trial:
  - Day 3: "Here's how to invite your team"
  - Day 7: "Halfway through your trial — here's what other carriers love"
  - Day 12: "Your trial ends in 2 days — here's what happens next"
  - Day 14: "Your trial ended — your account is now on [plan]"
- Smoke test: complete a self-serve signup with a test Stripe card, verify tenant created, login works, onboarding checklist shows progress

### Checkpoint 4 — Onboarding checklist (in-app)
- Persistent widget on the new tenant's dashboard during their first 30 days
- 9 items from `app.onboarding_progress`:
  - Add your first truck
  - Add your first employee
  - Add your first customer
  - Create your first job
  - Upload your company logo
  - Set your brand colors
  - Invite a team member
  - Connect Stripe (for invoicing)
  - Configure your dispatch hours
- Each item: link to the relevant page, marks complete on action, progress bar
- When complete: celebratory message, widget hides
- Smoke test: as a fresh tenant, complete each step, verify checklist updates and finally hides

### Checkpoint 5 — Platform billing webhooks
- New webhook handler at `/api/webhooks/stripe-platform`:
  - `customer.subscription.created` — already handled in signup flow, verify
  - `customer.subscription.updated` — update `system.subscriptions.status`, period dates
  - `customer.subscription.deleted` — set status='canceled', schedule archive in 30 days
  - `customer.subscription.trial_will_end` — send email reminder (3 days out)
  - `invoice.payment_succeeded` — create `system.platform_invoices` row, mark paid
  - `invoice.payment_failed` — set status='past_due', send dunning email
  - `invoice.upcoming` — send "your subscription will renew" reminder 7 days out
- Signature verification using `STRIPE_PLATFORM_WEBHOOK_SECRET`
- All webhook events logged to a `system.platform_webhook_events` table for replay/debugging
- Smoke test: trigger each webhook from Stripe CLI, verify state updates correctly

### Checkpoint 6 — Subscription management UI for tenants
- New page `/admin/billing` (tenant_owner only)
- Shows: current plan, status, trial end / next billing date, payment method, billing history (from `system.platform_invoices`)
- Buttons:
  - "Change plan" → opens Stripe Customer Portal in plan-change mode (Stripe handles the UI)
  - "Update payment method" → Stripe Customer Portal
  - "Download invoices" → links to Stripe-hosted invoice PDFs
  - "Cancel subscription" → confirmation modal → cancel via Stripe API → access until period end
- No retention dark patterns. The cancel button is the same size and prominence as other buttons. No "are you sure" loop more than once. No "we'll give you 50% off" interception.
- Smoke test: as a tenant, view billing page, change plan in test mode, verify it works; cancel and verify access continues until period end

### Checkpoint 7 — Past-due and suspension flow
- Background job (BullMQ, runs hourly): check all `subscriptions` with status='past_due':
  - 1 day past due: send polite reminder
  - 3 days past due: send firmer reminder, banner in admin UI
  - 7 days past due: send "we're going to suspend in 7 days" notice
  - 14 days past due: set status='suspended', tenant becomes read-only (can log in, see data, can't create or modify)
  - 44 days past due (suspended for 30 days): set status='archived', tenant is locked out, data retained for 90 more days, then export-and-delete option offered to tenant_owner
- All notifications sent via Resend (transactional)
- Suspended tenants see a clear banner: "Your subscription is past due. [Update payment]"
- Smoke test: simulate past-due state, verify each step fires correctly

### Checkpoint 8 — Custom domain mapping
- Tenant page `/admin/settings/domains` (Pro and Enterprise tiers only)
- Form to add a domain (e.g. `dispatch.acmetrucking.com`):
  - Saves to `system.tenant_domains` with status='pending'
  - Generates a verification TXT record token, displays it: "Add this TXT record to verify ownership"
  - Background job verifies TXT record every 30 seconds for up to 1 hour
  - Once verified: triggers SSL provisioning via certbot (`certbot certonly --nginx -d <domain>`)
  - On success: writes nginx server block, reloads nginx, sets status='active'
  - On failure: surfaces error to tenant
- Map subdomain pattern: every request to a custom domain looks up `tenant_domains.domain` to resolve `tenant_id`
- Tenant can set primary domain (where their team logs in by default)
- Smoke test: add a real test domain, verify TXT record validation, verify SSL provisions, verify the tenant's app loads at the custom domain

### Checkpoint 9 — Operator (Noble Glitch) dashboard
- New superadmin route `/superadmin/dashboard`
- Cards (top of page):
  - MRR (current monthly recurring revenue)
  - ARR (annualized)
  - Total tenants (broken into trialing / active / past_due / canceled)
  - New signups today / this week / this month
  - Trial-to-paid conversion rate (last 30 days)
  - Churn rate (last 30 days)
  - Active subscriptions by plan (chart)
- Tables:
  - Recent signups
  - At-risk tenants (past_due, suspended)
  - Recent cancellations (with reason if captured)
  - High-value customers (top 10 by ARR)
- Daily rollup job populates `system.platform_metrics_daily`
- Export everything to CSV
- Smoke test: load dashboard with seeded test data, verify all metrics calculate correctly

### Checkpoint 10 — Documentation site at docs.nobledispatch.com
- MDX-based docs at `apps/docs` or `app/(docs)/`
- Sections:
  - **Getting Started** — first 24 hours as a new tenant
  - **Dispatching** — creating jobs, assignment, calendars
  - **Driver App** — Driver Mode, photos, geofencing, voice
  - **AI Features** — how to use, configure, cost-control
  - **Customer Portal** — setup, sharing with customers
  - **Billing** — connecting Stripe Connect, invoices, payments
  - **Account Settings** — branding, team, custom domain
  - **API Reference** — for tenants who want integrations (stub for now)
  - **Troubleshooting** — common issues
- Search via Pagefind (free, builds at compile time)
- Sidebar nav, breadcrumbs
- Edit-on-GitHub link on each page (so non-technical contributors can suggest edits)
- Smoke test: visit `docs.nobledispatch.com`, search "driver mode", verify search returns relevant pages

### Checkpoint 11 — Status page at status.nobledispatch.com
- Self-hosted, simple
- Components monitored: Marketing Site, App, Database, AI Services, Voice AI, Email, Payments
- Each shows: green (operational) / yellow (degraded) / red (outage)
- Health checks (every 30 sec):
  - Marketing site: HTTP 200
  - App: HTTP 200 + DB query check
  - Database: connection + simple SELECT
  - AI: small Anthropic API ping
  - Voice AI: Vapi API health endpoint
  - Email: Resend API health
  - Payments: Stripe API health
- Public-facing — anyone can view
- Manual incident posting (superadmin only): create incident, post updates, mark resolved
- 90-day uptime history per service
- RSS/Atom feed for incidents
- Smoke test: simulate a service outage by blocking a port, verify status updates within 60 seconds

### Checkpoint 12 — Legal page stubs (DRAFT)
**Critical:** these are templates only. Mark them clearly. Do NOT remove the draft markers without attorney review.

- `/legal/terms` — Terms of Service draft including:
  - Service description
  - Account/eligibility requirements
  - Acceptable use policy
  - Subscription terms (auto-renewal, cancellation, refunds)
  - Limitation of liability
  - Indemnification
  - Governing law (Arizona by default)
  - Changes to terms
- `/legal/privacy` — Privacy Policy draft including:
  - Data collected (account info, usage data, payment info via Stripe)
  - Why collected
  - Where stored (Boston 2 + Stripe + third-party services listed)
  - Retention period
  - User rights (access, delete, export)
  - California (CCPA) and EU (GDPR) supplements
  - Contact for privacy questions
- `/legal/dpa` — Data Processing Agreement draft (for tenants concerned about being a data processor for their drivers/customers):
  - Roles (NobleDispatch as processor, tenant as controller)
  - Subprocessors listed (Stripe, Anthropic, Twilio, Vapi, Resend, Mapbox, Google)
  - Security measures
  - Breach notification
  - Termination and data return
- `/legal/security` — security overview (encryption at rest, in transit, access controls, audit logging, etc.)
- Each page top: BIG yellow banner: **"DRAFT — Not yet legally reviewed. Do not rely on these terms until reviewed by counsel."**
- A `/legal/_status` admin page tracks which legal documents have been reviewed, by whom, on what date
- Until `PLATFORM_DPA_REVIEW_DATE` env var is set, the public signup flow is gated with a soft warning: "We're in beta. Legal terms are draft." (Tenants can still sign up but are explicitly informed.)
- Smoke test: visit each legal page, verify draft banner is present, verify the gate banner shows on signup

### Checkpoint 13 — Sales materials package
- `/sales` directory in repo (not on the public site)
- Contains:
  - **Pitch deck** (PDF, generated from MDX): 10-slide deck for cold outreach
  - **One-pager** (PDF): single-page comparison vs McLeod / Samsara / Tailwind / Truckbase
  - **Demo script**: 15-minute walkthrough script with what to click and say
  - **Email templates**: outreach, follow-up, demo recap, proposal
  - **ROI worksheet** (PDF, fillable): for prospects to fill in their numbers
- These are tooling for YOU (the operator) — not user-facing
- Generated to PDF the same way as the project brief was
- Smoke test: generate each PDF, verify they look professional and have current pricing

### Checkpoint 14 — Tenant migration tooling
- Command-line script: `pnpm tenant:export <tenant-id>`
  - Exports tenant's data (customers, trucks, employees, jobs, calendar, messages, documents) to a tarball
  - Includes their tenant_settings, branding assets, custom domain config
  - Encrypted with a passphrase
- Command-line script: `pnpm tenant:import <tarball> <new-server>`
  - Restores a tenant on a new NobleDispatch installation
- Use case: when an Enterprise or White Label customer wants to move to their own VPS, this is the tool
- Charge a one-time fee for migration ($500–$2,000) — pricing surfaced on the marketing site
- Smoke test: export ID Hotshot, import to a fresh test database, verify all data is intact and the tenant can log in

### Checkpoint 15 — Final integration tests + go-live readiness

End-to-end Phase 4 scenarios:

**Scenario A: Self-serve trial conversion**
1. Visitor lands on nobledispatch.com from a search
2. Reads pricing, runs ROI calculator
3. Clicks "Start free trial" → completes signup wizard
4. Verifies Stripe Checkout in trial mode (no charge)
5. Lands in their new tenant dashboard with onboarding checklist
6. Adds first truck, employee, customer, creates first job
7. Day 14: Stripe charges them, status moves to 'active', subscription kicks in
8. Receives invoice via email, can view billing history in `/admin/billing`

**Scenario B: Custom domain provisioning**
1. Pro-tier tenant visits `/admin/settings/domains`
2. Adds `dispatch.theircompany.com`
3. Adds the TXT record to their DNS
4. Verification succeeds within 30 seconds
5. SSL provisions via certbot
6. Tenant can now access app at their custom domain
7. Original subdomain still works as fallback

**Scenario C: Cancellation and grace period**
1. Tenant clicks "Cancel" in `/admin/billing`
2. Confirmation modal, cancel goes through
3. Stripe webhook fires `customer.subscription.deleted`
4. Tenant continues to have access through end of paid period
5. After period end, subscription status moves to 'canceled', read-only mode
6. After 30 more days, archived; tenant_owner offered data export

**Scenario D: Operator dashboard verification**
1. Superadmin (Noble Glitch) logs in
2. Sees current MRR, ARR, tenant counts, churn
3. Drills into a specific tenant from the at-risk list
4. Can override their plan, extend trial, refund, suspend manually

Update `/opt/nobledispatch/WAKE_UP_README.md` with Phase 4 section:
- Status of every checkpoint
- Critical reminders: legal review status, Stripe live-mode status, custom domain queue
- New URLs (marketing, app, docs, status)
- Phase 4 stubs that still need outside work (legal review, marketing email service connection, sales materials)

Final commit: `[phase 4 / checkpoint 15] Phase 4 complete — platform ready for paying tenants pending legal review`

---

## PHASE 4 SCOPE — what to BUILD vs what to STUB

### BUILD (Phase 4 — this session):
✅ Marketing site at nobledispatch.com
✅ ROI calculator
✅ Self-serve signup flow with 14-day trial
✅ Onboarding checklist
✅ Platform billing webhooks
✅ Subscription management UI for tenants
✅ Past-due/suspension automation
✅ Custom domain mapping with SSL
✅ Operator dashboard (MRR, churn, etc.)
✅ Documentation site
✅ Self-hosted status page
✅ Legal page stubs (clearly marked as drafts)
✅ Sales materials (PDFs, internal use)
✅ Tenant migration tooling

### STUB ONLY (post-Phase 4 work, requires outside expertise):
🔧 Legal review of ToS/Privacy/DPA — get an attorney
🔧 Real marketing emails (drip campaigns) — use Loops or ConvertKit, requires copywriting
🔧 SEO/content marketing — long-term effort, separate from build
🔧 Paid ads / cold outreach — sales work, separate from build
🔧 Cloudflare for SaaS migration (if scaling past ~50 custom domains)

### DO NOT BUILD (out of scope entirely):
❌ Mobile-native apps (PWA covers most use cases)
❌ Multi-region / global deployment
❌ Reseller/partner portal (revisit if it becomes relevant)
❌ White-label sub-platforms (a tenant licensing the platform to OTHER tenants — different model entirely)
❌ Industry-specific integrations beyond what Phases 1–3 cover (ELD, factoring, brokers' load boards) — those are partnerships, not features

---

## OUTPUT FORMAT FOR THE STATUS LOG

Continue the format from prior phases with `[PHASE 4 / CHECKPOINT N]` tag.

```
[2026-07-15 02:14:33] [PHASE 4 / CHECKPOINT 3] [START] Self-serve signup flow
[2026-07-15 02:14:51] [PHASE 4 / CHECKPOINT 3] [INFO] Signup wizard 5 steps wired
[2026-07-15 02:15:08] [PHASE 4 / CHECKPOINT 3] [INFO] Stripe Checkout in trial mode (14 days), no charge until trial ends
[2026-07-15 02:15:34] [PHASE 4 / CHECKPOINT 3] [TEST] Test signup with card 4242 - tenant created, login works (PASS)
[2026-07-15 02:15:48] [PHASE 4 / CHECKPOINT 3] [TEST] Phase 1+2+3 regression - login + Driver Mode + AI dispatch (PASS)
[2026-07-15 02:16:02] [PHASE 4 / CHECKPOINT 3] [GIT] Committed
[2026-07-15 02:16:03] [PHASE 4 / CHECKPOINT 3] [DONE] ✅
```

---

## FINAL OUTPUTS Claude Code should produce

1. ✅ All Phase 1+2+3 functionality remains working
2. ✅ Marketing site live at https://nobledispatch.com
3. ✅ Documentation live at https://docs.nobledispatch.com
4. ✅ Status page live at https://status.nobledispatch.com
5. ✅ Self-serve signup flow tested in Stripe test mode
6. ✅ A test tenant successfully created via self-serve, used for one week, churned, archived
7. ✅ A test custom domain provisioned and reachable
8. ✅ Operator dashboard showing realistic test metrics
9. ✅ Legal pages exist with clear DRAFT banners
10. ✅ Sales materials PDFs in /sales directory
11. ✅ Migration tooling tested with ID Hotshot data export

---

## ===== PROMPT END =====

## After Claude Code finishes — what to check

1. **Visit nobledispatch.com** — does the marketing site look good? Read the copy critically. Does it convey what the product does?
2. **Run through self-serve signup as a fake company** — fill it out, complete trial signup, verify everything works.
3. **Custom domain test** — provision a real domain you control, verify SSL works.
4. **Read the legal pages.** They're drafts. Don't push to live mode until an attorney has reviewed them.
5. **Check the operator dashboard** — does it show ID Hotshot as your one tenant? MRR is $0 because Danielle isn't paying you (she owns the platform). That's expected.
6. **Don't switch Stripe to live until:**
   - Legal review is documented (the env var unlocks the switch)
   - You've tested at least 3 full self-serve signup → trial → conversion flows in test mode
   - Your accountant has reviewed the sales tax / Stripe Tax setup

---

## What's left after Phase 4

**Phase 4 completes the buildable platform.** What remains is *operating* the business:

- Get an attorney to review the legal stubs ($1,500–$5,000)
- Set up a real CPA who understands SaaS ($500–$2,000 to onboard)
- Sales: outreach, demos, content marketing, conferences
- Customer success: onboarding, training, retention
- Continuous product work: bug fixes, feature requests from real customers

Those aren't software builds. They're business activities. The platform is done — running a SaaS company is the next chapter, and that's all you.

---

**Created by The Noble Glitch · thenobleglitch.com · 2026**

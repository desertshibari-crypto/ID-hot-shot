# NobleDispatch — Phase 2 Deployment Prompt for Claude Code

**For:** Boston 2 VPS (continuing on Phase 1 deployment)
**Project root:** `/opt/nobledispatch` (existing)
**Phase:** 2 of 4 — Driver Experience Layer + Real-time + Pay/Export
**Prerequisites:** Phase 1 deployed, healthy, and verified

---

## How to run this

```bash
# 1. Verify Phase 1 is healthy first
curl -I https://nobledispatch.idhotshot.com    # should return 200
curl -I https://idhotshot.com                  # should still return 200
cd /opt/nobledispatch && git log --oneline | head -20   # should show all 18 Phase 1 checkpoints

# 2. Add Phase 2 env vars to /root/nobledispatch.env (see PRE-FLIGHT below)
nano /root/nobledispatch.env

# 3. Source them and launch Claude Code with autonomous mode + this prompt
source /root/nobledispatch.env
claude --dangerously-skip-permissions < /root/NOBLEDISPATCH_PHASE2_DEPLOY.md

# 4. From a SECOND SSH window, watch the build:
tail -f /var/log/nobledispatch-build.log

# 5. Go to bed.
```

---

## PRE-FLIGHT — additional env vars for Phase 2

Append to `/root/nobledispatch.env`:

```bash
# === REQUIRED FOR PHASE 2 ===

# Web Push (generate with: npx web-push generate-vapid-keys)
export VAPID_PUBLIC_KEY="<base64 string>"
export VAPID_PRIVATE_KEY="<base64 string>"
export VAPID_SUBJECT="mailto:dispatch@idhotshot.com"

# Real email — Resend (https://resend.com/api-keys)
# Free tier = 100 emails/day, plenty for Phase 2
export RESEND_API_KEY="re_xxxxxxxxxxxxxxxxxxxx"
export EMAIL_FROM="dispatch@idhotshot.com"        # must be verified in Resend
export EMAIL_REPLY_TO="dispatch@idhotshot.com"

# === OPTIONAL — graceful degradation if missing ===

# ElevenLabs for premium TTS (default is Web Speech API, free, on-device)
export ELEVENLABS_API_KEY=""
export ELEVENLABS_VOICE_ID="21m00Tcm4TlvDq8ikWAM"   # default warm female voice

# S3-compatible storage (default is local disk)
# Backblaze B2 or Cloudflare R2 recommended — cheap and S3-compatible
export S3_ENDPOINT=""                            # e.g. https://s3.us-west-002.backblazeb2.com
export S3_REGION=""                              # e.g. us-west-002
export S3_BUCKET=""
export S3_ACCESS_KEY=""
export S3_SECRET_KEY=""

# Twilio (still optional in Phase 2 — only used for SMS verification of 2FA backup)
export TWILIO_ACCOUNT_SID=""
export TWILIO_AUTH_TOKEN=""
export TWILIO_FROM_NUMBER=""
```

Verify before running:
```bash
# Phase 1 services are running
docker compose -f /opt/nobledispatch/docker-compose.yml ps
# Should show: app, postgres, redis — all "Up (healthy)"

# Database has Phase 1 schema
docker compose -f /opt/nobledispatch/docker-compose.yml exec postgres \
  psql -U nobledispatch -d nobledispatch -c "\dt app.*"
# Should list jobs, customers, trucks, employees, calendar_events, messages, etc.
```

---

## ===== PROMPT BEGIN — EVERYTHING BELOW IS FOR CLAUDE CODE =====

You are extending **NobleDispatch** with Phase 2 features. Phase 1 is deployed at `https://nobledispatch.idhotshot.com` and running on this server. Your job is the **Driver Experience Layer** + real-time infrastructure + pay/export modules.

This is **safety-critical work**. Phase 2 includes Driver Mode — a UI that locks while a driver's vehicle is moving. Bugs here can hurt people. Build conservatively. Test thoroughly. When in doubt, fail to a safer state (locked, not unlocked).

---

## HARD SAFETY RAILS — same rules as Phase 1 + additions

1. **Work directory remains `/opt/nobledispatch`.** Do not write outside it except for nginx (already configured) and `/var/log/nobledispatch-build.log`.

2. **Phase 1 must remain functional through every checkpoint.** After every checkpoint, smoke-test that:
   - `https://nobledispatch.idhotshot.com` still returns 200 with a working login page
   - `https://idhotshot.com` still returns 200
   - Existing jobs/calendars/customers still load
   - Phase 1 users can still log in and operate normally
   If any of these break, STOP, log clearly, and roll back the last commit.

3. **Database migrations are additive only.** Add tables, add columns. Never drop or rename in Phase 2. If a Phase 1 design needs revision, leave a TODO comment and surface it in the wake-up package — don't refactor under autonomous execution.

4. **Driver Mode safety defaults:** if speed cannot be determined (no GPS, browser denied geolocation, sensor failure) → **lock the screen**. Default to safe. The unlock code path requires *positive evidence* of stationary state (14+ seconds of speed < 5 mph), not absence of evidence of motion.

5. **Real-time WebSocket must not break Phase 1's polling fallback.** Both should coexist. If WS drops, polling resumes. Drivers should never see "disconnected — go check your wifi" while on a job.

6. **Push notifications and TTS are opt-in per user.** Default OFF on first deploy. User explicitly enables in their settings. Do NOT auto-enable based on role.

7. **Continue git commits per checkpoint.** Continue status logging to `/var/log/nobledispatch-build.log`. Continue the same `[YYYY-MM-DD HH:MM:SS] [PHASE 2 / CHECKPOINT N] [LEVEL]` format.

8. **STOP conditions** for Phase 2:
   - Phase 1 stops responding
   - Database migration fails
   - Driver Mode tests fail (locked state can't be verified, or unlock condition is wrong)
   - WebSocket server can't bind to its port
   - Required env vars missing for required Phase 2 features

---

## STACK ADDITIONS for Phase 2

| Need | Choice | Why |
|---|---|---|
| Real-time | `ws` package + Redis Pub/Sub | Lean, self-hosted, scales horizontally |
| TTS (default) | Web Speech API | Free, built-in, on-device, no API limit |
| TTS (premium) | ElevenLabs (only if key provided) | Optional upgrade path |
| Push notifications | Web Push API + `web-push` lib | Cross-platform, no third-party |
| Email | Resend + `react-email` | Modern, deliverable, cheap |
| 2FA | `otplib` (TOTP) | Standard, works with any authenticator |
| QR codes | `qrcode` package | For 2FA setup screens |
| Photo capture | `getUserMedia` + canvas compression | Native browser, no library |
| Geolocation | `Geolocation API` (browser native) | Free, accurate enough for our needs |
| QuickBooks export | Custom CSV (IIF format compat) | No SDK needed for CSV; OAuth API is Phase 3 |
| PDF (pay stubs/checks) | `@react-pdf/renderer` (already in Phase 1) | Reuse |
| S3-compatible | `@aws-sdk/client-s3` | Works with Backblaze, R2, AWS, MinIO |

---

## DATABASE MIGRATIONS — Phase 2 additions

All additive. New tables + columns. RLS enabled where tenant-scoped.

```sql
-- New columns on existing tables
ALTER TABLE system.users ADD COLUMN totp_secret TEXT;
ALTER TABLE system.users ADD COLUMN totp_enabled BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE system.users ADD COLUMN backup_codes JSONB;
ALTER TABLE system.users ADD COLUMN push_subscriptions JSONB DEFAULT '[]';
ALTER TABLE system.users ADD COLUMN tts_preferences JSONB DEFAULT '{"enabled":false,"rate":1.0,"voice":"default","alertTypes":{}}';
ALTER TABLE system.users ADD COLUMN sound_preferences JSONB DEFAULT '{}';

ALTER TABLE app.employees ADD COLUMN current_lat DOUBLE PRECISION;
ALTER TABLE app.employees ADD COLUMN current_lng DOUBLE PRECISION;
ALTER TABLE app.employees ADD COLUMN current_speed_mph DOUBLE PRECISION;
ALTER TABLE app.employees ADD COLUMN location_updated_at TIMESTAMPTZ;
ALTER TABLE app.employees ADD COLUMN last_seen_at TIMESTAMPTZ;

ALTER TABLE app.jobs ADD COLUMN pickup_arrived_at TIMESTAMPTZ;
ALTER TABLE app.jobs ADD COLUMN pickup_departed_at TIMESTAMPTZ;
ALTER TABLE app.jobs ADD COLUMN dropoff_arrived_at TIMESTAMPTZ;
ALTER TABLE app.jobs ADD COLUMN dropoff_departed_at TIMESTAMPTZ;
ALTER TABLE app.jobs ADD COLUMN driver_mode_started_at TIMESTAMPTZ;
ALTER TABLE app.jobs ADD COLUMN driver_mode_ended_at TIMESTAMPTZ;

ALTER TABLE app.documents ADD COLUMN captured_lat DOUBLE PRECISION;
ALTER TABLE app.documents ADD COLUMN captured_lng DOUBLE PRECISION;
ALTER TABLE app.documents ADD COLUMN captured_at TIMESTAMPTZ;
ALTER TABLE app.documents ADD COLUMN storage_provider TEXT NOT NULL DEFAULT 'local';
ALTER TABLE app.documents ADD COLUMN storage_key TEXT;

-- New: location history (don't bloat employees table with this)
CREATE TABLE app.employee_locations (
  id BIGSERIAL PRIMARY KEY,
  tenant_id UUID NOT NULL,
  employee_id UUID NOT NULL REFERENCES app.employees(id) ON DELETE CASCADE,
  job_id UUID REFERENCES app.jobs(id) ON DELETE SET NULL,
  lat DOUBLE PRECISION NOT NULL,
  lng DOUBLE PRECISION NOT NULL,
  speed_mph DOUBLE PRECISION,
  heading_deg DOUBLE PRECISION,
  accuracy_m DOUBLE PRECISION,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON app.employee_locations (tenant_id, employee_id, recorded_at DESC);
CREATE INDEX ON app.employee_locations (tenant_id, job_id, recorded_at) WHERE job_id IS NOT NULL;
-- Retain only 90 days of history per location
-- (Phase 2 sets up the table; a separate cron job/BullMQ task prunes — define it but schedule it conservatively)

-- New: tenant-level alert sound config
CREATE TABLE app.alert_sounds (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  alert_type TEXT NOT NULL,            -- 'job_assigned' | 'message_received' | 'admin_call_request' | 'route_deviation' | 'arrival' | 'priority'
  label TEXT NOT NULL,
  sound_url TEXT NOT NULL,             -- /storage/<tenant>/sounds/<file>
  enabled_by_default BOOLEAN NOT NULL DEFAULT true,
  is_priority BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- New: pay periods (Phase 1 created the table; Phase 2 wires the calculation)
ALTER TABLE app.employee_pay_periods ADD COLUMN line_items JSONB DEFAULT '[]';
ALTER TABLE app.employee_pay_periods ADD COLUMN deductions JSONB DEFAULT '[]';
ALTER TABLE app.employee_pay_periods ADD COLUMN net_pay NUMERIC(10,2);
ALTER TABLE app.employee_pay_periods ADD COLUMN approved_by UUID REFERENCES system.users(id);
ALTER TABLE app.employee_pay_periods ADD COLUMN approved_at TIMESTAMPTZ;
ALTER TABLE app.employee_pay_periods ADD COLUMN paid_at TIMESTAMPTZ;
ALTER TABLE app.employee_pay_periods ADD COLUMN export_data JSONB;
ALTER TABLE app.employee_pay_periods ADD COLUMN paystub_url TEXT;

-- New: voice messages (separate from text messages for clarity)
CREATE TABLE app.voice_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  message_id UUID REFERENCES app.messages(id) ON DELETE CASCADE,
  audio_url TEXT NOT NULL,
  duration_seconds NUMERIC,
  transcript TEXT,                     -- optional, populated by Phase 3 AI
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- New: admin call requests (priority workflow)
CREATE TABLE app.call_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  from_user_id UUID NOT NULL REFERENCES system.users(id),
  to_employee_id UUID NOT NULL REFERENCES app.employees(id),
  subject TEXT,
  status TEXT NOT NULL DEFAULT 'pending',  -- pending | acknowledged | called_back | dismissed
  acknowledged_at TIMESTAMPTZ,
  called_back_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS on all new tenant-scoped tables (employee_locations, alert_sounds, voice_messages, call_requests)
-- with the same tenant_isolation policy used in Phase 1
```

---

## BUILD ORDER — execute in this sequence with checkpoints

After EVERY checkpoint:
1. Run smoke tests against the new feature
2. Run smoke tests against Phase 1 (must still work)
3. `git add -A && git commit -m "[phase 2 / checkpoint N] description"`
4. Append a clear status line to `/var/log/nobledispatch-build.log`
5. Move on

### Checkpoint 0 — Phase 1 health verification
- Confirm `https://nobledispatch.idhotshot.com` and `https://idhotshot.com` both return 200
- Confirm Phase 1 docker containers are healthy
- Confirm `git log` shows all 18 Phase 1 checkpoints
- Confirm required Phase 2 env vars (`VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `RESEND_API_KEY`, `EMAIL_FROM`) are present
- If any check fails, STOP. Phase 2 cannot proceed without a healthy Phase 1.
- Run all migrations from this prompt's "Database Migrations" section. Verify they applied successfully.

### Checkpoint 1 — Real-time WebSocket infrastructure
- Add a WebSocket server (`ws` package) running on port 3002 inside the app container
- Authentication: WS connection upgrades carry the auth cookie/token; verify on connect, attach `tenantId` and `userId` to the socket
- Topics/rooms: `tenant:<tenantId>:user:<userId>` (private), `tenant:<tenantId>:role:<role>` (broadcast), `tenant:<tenantId>:job:<jobId>` (job participants)
- Redis Pub/Sub between app instances (so multiple workers can broadcast to the same room)
- Client-side hook `useRealtime(topic)` with auto-reconnect and exponential backoff
- Fall back to existing polling if WS connection fails 3x in a row
- Update Nginx to proxy `/ws` to port 3002 with `proxy_http_version 1.1`, upgrade headers, long timeouts
- Smoke test: open two browser tabs as two different users in same tenant, send a message, verify it appears instantly in the other tab without refresh

### Checkpoint 2 — Push notification infrastructure
- Service worker registered at `/sw.js` (already exists from Phase 1 PWA setup, extend it)
- VAPID keys from env, expose public key via `/api/push/vapid`
- Endpoint `POST /api/push/subscribe` saves subscription to `users.push_subscriptions`
- Endpoint `POST /api/push/test` sends a test notification (admin-only)
- `lib/push.ts` helper: `sendPush(userId, payload)` — payload includes title, body, icon, tag, data (for routing on click)
- On notification click, service worker focuses or opens the relevant URL
- Settings page lets users enable/disable push, request browser permission
- Smoke test: enable push as a test driver user, send a test notification from admin, verify it arrives even with the tab in background

### Checkpoint 3 — Driver Mode UI shell
- New route `/driver/job/[jobId]/active` — the in-cab UI
- Layout: full-screen, no top/bottom nav, dark theme by default
- Three states: `EN_ROUTE_TO_PICKUP` → `AT_PICKUP` → `EN_ROUTE_TO_DROPOFF` → `AT_DROPOFF` → `COMPLETE`
- Each state shows: large destination address, ETA, distance, big primary action button, bottom strip with truck/job number
- Top-right corner: signal indicator (GPS, network, WS), brightness toggle (auto/manual)
- Auto theme: switches to dark mode after sunset based on browser local time + lat/lng
- "Navigate" button opens device-native nav via deep link picker:
  - Google Maps: `https://www.google.com/maps/dir/?api=1&destination=LAT,LNG&travelmode=driving`
  - Waze: `https://waze.com/ul?ll=LAT,LNG&navigate=yes`
  - Apple Maps: `https://maps.apple.com/?daddr=LAT,LNG`
- "Job Details" button opens an overlay with full instructions, customer contact, special notes
- "Messages" button shows unread count, opens chat overlay
- Driver Mode is the default landing for `driver` role users when they have an active assigned job
- Smoke test: assign a job to a driver user, log in as them, verify Driver Mode loads cleanly

### Checkpoint 4 — Movement detection + screen lock
**The safety-critical checkpoint.** Build conservatively.

- Browser `Geolocation.watchPosition()` with `enableHighAccuracy: true`, requests every ~3 seconds while in Driver Mode
- Compute speed: prefer `position.coords.speed` (m/s, sometimes null) → fallback compute from successive lat/lng deltas + timestamps
- Convert to mph
- State machine:
  ```
  STATIONARY → (speed > 5 mph for 2+ readings) → MOVING (LOCKED)
  MOVING → (speed < 5 mph for 14+ seconds continuously) → STATIONARY (UNLOCKED)
  ```
- LOCKED state UI:
  - Full-screen overlay: large directional arrow, next-instruction text, ETA
  - All other UI hidden, no scrollable content, no buttons except Emergency
  - Single "Emergency" button in corner (long-press 3s to activate; logs to audit_log; offers to call 911 or dispatch)
  - TTS announces upcoming turns (when nav data available) and incoming messages
- Default to LOCKED if:
  - Geolocation permission denied
  - GPS signal lost for > 10 seconds
  - Movement state cannot be determined
- Settings: tenant_owner can adjust the lock threshold (default 5 mph, 14 sec) within safe bounds (3-10 mph, 10-30 sec). Drivers cannot override.
- Audit log entries: `driver_mode_locked`, `driver_mode_unlocked`, `driver_mode_emergency_activated`
- Smoke test (manual): on a phone, simulate motion using Chrome DevTools sensors panel to set speed values, verify lock/unlock transitions
- Smoke test (automatic): unit test the state machine logic with mock speed inputs
- **Document the safety logic clearly** in `/opt/nobledispatch/docs/DRIVER_MODE_SAFETY.md` for future engineers

### Checkpoint 5 — Text-to-speech engine
- `lib/tts.ts` provides `speak(text, options)` and `cancel()`
- Default: Web Speech API via `window.speechSynthesis`
- If `ELEVENLABS_API_KEY` is set: optional premium voice per tenant (admin enables in settings, falls back to Web Speech if quota exceeded or call fails)
- User preferences in `users.tts_preferences`:
  - Master enable/disable
  - Per alert type enable/disable (job_assigned, message_received, admin_call_request, etc.)
  - Voice (system voice list)
  - Rate (0.5x to 2.0x)
- TTS is invoked automatically for:
  - Incoming messages while in Driver Mode
  - Admin call requests (priority — always speaks regardless of mute state)
  - Job assignment notifications (only while in Driver Mode)
- Settings page with "Test voice" button
- Smoke test: enable TTS as a driver, send a message from admin, verify it speaks

### Checkpoint 6 — Configurable alert sounds
- Default alert sounds bundled in `/public/sounds/` (use royalty-free or generated tones — DO NOT use copyrighted sounds):
  - `job-assigned.mp3` — short ascending chime
  - `message.mp3` — soft bell
  - `admin-call.mp3` — distinctive 2-tone
  - `priority.mp3` — urgent buzz
  - `arrival.mp3` — pleasant ding
  - `route-deviation.mp3` — soft warning
- Tenant admin can upload custom sound files (mp3, wav, ogg) per alert type → stored as documents → referenced in `alert_sounds` table
- Per-user override in user settings: enable/disable per alert type, swap to a different default
- `lib/audio.ts` provides `playAlert(alertType, userId)` which:
  - Resolves user preferences
  - Falls back to tenant defaults
  - Plays the sound via `<audio>` element (works with Bluetooth-paired devices because the OS handles audio routing)
  - Respects browser autoplay policies (will fail silently if no user gesture has occurred — expected)
- Smoke test: test each alert type, verify sound plays

### Checkpoint 7 — Geofencing + auto check-in
- Distance computation: haversine formula in `lib/geo.ts`
- For each active job assigned to current driver, check every location update:
  - If within 100m of `pickup_location.lat/lng` and `pickup_arrived_at` is null → prompt "Mark as arrived at pickup?" with a 30-second countdown to auto-confirm
  - If pickup is confirmed and current location is >500m from pickup and `pickup_departed_at` is null → set `pickup_departed_at`
  - Same logic for dropoff
- Toast/notification + sound when geofence triggers
- Driver can manually override (back button, "I haven't arrived yet")
- Updates job `pickup_arrived_at`, `pickup_departed_at`, `dropoff_arrived_at`, `dropoff_departed_at` timestamps
- These timestamps feed time tracking and pay calculations
- Smoke test: simulate driver location near a job's pickup, verify prompt appears

### Checkpoint 8 — Photo capture
- `<input type="file" accept="image/*" capture="environment">` for the simple path
- Custom in-app camera UI for the rich path:
  - `getUserMedia({ video: { facingMode: 'environment' } })`
  - Live preview on canvas
  - Capture button takes still
  - Auto-compress to <1MB at 1920px max dimension before upload
  - Geotag with current location (employee_locations join via `captured_lat/lng/at`)
- Categorize on save: BOL, POD, damage, signature, other
- Upload via existing documents API (Phase 1)
- Photos appear on job detail page, ordered by capture time
- Smoke test: open Driver Mode on a phone/tablet with camera, capture a photo, verify it lands on the job record with location data

### Checkpoint 9 — Voice messages
- Record button in chat composer (driver UI especially)
- `MediaRecorder` API → `audio/webm` blob → upload to documents → `voice_messages` row links to message
- Playback in chat: simple `<audio controls>`, scrubber, speed (1x/1.5x/2x)
- Max 2 minutes per voice message (enforced client and server)
- Smoke test: record + send a voice message, play back from another user

### Checkpoint 10 — ADMIN-requests-call workflow
- Admin/dispatcher button on employee profile and chat thread: "Request Call Back"
- Optional subject ("Last-minute pickup change", "Question about Acme job", etc.)
- Creates `call_requests` row + sends:
  - Push notification (high priority)
  - WS broadcast to that employee's active sessions
  - TTS readout (if enabled): "[Admin name] from dispatch requests a call when you're able"
  - Distinct alert sound (`admin-call.mp3`)
  - Visible banner in driver UI that persists until acknowledged or dismissed
- Driver actions: "Acknowledge" (just dismiss) or "Call Now" (tel: link to admin's phone)
- Status reflected back to admin in real-time
- Smoke test: admin requests call, verify driver gets all three alert channels, acknowledge updates admin view

### Checkpoint 11 — Real email via Resend
- `lib/email.ts` with `sendEmail({to, subject, react|html, text})`
- Templates in `emails/` using `react-email`:
  - `WelcomeEmail` — when a user is invited (replaces console-log stub from Phase 1)
  - `PasswordReset` — secure token, 30-min expiry
  - `JobAssigned` — for drivers assigned a job (in addition to push)
  - `WeeklyDigest` — Sunday night summary for tenant owners (jobs completed, miles driven, revenue)
  - `PaystubReady` — when a pay period is approved
- Tenant settings: enable/disable per template
- Smoke test: trigger each template, verify delivery to a real email inbox

### Checkpoint 12 — 2FA (TOTP)
- Setup flow:
  - User clicks "Enable 2FA" in settings
  - Server generates secret, returns QR code (otpauth URL via `qrcode` package)
  - User scans with Google Authenticator / Authy / 1Password
  - User enters first code to confirm setup
  - Server generates 10 backup codes, displays once, stores hashed
- Login flow:
  - After password, if `totp_enabled`, prompt for 6-digit code or backup code
  - 5-minute window grace period for clock skew
- 2FA is **required** for `superadmin` role and **strongly encouraged** (banner) for `tenant_owner`. Optional for others.
- Recovery: 2FA reset requires super admin intervention or backup code use.
- Smoke test: enable 2FA, log out, log in with code, log in with backup code

### Checkpoint 13 — Pay calculator
- Pay period UI: list (filterable by status, date, employee), detail (line items + computed totals)
- Generate pay period: pick date range, pick employees → server iterates `job_time_entries` and `jobs` for the range, computes:
  - **Per-mile**: sum of `jobs.distance_miles` for assigned + completed jobs × employee.pay_rate
  - **Hourly**: sum of `(end_at - start_at)` for billable time entries × pay_rate
  - **Salary**: pro-rata of period
  - **Percentage**: % of `jobs.rate_final` for assigned jobs
  - Mixed: configurable
- Line items: each contributing job/entry shown
- Deductions: manual entry (taxes, advances, equipment costs) — Phase 2 keeps it manual; Phase 3 may add tax tables
- Approval: tenant_owner approves → status moves to `approved` → triggers email
- Smoke test: create a pay period for an employee with completed jobs, verify math

### Checkpoint 14 — QuickBooks CSV export
- Generate CSV in QuickBooks Desktop IIF format AND a simpler "QuickBooks Online compatible" CSV
- Export endpoint: `/api/pay-periods/[id]/export.iif` and `.csv`
- Include: pay date, employee name, gross pay, net pay, line item descriptions
- Tenant settings: chart of accounts mapping (which QuickBooks account names to use)
- Mark pay period as `exported_to: quickbooks_iif` after download
- Smoke test: export a pay period, open IIF file in a text editor, validate format

### Checkpoint 15 — Printable pay stubs / checks
- Pay stub PDF (`@react-pdf/renderer`) — same letterhead engine as Phase 1 invoices
  - Tenant logo + brand
  - Employee info, pay period, gross/net, line items, deductions, YTD totals
  - "Powered by NobleDispatch / The Noble Glitch" footer
- Printable check PDF (with MICR-line if user provides routing/account info)
  - Big disclaimer in the UI: "Test the print alignment with a void check first. NobleDispatch does not guarantee bank acceptance — verify with your bank."
  - MICR font included via `@font-face` (use the free MICRE13B-Regular font)
- Auto-saved to documents on generation, linked from pay period
- Smoke test: generate stub PDF, check PDF, verify MICR line renders

### Checkpoint 16 — S3-compatible storage abstraction
- `lib/storage.ts` exports a `StorageProvider` interface (already stubbed in Phase 1)
- Implementations: `LocalProvider` (Phase 1 default) and `S3Provider` (new)
- `S3Provider` uses `@aws-sdk/client-s3` with custom endpoint (works with Backblaze, R2, AWS, MinIO)
- Tenant setting: `storage_provider` = `local` | `s3`
- Migration command: `pnpm storage:migrate <tenantId> <fromProvider> <toProvider>` — moves files, updates `documents.storage_provider/storage_key`
- All file uploads go through `StorageProvider.put()`; downloads through `StorageProvider.get()` or signed URLs
- Smoke test: switch a tenant to S3, upload a new document, verify it lands in the bucket and is retrievable

### Checkpoint 17 — Audit log UI + export
- `/admin/audit` route (tenant_owner + dispatcher view their tenant's log; superadmin sees all tenants)
- Filterable: by user, action, entity type, date range
- Export to CSV
- Pagination (server-side, can be many rows)
- Audit log additions for Phase 2 actions: `driver_mode.locked`, `driver_mode.unlocked`, `driver_mode.emergency`, `geofence.triggered`, `pay_period.approved`, `pay_period.exported`, `2fa.enabled`, `2fa.disabled`, `push.subscribed`
- Smoke test: perform a few actions, verify they appear in the log

### Checkpoint 18 — Smoke tests + wake-up package
End-to-end driver scenario:
1. Login as driver on a tablet/phone-sized viewport → Driver dashboard
2. Tap an assigned job → Driver Mode loads
3. Navigate to pickup → simulate location → "Arrived at pickup" prompt fires
4. Confirm arrival → start TTS-read message from admin → message is spoken
5. Admin requests call back → priority alert with sound + TTS
6. Capture a photo (BOL) → uploads with geotag
7. Send a voice message → admin receives in real-time
8. Driver Mode auto-locks when speed simulated > 5mph
9. Stationary 14+ sec → auto-unlocks
10. Complete job → returns to driver dashboard
11. Tenant owner generates pay period for that driver → approves → exports IIF → generates pay stub PDF

Update `/opt/nobledispatch/WAKE_UP_README.md` with:
- Phase 2 status of every checkpoint (✅ or ⚠️)
- New URLs and features
- Driver Mode safety doc location
- 2FA setup instructions for the user
- Resend domain verification reminder (if using a custom from-address, they need to verify it in Resend's dashboard)
- Known limitations: `getUserMedia` requires HTTPS (already covered), iOS Safari has slight differences in `Geolocation` accuracy, push notifications work on iOS Safari only on iOS 16.4+ as installed PWA
- Phase 3 stubs (what's intentionally not built yet)

Final commit: `[phase 2 / checkpoint 18] Phase 2 complete — driver experience layer live`

---

## PHASE 2 SCOPE — what to BUILD vs what to STUB vs what's PHASE 3

### BUILD (Phase 2 — this session):
✅ Real-time WebSocket (with polling fallback)
✅ Push notifications
✅ Driver Mode UI + state machine
✅ Movement-aware screen lock with safety defaults
✅ Text-to-speech engine + per-alert prefs
✅ Configurable alert sounds (uploads + per-user prefs)
✅ Geofencing + auto check-in/out
✅ Photo capture with geotag
✅ Voice messages
✅ ADMIN-requests-call workflow
✅ Real email via Resend (replaces Phase 1 console-log stub)
✅ 2FA (TOTP)
✅ Pay calculator (per-mile, hourly, salary, percentage, mixed)
✅ QuickBooks CSV export
✅ Pay stub PDFs + printable checks (with MICR caveat)
✅ S3-compatible storage abstraction
✅ Audit log UI + CSV export

### DO NOT BUILD (Phase 3):
❌ AI Assisted Dispatch (Twilio + Vapi voice AI for inbound customer calls)
❌ AI copilots in forms (auto-extract job details from emails/SMS)
❌ Customer portal (loads in flight, invoice access, self-service booking)
❌ Reporting/analytics dashboards
❌ Payment processor integration (Stripe/Square)
❌ Custom domain mapping UI for white-label tenants
❌ Live chat → SMS routing to dispatcher's phone (Phase 1 stubbed this; full Twilio integration is Phase 3)
❌ Real-time GPS tracking display on admin map (Phase 2 STORES locations, Phase 3 displays the live map)

If you find yourself wanting to "just quickly add" any of these, **don't**. Stub them and move on.

---

## OUTPUT FORMAT FOR THE STATUS LOG

Continue Phase 1's format. Tag with `[PHASE 2 / CHECKPOINT N]` instead of `[CHECKPOINT N]`.

Example:
```
[2026-05-15 23:14:33] [PHASE 2 / CHECKPOINT 4] [START] Driver Mode movement detection
[2026-05-15 23:14:35] [PHASE 2 / CHECKPOINT 4] [INFO] Geolocation watchPosition wired with 3sec interval
[2026-05-15 23:14:51] [PHASE 2 / CHECKPOINT 4] [INFO] State machine: STATIONARY → MOVING transition tested with mock speed
[2026-05-15 23:15:12] [PHASE 2 / CHECKPOINT 4] [INFO] Lock UI overlay rendering correctly
[2026-05-15 23:15:34] [PHASE 2 / CHECKPOINT 4] [TEST] Smoke: 14sec stationary unlocks (PASS)
[2026-05-15 23:15:42] [PHASE 2 / CHECKPOINT 4] [TEST] Smoke: GPS lost defaults to locked (PASS)
[2026-05-15 23:15:48] [PHASE 2 / CHECKPOINT 4] [TEST] Smoke: emergency long-press logs audit (PASS)
[2026-05-15 23:15:55] [PHASE 2 / CHECKPOINT 4] [TEST] Phase 1 regression — login still works (PASS)
[2026-05-15 23:16:02] [PHASE 2 / CHECKPOINT 4] [GIT] Committed 'driver mode movement detection + lock state machine'
[2026-05-15 23:16:03] [PHASE 2 / CHECKPOINT 4] [DONE] ✅ 11 files changed, 487 insertions
```

---

## FINAL OUTPUTS Claude Code should produce

1. ✅ All Phase 1 functionality remains working
2. ✅ Phase 2 features live at `https://nobledispatch.idhotshot.com`
3. ✅ `/opt/nobledispatch/docs/DRIVER_MODE_SAFETY.md` exists and clearly documents the safety logic
4. ✅ `/var/log/nobledispatch-build.log` has clean Phase 2 narrative
5. ✅ `/opt/nobledispatch/WAKE_UP_README.md` updated with Phase 2 section
6. ✅ Git history shows all Phase 2 checkpoints as commits
7. ✅ Database has all Phase 2 migrations applied (no Phase 1 migrations rolled back)

---

## ===== PROMPT END =====

## After Claude Code finishes — what to check

1. **SSH in:** `tail -100 /var/log/nobledispatch-build.log` — should end with Phase 2 checkpoint 18 ✅
2. **Read** `/opt/nobledispatch/WAKE_UP_README.md` — full status report
3. **Driver Mode test (do this on an actual phone or tablet):**
   - Log in as a driver
   - Open an assigned job → Driver Mode
   - Walk around outside (or use Chrome DevTools → Sensors → spoof location/speed)
   - Verify lock activates above 5mph and unlocks 14sec after stopping
4. **Admin call request test:** request a call back → verify the driver gets the alert with sound + TTS
5. **Pay period test:** generate one for a driver with completed jobs, approve, export IIF, open in QuickBooks
6. **2FA setup:** enable on Danielle's account, log out, log back in with authenticator code

If something's broken: `cd /opt/nobledispatch && git log --oneline | head -25` shows every checkpoint. `git reset --hard <commit>` rolls back to any prior state. Phase 1 commits remain intact below Phase 2's.

---

## What's left after Phase 2

**Phase 3 — AI & growth (next session):**
- AI Assisted Dispatch (Twilio + Vapi voice AI for inbound customer calls)
- AI copilots: auto-extract jobs from emails/SMS, smart driver suggestions, route optimization hints
- Customer portal: loads in flight, invoice access, self-service booking
- Reporting/analytics dashboards (revenue per truck/driver/lane, deadhead %, on-time %)
- Payment processor (Stripe Connect for marketplace, or direct Stripe/Square)
- Live chat → SMS routing
- Real-time fleet map for admin (drivers' live positions on a map)

**Phase 4 — Multi-tenant scaling & sales (later):**
- nobledispatch.com marketing site
- Custom domain UI for white-label tenants
- Tenant onboarding wizard
- Billing engine (you billing your customers — recurring SaaS subscriptions)
- Sales materials and pitch deck

---

**Created by The Noble Glitch · thenobleglitch.com · 2026**

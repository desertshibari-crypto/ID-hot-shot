# idhotshot.com Website

A complete, working HTML prototype of the marketing website for ID Hotshot Transportation. Built as a single self-contained file with all design, animation, copy, and interactivity in place.

## Files

| File | What it is |
|---|---|
| `idhotshot_site.html` | The complete working website. Open in any browser to see it run. ~1.1 MB. |

## What's in the website

Single-page app with frame-based navigation between sections:

- **Hero** — cinematic logo banner, animated entry
- **Services** — flatbed, hotshot, expedited, last-mile
- **Rate calculator** — interactive pricing based on distance, equipment, expedite level
- **Booking** — calendar-based job booking form
- **Founder story** — Danielle Riley's narrative
- **Live chat widget** — fixed-position chat that integrates with NobleDispatch inbound queue (when deployed)
- **Contact** — phone, email, address, USDOT 4559278
- **Footer** — Powered by Noble Dispatch attribution

## How to preview

Open `idhotshot_site.html` in any modern browser:

- **Mac:** Double-click the file, or `open idhotshot_site.html`
- **Windows:** Double-click the file
- **Linux:** `xdg-open idhotshot_site.html`
- **Cloud preview:** drag-and-drop into any browser tab

No build step needed. No server needed. Just open it.

## Deploying to production

To deploy this as the live idhotshot.com:

1. Run the website deployment prompt at `prompts/00-website-deploy.md` against your VPS
2. That prompt sets up nginx, SSL, and serves this HTML file at the domain

The HTML is intentionally self-contained so it can be served as a single static file — no build process, no dependencies, no breakage from third-party CDNs.

## Editing the content

If you need to change copy, prices, services, or anything else: open `idhotshot_site.html` in any text editor (VS Code, Notepad++, Sublime Text). Search for the text you want to change. Save. Reload in browser. Done.

For larger changes (new sections, restructuring), the file is organized into clearly-commented sections — search for `<!-- SECTION:` to find the major dividers.

## A note on the chat widget

The chat widget posts to a backend endpoint that's part of the NobleDispatch platform (specifically the Phase 1 inbound queue). Until that's deployed, the widget will accept messages but they won't go anywhere — they'll just queue locally. Once Phase 1 is live, set the endpoint in the HTML (search for `CHAT_ENDPOINT_URL`) to your actual NobleDispatch URL.

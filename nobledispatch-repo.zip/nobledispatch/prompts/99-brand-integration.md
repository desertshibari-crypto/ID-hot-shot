# NobleDispatch — Visual Asset Integration Deployment Prompt

**Purpose:** Integrate the Noble Dispatch brand assets (banner, login design, dashboard mockups) into the deployed NobleDispatch platform.
**Scope:** Visual layer only — login page + dashboard layout + per-tenant logo upload system. NOT a new phase.
**For:** Boston 2 VPS
**Project root:** `/opt/nobledispatch` (existing Phase 1+ deploy)
**Prerequisites:** At minimum Phase 1 deployed and healthy. Phase 2-5 not required for this patch.

---

## What this patch does and what it doesn't

**Does:**
- Establishes a `public/brand/` directory for platform-level brand assets
- Rebuilds the login page using the Noble Dispatch banner image as a background hero
- Rebuilds the tenant dashboard shell to match the visual reference mockups (both light and dark themes)
- Adds per-tenant logo upload so ID Hotshot's red shield-truck logo can be replaced by other tenants
- Fixes a typo found in the mockup: "Noble ispatch" → "NobleDispatch"
- Establishes the "TENANT NAME | NOBLEDISPATCH" header pattern as a configurable platform-attribution feature

**Doesn't:**
- Embed the dashboard mockup images themselves as static images. The mockups show the *visual target*; we build real React components that match
- Touch the website at idhotshot.com (this is platform-only)
- Add new functionality — just visual polish
- Modify any database tables beyond a small addition to `app.tenant_settings`

---

## Pre-flight

```bash
# Verify Phase 1+ healthy
curl -I https://nobledispatch.idhotshot.com
cd /opt/nobledispatch && git status

# Brand assets — upload these 5 files to /opt/nobledispatch/public/brand/
# (they're attached separately to this prompt — see brand_assets/ directory)
#
#   noble_dispatch_banner.png         — full marketing/login background
#   noble_dispatch_login_reference.png — login composition reference (with Username/Password labels)
#   dashboard_light_mockup.png        — light theme dashboard visual target
#   dashboard_dark_mockup.png         — dark theme dashboard visual target
#
# Upload via scp:
scp /path/to/brand_assets/*.png \
    root@boston2:/opt/nobledispatch/public/brand/
```

After upload, verify:

```bash
ls -lh /opt/nobledispatch/public/brand/
# Should show all 4 PNG files
```

---

## ===== PROMPT BEGIN — EVERYTHING BELOW IS FOR CLAUDE CODE =====

You are integrating Noble Dispatch brand assets into the deployed platform. This is a visual patch, not a new feature phase. Stay focused — five checkpoints, smaller scope than any prior phase.

The brand asset files have been pre-uploaded to `/opt/nobledispatch/public/brand/`. Verify they exist before starting:

```bash
test -f /opt/nobledispatch/public/brand/noble_dispatch_banner.png || exit 1
test -f /opt/nobledispatch/public/brand/noble_dispatch_login_reference.png || exit 1
test -f /opt/nobledispatch/public/brand/dashboard_light_mockup.png || exit 1
test -f /opt/nobledispatch/public/brand/dashboard_dark_mockup.png || exit 1
```

If any are missing: STOP. Ask for upload.

---

## HARD SAFETY RAILS

All prior phase rails apply. Specific to this patch:

1. **The dashboard mockups (#4 and #5) are visual references, NOT to be embedded as images.** Build React components that *match* the design. The mockup PNGs stay in `public/brand/` as a reference for designers but are not displayed in production.

2. **The login banner (#1) IS used as a background image.** This is the one mockup that gets embedded directly. Optimize it for web (resize/compress as needed but keep readable text).

3. **Per-tenant logo upload must default to a generic NobleDispatch fallback when no tenant logo is set.** The red shield-truck logo seen in the mockups is ID Hotshot's tenant logo, not the platform's. Don't bake it in as the default.

4. **Typo fix is non-negotiable.** The mockup footer shows "Noble ispatch Powered, v1.5" — missing the D. The implemented footer reads "NobleDispatch · v[VERSION]" cleanly.

5. **Both light AND dark themes must work.** Mockup #4 is light, #5 is dark. Implement both. Theme toggle persists per user. Default to user's OS preference (`prefers-color-scheme`) on first visit.

6. **STOP conditions:**
   - Phase 1 services unhealthy after any change
   - Existing login/dashboard breaks for any user
   - Database migration fails

---

## DATABASE — small addition

Append to `app.tenant_settings`:

```sql
ALTER TABLE app.tenant_settings ADD COLUMN IF NOT EXISTS logo_url TEXT;
ALTER TABLE app.tenant_settings ADD COLUMN IF NOT EXISTS logo_uploaded_at TIMESTAMPTZ;

-- Set ID Hotshot's logo to the red shield-truck from the mockups (we'll save it as a tenant asset)
-- This happens in Checkpoint 4 after the upload system is built
```

---

## BUILD ORDER — 5 checkpoints

After EVERY checkpoint:
1. Smoke test the new visual works on desktop AND mobile (375px width)
2. Verify existing login + dashboard still work for ID Hotshot
3. `git add -A && git commit -m "[brand-integration / checkpoint N] description"`
4. Append status log
5. Continue

---

### Checkpoint 0 — Pre-flight verification

- Phase 1 healthy
- All 4 brand asset PNGs present in `/opt/nobledispatch/public/brand/`
- Apply schema migration (`logo_url`, `logo_uploaded_at` on `tenant_settings`)
- Image-optimize the banner: produce `noble_dispatch_banner_optimized.webp` and `noble_dispatch_banner_optimized.jpg` (1920px wide, ~80 quality). Keep original PNG as fallback.
- Log file sizes before/after; banner should drop from ~645KB to <200KB after optimization
- If anything fails: STOP

---

### Checkpoint 1 — Login page rebuild

Reference mockup: `noble_dispatch_login_reference.png` (image #3 with Username/Password labels)

**File:** `app/(auth)/login/page.tsx` (or equivalent existing path)

**Layout:**
- Full-screen background using the optimized banner image (`object-fit: cover`, center-anchored)
- Subtle dark overlay (rgba(0,0,0,0.15)) over the background so the login card has contrast
- **Noble Dispatch shield/compass logo** centered at top, ~340px wide
  - Generate this as inline SVG matching the dark steel + gold + compass-star design from the mockup
  - Save the SVG to `components/brand/NobleDispatchLogo.tsx`
- **Glass-morphism login card** below logo, centered:
  - ~480px wide, semi-transparent white background with backdrop-blur
  - Title: "NOBLE DISPATCH PLATFORM LOGIN" — uppercase, dark navy (#1a3a5c)
  - Username field with person icon prefix, placeholder "Username"
  - Password field with lock icon prefix, placeholder "Password"
  - Big steel-gradient "LOG IN" button with chevron decorations on both sides
  - Two links below: "Forgot Password?" and "Request Invite Code"
- **Footer pill** at bottom: the tenant's primary domain (e.g., "idhotshot.com" for ID Hotshot's login; "nobledispatch.com" for the platform's own login)

**Per-tenant theming:**
- Read `tenant_settings.logo_url` if a custom tenant logo is set — show it ABOVE the Noble Dispatch shield logo, smaller, with a thin gold separator between them
- This means: customer-facing tenant login = "[Tenant Logo] / [Noble Dispatch] / Login Form / tenant-domain.com pill"

**Responsive:**
- Mobile (<640px): logo scales to 240px, card to 92% width
- Tablet+ : as designed

**Smoke tests:**
- Visit `https://nobledispatch.idhotshot.com/login` — see the banner background, the Noble Dispatch logo, the glass login card, the idhotshot.com footer pill
- Try logging in as Danielle's account — must work end-to-end
- Open in mobile viewport — verify card scales and doesn't overflow
- Try with `tenant_settings.logo_url=NULL` — verify fallback to Noble Dispatch logo only

---

### Checkpoint 2 — Dashboard shell rebuild (light + dark themes)

Reference mockups: `dashboard_light_mockup.png` and `dashboard_dark_mockup.png`

**File:** `app/(app)/layout.tsx` and `app/(app)/dashboard/page.tsx`

**Header section (top of every page after login):**
- Left: Tenant logo (from `tenant_settings.logo_url`, fallback to placeholder)
- Center-left: Title pattern `[TENANT_NAME] | NOBLEDISPATCH`
  - Tenant name in tenant's primary color (red for ID Hotshot per existing brand)
  - Separator pipe in medium gray
  - "NOBLEDISPATCH" in dark/light theme-appropriate color
  - Subtitle below: `USDOT [tenant.usdot_number]`
- Right: Notification bell with red dot indicator (when unread), user avatar dropdown, settings gear

**Left sidebar nav (collapsible on mobile):**
- 11 items matching mockup order: Dashboard, Jobs, Calendars, Map, Inbound, Customers, Trucks, Employees, Messages, Documents, Settings
- Each item: icon + label, hover state shows red glow effect (matches mockup), active state shows persistent red border
- Icons should be Lucide icons (consistent with rest of platform): `Gauge`, `ClipboardList`, `Calendar`, `Map`, `Inbox`, `Users`, `Truck`, `UserCog`, `MessageSquare`, `FolderOpen`, `Settings`

**Main content area — Dashboard page:**
- Page heading "DASHBOARD" with thin red underline accent
- 5 KPI cards in a row (responsive: stack on mobile):
  - Active Jobs — count of jobs with status='active'/'in_transit'
  - Trucks — count of trucks where status='active', label "in fleet"
  - Employees — count of employees where status='active', label "active"
  - Customers — count of customers, label "on file"
  - Inbound — count of inbound_requests where status='pending', label "pending"
- Each card: rounded rectangle, red glowing border accent (subtle in light mode, more pronounced in dark mode), large number, small lowercase descriptor below

**Theme system:**
- Light mode: white/cream background (#fafafa), dark text, red accents
- Dark mode: dark gray base (#1a1a1a), carbon-fiber texture overlay on main content (CSS: subtle 45-degree pattern, see mockup #5), light text, red glow accents more vivid
- Theme toggle in user avatar dropdown
- Theme preference saved to `user_preferences` table (or localStorage as fallback)
- Default: respect `prefers-color-scheme` on first visit
- Carbon fiber texture: implement as CSS pattern or single small tileable PNG (~5KB) in `public/brand/textures/carbon_fiber.png`. Apply only to dark theme.

**Footer (bottom of every page):**
- Format: `[Copyright text] · NobleDispatch Powered · v[VERSION]`
- Notice: this fixes the "Noble ispatch" typo from the mockup
- VERSION pulled from `package.json` or env

**Smoke tests:**
- Log in as Danielle, land on Dashboard
- Verify the title shows "ID HOTSHOT | NOBLEDISPATCH" with USDOT 4559278 below
- Verify all 5 KPI cards show correct counts (may be zero — that's fine)
- Click each nav item — verify all 11 routes load and active state highlights correctly
- Toggle theme — verify both themes render cleanly, theme persists across page navigation
- Mobile viewport: verify sidebar collapses to hamburger menu, KPI cards stack vertically
- Verify footer says "NobleDispatch" (with the D)

---

### Checkpoint 3 — Per-tenant logo upload system

**File:** `app/(app)/admin/settings/branding/page.tsx`

**UI:**
- New section in the existing tenant branding settings: "Tenant Logo"
- Current logo preview (or "No logo set" placeholder)
- Upload dropzone:
  - Accept PNG, JPG, SVG, WebP
  - Max 2MB
  - Recommended size: 400x400 minimum, transparent background preferred
  - On upload: store to existing tenant document storage (or S3 if configured), update `tenant_settings.logo_url`
- Remove logo button (clears `logo_url` back to NULL — reverts to Noble Dispatch fallback)
- Live preview alongside the dashboard header layout so the tenant sees how it'll look

**Backend:**
- `POST /api/tenant/logo` — handles upload, validates file type and size, writes to storage, updates DB
- `DELETE /api/tenant/logo` — clears `logo_url`, returns 204
- All endpoints respect RLS — tenant_owner role only

**Onboarding integration:**
- Add "Upload your logo" as a step in the Phase 4 onboarding checklist (already exists; just point it at this new page)

**Smoke tests:**
- As tenant_owner, upload a logo (use any test PNG)
- Verify it appears in the header within 1 second of upload
- Verify it appears on the login page (must be visible without re-login if you're already logged in — verify with a fresh incognito session)
- Upload an oversized 5MB file — verify rejection with friendly message
- Upload SVG — verify it works
- Remove logo — verify fallback to Noble Dispatch shield appears

---

### Checkpoint 4 — Seed ID Hotshot's logo

This is one-time data:

1. Locate the red shield-truck logo from earlier brand assets (the ID Hotshot logo that appears in dashboard mockups #4 and #5)
2. If it exists in repo from prior phases: copy to `public/brand/id_hotshot_logo.png`
3. If not: extract from the dashboard mockup or use the earlier ID Hotshot logo file (`BD7D9F9F-...PNG` from initial uploads)
4. Update ID Hotshot's `tenant_settings.logo_url` to point to this file:
   ```sql
   UPDATE app.tenant_settings
   SET logo_url = '/brand/id_hotshot_logo.png',
       logo_uploaded_at = now()
   WHERE tenant_id = (SELECT id FROM system.tenants WHERE slug = 'id-hotshot');
   ```

**Smoke tests:**
- Log out, visit `https://nobledispatch.idhotshot.com/login` — verify ID Hotshot logo appears above Noble Dispatch logo on login screen
- Log in — verify ID Hotshot logo appears in dashboard header
- Open an incognito window to a different tenant's instance (or create a test tenant with no logo) — verify ONLY the Noble Dispatch fallback shows

---

### Checkpoint 5 — Final smoke + commit

**End-to-end regression:**

1. Phase 1 services healthy
2. Login page renders with banner + glass login card on desktop
3. Login page works on mobile (375px) without overflow
4. Login succeeds for existing accounts (no auth regression)
5. Dashboard renders with correct tenant logo + "ID HOTSHOT | NOBLEDISPATCH" title + USDOT
6. All 5 KPI cards show real data
7. All 11 sidebar nav items route correctly
8. Theme toggle works and persists
9. Footer reads "NobleDispatch" (with the D)
10. Tenant logo upload works
11. No console errors on any page
12. Lighthouse score on login page: Performance >85, Accessibility >90

**Update `/opt/nobledispatch/WAKE_UP_README.md`:**
- New section: "Brand Asset Integration"
- Status of all 5 checkpoints
- Notes on:
  - `public/brand/` directory contents
  - Per-tenant logo upload location
  - Theme system implementation notes
  - Where to find the Noble Dispatch SVG logo component for future edits

**Final commit:**
```
[brand-integration / checkpoint 5] Visual asset integration complete

- Noble Dispatch banner on login page background
- Login page composition matches design reference
- Dashboard shell rebuilt with light + dark themes
- "TENANT NAME | NOBLEDISPATCH" header attribution pattern
- Per-tenant logo upload system
- ID Hotshot logo seeded
- "Noble ispatch" typo fixed → "NobleDispatch"
```

---

## OUTPUT FORMAT FOR THE STATUS LOG

Use tag `[BRAND-INTEGRATION / CHECKPOINT N]`:

```
[2026-XX-XX 02:14:33] [BRAND-INTEGRATION / CHECKPOINT 1] [START] Login page rebuild
[2026-XX-XX 02:14:51] [BRAND-INTEGRATION / CHECKPOINT 1] [INFO] Banner optimized: 645KB → 178KB WebP
[2026-XX-XX 02:15:08] [BRAND-INTEGRATION / CHECKPOINT 1] [INFO] Noble Dispatch SVG logo component created
[2026-XX-XX 02:15:34] [BRAND-INTEGRATION / CHECKPOINT 1] [TEST] Desktop login renders correctly (PASS)
[2026-XX-XX 02:15:42] [BRAND-INTEGRATION / CHECKPOINT 1] [TEST] Mobile 375px login renders correctly (PASS)
[2026-XX-XX 02:15:48] [BRAND-INTEGRATION / CHECKPOINT 1] [TEST] Login flow regression for Danielle's account (PASS)
[2026-XX-XX 02:16:02] [BRAND-INTEGRATION / CHECKPOINT 1] [GIT] Committed
[2026-XX-XX 02:16:03] [BRAND-INTEGRATION / CHECKPOINT 1] [DONE] ✅
```

---

## ===== PROMPT END =====

## After Claude Code finishes — what to check

1. **Open `https://nobledispatch.idhotshot.com/login` in a fresh browser tab.** Does the page now look like the design reference? Banner background, glass login card centered, ID Hotshot logo above Noble Dispatch logo, "idhotshot.com" footer pill.

2. **Log in.** Does the dashboard match the mockup? Red KPI card glow effects, sidebar nav with 11 items, "ID HOTSHOT | NOBLEDISPATCH" title with USDOT line beneath.

3. **Click the user avatar → toggle dark mode.** Does it shift to the carbon-fiber dark theme cleanly?

4. **Visit `/admin/settings/branding`.** Can you upload a new logo and see it propagate?

5. **Check the footer.** Should say "NobleDispatch" — verify the typo from the mockup is gone.

6. **Open in mobile viewport.** Verify the sidebar collapses, KPI cards stack, login card doesn't overflow.

---

## What this changes for sales

When you demo NobleDispatch to a prospect now, the product **looks like a product**. Not a generic SaaS template. Specifically:

- The login page is memorable — banner imagery sets brand tone instantly
- The "TENANT NAME | NOBLEDISPATCH" header pattern is a clean platform-attribution play
- The light/dark themes show technical polish that mid-tier prospects notice
- Per-tenant logo upload demonstrates white-label capability without explaining it

**Don't oversell this in demos.** The platform's value is what it does, not how it looks. But polish removes objections that bad UI creates ("is this a real product?"). This patch removes those objections.

---

**Created by The Noble Glitch · thenobleglitch.com · 2026**

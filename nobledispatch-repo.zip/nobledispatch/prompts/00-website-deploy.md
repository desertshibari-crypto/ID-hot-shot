# Claude Code Deployment Prompt — ID Hotshot Transportation

Copy everything below the `===PROMPT BEGIN===` line into Claude Code (`claude` in your terminal) on the server you want to deploy to. Run it from a fresh project directory.

---

## Before you run it — pick a server

I don't have visibility into your server inventory. Pick one that meets these criteria:

| Need | Minimum |
|---|---|
| OS | Ubuntu 22.04+ / Debian 12+ (the prompt assumes this) |
| RAM | 1 GB (2 GB recommended for Node + Postgres) |
| Disk | 10 GB |
| Public IP / domain | Yes — point `idhotshot.com` and `www.idhotshot.com` A records at the box before running |
| Ports open | 80, 443 (Cloudflare or direct) |
| Root / sudo | Yes |

If you've got several VPSes, **pick the one closest to Tucson or Denver geographically** — most of your visitors will be in the southwest, and a server in Phoenix, Las Vegas, Dallas, or Denver will feel snappier than one on the East Coast. Bonus if it already has Node 20+ installed.

## Before you run it — get these credentials ready

The prompt will ask you for these. Have them on hand:

1. **Domain DNS already pointed** at the server's IP (`idhotshot.com` + `www.idhotshot.com`)
2. **Twilio account** (free tier is fine to start) — you'll need:
   - Account SID
   - Auth Token  
   - A Twilio phone number that can SMS US numbers
3. **Iliana's actual cell phone** in E.164 format (e.g. `+15202399422`)
4. **SMTP credentials** for outbound email (Resend, Postmark, SendGrid, or just Gmail SMTP) — for contact-form emails to `dispatch@idhotshot.com`
5. **An email address** to receive admin notifications
6. **(Optional) Google Maps API key** if you want real distance lookup from ZIP→ZIP. If you skip this, the calculator falls back to manual mile entry only.
7. **(Optional) Anthropic API key** if you want the chat widget to use Claude for first-touch responses before texting Iliana
8. **(Optional) An image-generation API key** — the prompt will offer to generate the missing AI images. Options: Replicate, fal.ai, OpenAI Images, Stability. If you skip this, it'll use SVG placeholders that still look good.

## Files included with this prompt

- `idhotshot_site.html` — a working static preview of the site that I built. You can open it in any browser to see exactly what we're deploying. Claude Code will use this as the visual reference and rebuild it as a real production app.

---

## ===PROMPT BEGIN===

You are deploying the production website for **ID Hotshot Transportation** at the domain **idhotshot.com**.

I have a working static HTML reference of the site at `./idhotshot_site.html` (or wherever I drop it — ask me if you can't find it). Open it in a browser or read it as a file. **That file is the visual + UX spec.** Match its design language, copy, color palette, fonts (Anton + Barlow), animations, and frame-based navigation. Do not invent a different design.

### Stack

Build it as a production-grade Next.js 14+ application (App Router, TypeScript, Tailwind), backed by a small Node API. Keep the frame-based feel — use the App Router with sections that swap in the same layout (sticky nav stays mounted), not a single endless scroll page.

- **Frontend**: Next.js 14 + TypeScript + Tailwind, deployed via PM2 + Nginx + Let's Encrypt
- **Database**: SQLite (via `better-sqlite3`) for bookings/contacts/messages — keep it simple, this is a small operation
- **Chat → SMS**: Twilio. Visitor messages POST to `/api/chat`, server forwards to Iliana's phone via SMS. Replies from her phone come back via Twilio webhook to `/api/chat/reply` and stream back into the visitor's session via Server-Sent Events.
- **Email**: Use whichever SMTP I provide via `nodemailer`
- **Calendar availability**: Real, not pseudorandom — back it with the SQLite table `bookings` and mark days "limited" at 3+ bookings, "full" at 6+
- **Rate calculator**: Identical math to the reference file. If I provide a Google Maps API key, add a ZIP→ZIP distance lookup that auto-fills the miles field. Keep manual entry as a fallback.

### Project structure

```
idhotshot/
├─ app/
│  ├─ layout.tsx         (sticky nav + footer + chat fab)
│  ├─ page.tsx           (home frame)
│  ├─ story/page.tsx
│  ├─ services/page.tsx
│  ├─ rates/page.tsx
│  ├─ book/page.tsx
│  ├─ contact/page.tsx
│  └─ api/
│     ├─ book/route.ts
│     ├─ contact/route.ts
│     ├─ chat/route.ts
│     ├─ chat/reply/route.ts    (Twilio inbound webhook)
│     ├─ chat/stream/route.ts   (SSE to client)
│     ├─ availability/route.ts
│     └─ distance/route.ts
├─ components/
│  ├─ Nav.tsx
│  ├─ Footer.tsx
│  ├─ ChatWidget.tsx
│  ├─ Calendar.tsx
│  ├─ RateCalculator.tsx
│  ├─ HeroBanner.tsx
│  ├─ TruckStrip.tsx
│  └─ AnimatedSpeedlines.tsx
├─ lib/
│  ├─ db.ts              (SQLite setup + migrations)
│  ├─ twilio.ts
│  ├─ mail.ts
│  └─ rates.ts           (rate constants — single source of truth)
├─ public/
│  ├─ logo-square.png    (copy from idhotshot_site.html base64 or ask me to upload)
│  ├─ logo-wide.png      (the cinematic hero)
│  └─ generated/         (AI-generated filler images, see below)
├─ .env.local
├─ ecosystem.config.js   (PM2)
└─ next.config.js
```

### Animation requirements (don't skip these — they're the personality)

- **Hero**: the cinematic wide logo image (logo-wide.png) is the centerpiece. Behind/over it, animate horizontal red speed-lines streaking left-to-right on a 2.4s loop, staggered.
- **Truck strip**: between sections, a thin horizontal band where a small truck SVG drives across with text trailing it ("Phoenix → Denver · On Time, Every Time · Fully Insured"). Continuous loop.
- **Frame transitions**: when a nav item is clicked, fade-and-slide-up the new frame over 550ms with a cubic-bezier(0.16, 1, 0.3, 1) easing.
- **Stat counters**: count up from 0 on home frame mount.
- **Service cards**: red top-border slides in from the left on hover, card lifts 6px.
- **Calculator quote**: the dollar amount should tick up smoothly when inputs change, not snap.
- **Chat FAB**: subtle pulse ring around it. Badge with "1" until first opened.

### Copy / story

The full copy is already written in the reference file. Pull it verbatim — the founder's name is **Iliana Delgado**, the story is intentionally specific, don't water it down or change names.

### Phone, USDOT, domain — don't change these

- Phone: `520-239-9422` (also Twilio destination for chat→SMS)
- USDOT: `4559278`  
- Domain: `idhotshot.com`
- Email: `dispatch@idhotshot.com`
- Locations: Tucson, AZ (HQ) + Denver, CO (shop)

### Rates — the single source of truth

Put these in `lib/rates.ts` and import everywhere:

```ts
export const EQUIPMENT = {
  box:     { name: "13' Box Truck",        rate: 1.40, min: 125, market: 2.00 },
  trailer: { name: "Pickup + 18' Trailer", rate: 1.55, min: 175, market: 2.00 },
  fifth:   { name: "5th Wheel Hauling",    rate: 1.85, min: 250, market: 2.25 },
  camper:  { name: "Camper / Travel Trailer", rate: 1.75, min: 225, market: 2.25 },
  bumper:  { name: "Bumper Pull / Utility", rate: 1.65, min: 200, market: 2.00 },
};
export const ADDONS = {
  expedited: 1.15,
  weekend:   1.10,
  oversize:  1.25,
  liftgate:  1.00, // free
};
```

### Chat → SMS architecture (the part that needs the most care)

1. Visitor opens chat, types a message.
2. POST `/api/chat` with `{ sessionId, message, contact? }`. Server:
   - Stores the message in SQLite (`messages` table, indexed by `sessionId`)
   - Sends an SMS to Iliana via Twilio: `[ID Hotshot] Visitor #ABC1: "their message"\nReply to this text and they'll see it.\nView: idhotshot.com/admin/chat/ABC1`
   - **Important**: Twilio SMS doesn't carry session metadata, so we use a **registry of short session IDs** (3-6 char alphanumeric). When Iliana replies to the SMS, we map her reply back to the most-recent session that texted her. If she wants to reply to an older one, she texts `#ABC1 your reply`.
   - Returns immediately so the chat UI feels snappy. If `ANTHROPIC_API_KEY` is set, also kick off a Claude `claude-haiku-4-5` first-touch response with the system prompt: "You are Iliana's assistant for ID Hotshot Transportation. Answer common questions about hotshot rates, equipment (box truck, 18' trailer, 5th wheel, camper, bumper pull), insurance ($1M cargo + $1M auto), USDOT 4559278, locations (Tucson + Denver), and 24/7 dispatch. If they want a real quote or booking, tell them Iliana will text them back from 520-239-9422 within minutes." Stream that reply into the chat first, with a label like "Auto-reply · Iliana texting you now".
3. Twilio webhook to `/api/chat/reply`: when Iliana texts back, parse the body. If it starts with `#XXXX` route to that session; otherwise route to the most recently active session (within last 2 hours). Store and broadcast via SSE to that session's open browser tab.
4. Visitor's browser keeps an EventSource connection to `/api/chat/stream?sessionId=...` to receive Iliana's responses live.

If `TWILIO_*` env vars are missing, the chat widget should still work — it falls back to "your message has been logged, Iliana will reach out by phone shortly" and emails the message to the dispatch address instead.

### Booking flow

`/api/book` accepts `{ date, slot, name, phone, email?, notes }`, validates, inserts into `bookings`, sends:
- SMS to Iliana with the booking details + a link to a `/admin/bookings/[id]` page
- Email to `dispatch@idhotshot.com` with the same  
- Confirmation SMS to the customer's phone if Twilio is configured

`/api/availability?month=YYYY-MM` returns a JSON map of `{ "YYYY-MM-DD": "open" | "limited" | "full" }` based on current booking density.

### Admin

Build a minimal `/admin` route protected by HTTP Basic Auth (creds in `.env.local`). It lists bookings, contact submissions, and chat sessions. No fancy UI needed — just a working dashboard so Iliana can review what's come in.

### AI-generated filler images

The reference file uses CSS gradient placeholders for some sections (founder photo, service icons). If I provide an image-gen API key, generate these in `/public/generated/` using the prompts below. If not, leave the SVG placeholders — they look fine.

Image prompts (use whatever model is best — flux-pro, sdxl, dall-e 3, etc.):

1. **`founder-portrait.jpg`** — "Confident woman in her late 30s, Latina, wearing a slightly worn red flannel shirt, leaning against the door of a white box truck at golden hour in the Arizona desert, mountains in the background, photorealistic, 4:3 ratio, cinematic lighting, looks like a real photo not a render"

2. **`box-truck-action.jpg`** — "White 13-foot box truck driving fast on a desert highway in Arizona, motion blur on the wheels, red speed lines, dust trail, dramatic lighting, professional commercial photography, 16:9"

3. **`fleet-lineup.jpg`** — "Three white box trucks and pickup trucks with trailers parked in a row outside a small commercial garage in Colorado, snow-capped mountains in distance, blue sky, professional photography, 16:9"

4. **`truck-cab-interior.jpg`** — "Interior of a box truck cab, clean, GPS mounted on dash, coffee in cup holder, slightly worn but well-maintained, morning light through windshield, photorealistic, 4:3"

5. **`trailer-hauling.jpg`** — "White pickup truck pulling an 18-foot enclosed trailer through mountain pass, Colorado scenery, golden hour, professional commercial photography, 16:9"

Place 1 & 2 on the home frame, 3 on services, 4 in story alongside the timeline, 5 in services as a hero for the trailer card.

### Deployment & DNS

- Use PM2 to run Next.js on port 3000. Config in `ecosystem.config.js` with restart on crash.
- Nginx reverse proxy from 80/443 → 3000, with `idhotshot.com` and `www.idhotshot.com` server names. Redirect www → apex (or apex → www, your call — pick one and stick with it).
- Use `certbot --nginx` to get a Let's Encrypt cert. Set up auto-renewal via the systemd timer.
- Add gzip + brotli compression in Nginx. Cache static assets aggressively. Set `next-sitemap` to generate `sitemap.xml`.
- Add basic security headers (HSTS, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, a sensible CSP that allows the Twilio + your image-gen domain).
- Enable Cloudflare in front if I have an account — ask me before assuming.

### Performance budget

- Lighthouse Performance ≥ 90 on mobile
- LCP < 2.0s
- The hero image is the biggest asset — output it as AVIF + WebP fallbacks via `next/image`, lazy-load everything below the fold.

### SEO

- Title: "ID Hotshot Transportation — Hotshot Trucking AZ & CO | USDOT 4559278"
- Meta description: "Woman-owned hotshot trucking out of Tucson and Denver. Box trucks, 5th wheels, campers, trailers. Fully insured, 24/7 dispatch, 10–15% under market. USDOT 4559278."
- Per-page titles + descriptions
- Schema.org `MovingCompany` + `LocalBusiness` JSON-LD with both locations, phone, USDOT, hours (24/7)
- `robots.txt` + sitemap
- OpenGraph image: use the wide cinematic logo

### Step-by-step execution

Walk through this in order and check in with me at each step:

1. Confirm the server, ask me which directory to install into, and verify Node 20+ + nginx are present (install if not).
2. Read `idhotshot_site.html` from the project root to lock in the visual spec.
3. Scaffold the Next.js project with the structure above.
4. Build the layout, nav, footer, and chat FAB first. Show me the home page locally on `:3000` over SSH tunnel before going further.
5. Build out each frame (story, services, rates, book, contact) one at a time. After each, push to a staging branch I can preview.
6. Wire the API routes. Test each one with curl before moving on.
7. Twilio integration last. Walk me through the webhook URL setup in the Twilio console.
8. AI image generation pass (optional, only if I gave you an API key).
9. Nginx + certbot + DNS verification.
10. Final Lighthouse pass and SEO audit.
11. Hand me a one-page operations cheat sheet: how to update copy, how Iliana texts to reply to chats, where logs are, how to roll back.

### Things to ask me before assuming

- Which directory on the server? (`/var/www/idhotshot`? `/opt/idhotshot`? somewhere else?)
- Cloudflare in front, or direct?
- Do I want comments / blog / news section now, or later?
- Should Iliana have a separate "driver app" (mobile PWA showing assigned bookings)? Out of scope unless I say yes.

Be thorough, be opinionated, and don't fake any integration — if a credential is missing, tell me and stub it cleanly so the rest of the site still works.

## ===PROMPT END===

---

## After Claude Code is done

Test these things in order:

1. Open `https://idhotshot.com` — does the hero render? Speed lines animate?
2. Click each nav item — frames swap without full page reload?
3. Rate calculator — change equipment, type miles, do the numbers update? Does the savings box appear?
4. Book a fake pickup — does Iliana get the SMS? Does the customer get a confirmation?
5. Open the chat widget on your phone, send "test from a customer" — does Iliana's phone buzz?
6. Have Iliana text a reply to that SMS — does it appear in the chat window in the browser?
7. Submit the contact form — does the email arrive at `dispatch@idhotshot.com`?
8. Visit `safer.fmcsa.dot.gov` and look up USDOT 4559278 to make sure it shows up — that's an external trust signal worth checking.

## Going further (later sprints)

- Driver-side mobile PWA so dispatched drivers can see jobs and update status
- Stripe integration for deposit-on-booking (10% deposit reserves the slot)
- Customer accounts so repeat customers don't re-enter info
- Lane analytics dashboard (what routes are most profitable, where deadhead is killing margin)
- Integration with DAT / Truckstop load boards if you ever want to take broker freight
- Reviews / testimonials section (collect via post-delivery SMS asking for a Google review)

Good luck — this is going to be a great-looking site for a great-sounding business.
